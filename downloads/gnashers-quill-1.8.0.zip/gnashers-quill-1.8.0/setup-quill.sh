#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# setup-quill.sh — install everything Gnasher's Quill needs, on macOS or Linux.
#
#   chmod +x setup-quill.sh
#   ./setup-quill.sh              install what's missing (asks first)
#   ./setup-quill.sh --dry-run    show what it would do, change nothing
#   ./setup-quill.sh --yes        don't ask
#   ./setup-quill.sh --model      also pre-download the speech model
#
# Idempotent: anything already present is detected and skipped.
#
# HONEST NOTE: the Quill was built and measured on Windows. This script and the
# macOS/Linux audio paths are written to the documented interfaces but have not been
# run on those machines. `python3 quill_platform.py` is the one command to run first —
# it prints exactly what it detected and the record command it would use, so a wrong
# guess shows up in one line rather than at 7pm on game night.

set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRY=0; YES=0; MODEL=0; DID=0
for a in "$@"; do
  case "$a" in
    --dry-run) DRY=1 ;;
    --yes|-y)  YES=1 ;;
    --model)   MODEL=1 ;;
    *) echo "unknown option: $a"; exit 2 ;;
  esac
done

head() { printf '\n  %s\n  %s\n' "$1" "$(printf -- '-%.0s' {1..62})"; }
good() { printf '  OK   %s\n' "$1"; }
warn() { printf '  ..   %s\n' "$1"; }
bad()  { printf '  !!   %s\n' "$1"; }

confirm() {
  if [ "$DRY" = 1 ]; then warn "would run: $1"; return 1; fi
  if [ "$YES" = 1 ]; then return 0; fi
  printf '  ->   %s\n' "$1"
  read -r -p "       run this? (Y/n) " a </dev/tty || return 1
  [ -z "$a" ] || [ "${a:0:1}" = "y" ] || [ "${a:0:1}" = "Y" ]
}

OS="$(uname -s)"
printf '\n  GNASHER'"'"'S QUILL - setup\n  %s\n' "$HERE"
[ "$DRY" = 1 ] && echo "  DRY RUN - nothing will be installed"

# --- 1. a package manager ----------------------------------------------------
head "1. Package manager"
PM=""
if   command -v brew    >/dev/null 2>&1; then PM="brew";   good "Homebrew"
elif command -v apt-get >/dev/null 2>&1; then PM="apt";    good "apt"
elif command -v dnf     >/dev/null 2>&1; then PM="dnf";    good "dnf"
elif command -v pacman  >/dev/null 2>&1; then PM="pacman"; good "pacman"
else
  bad "No supported package manager found."
  if [ "$OS" = "Darwin" ]; then
    echo '       Install Homebrew:  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  fi
fi

pm_install() {  # pm_install <brew-pkg> <apt-pkg>
  case "$PM" in
    brew)   confirm "brew install $1"            && { brew install "$1"; DID=1; } ;;
    apt)    confirm "sudo apt-get install -y $2" && { sudo apt-get install -y "$2"; DID=1; } ;;
    dnf)    confirm "sudo dnf install -y $2"     && { sudo dnf install -y "$2"; DID=1; } ;;
    pacman) confirm "sudo pacman -S --noconfirm $2" && { sudo pacman -S --noconfirm "$2"; DID=1; } ;;
    *)      bad "Install '$1' by hand." ;;
  esac
}

# --- 2. Python ---------------------------------------------------------------
head "2. Python 3.10+"
PY=""
for c in python3.12 python3.11 python3; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done
if [ -n "$PY" ]; then good "$($PY --version 2>&1)"; else pm_install python python3; PY="python3"; fi

# --- 3. ffmpeg ---------------------------------------------------------------
head "3. ffmpeg (does the recording)"
if command -v ffmpeg >/dev/null 2>&1; then good "ffmpeg present"; else pm_install ffmpeg ffmpeg; fi

# --- 4. Linux needs a way to SEE microphones ---------------------------------
if [ "$OS" != "Darwin" ]; then
  head "4. PulseAudio tools (so mics can be listed)"
  if command -v pactl >/dev/null 2>&1; then good "pactl present"
  else
    warn "pactl not found - the Quill falls back to the ALSA 'default' device."
    pm_install pulseaudio pulseaudio-utils
  fi
fi

# --- 5. faster-whisper -------------------------------------------------------
head "5. faster-whisper (does the transcribing)"
if [ -n "$PY" ] && $PY -c "import faster_whisper" >/dev/null 2>&1; then
  good "faster-whisper $($PY -c 'import faster_whisper;print(faster_whisper.__version__)' 2>/dev/null)"
else
  # A venv beside the Quill keeps this off the system Python, which modern distros
  # (and Homebrew) refuse to let pip touch anyway.
  if [ ! -d "$HERE/.venv" ] && confirm "$PY -m venv '$HERE/.venv'   (keeps deps out of system Python)"; then
    $PY -m venv "$HERE/.venv"; DID=1
  fi
  if [ -x "$HERE/.venv/bin/python" ]; then PY="$HERE/.venv/bin/python"; fi
  confirm "$PY -m pip install --upgrade faster-whisper" && { $PY -m pip install --upgrade faster-whisper; DID=1; }
fi

# --- 6. the model ------------------------------------------------------------
head "6. The speech model"
if $PY - <<'EOF' >/dev/null 2>&1
import os,glob
h=os.path.expanduser("~/.cache/huggingface/hub")
raise SystemExit(0 if glob.glob(os.path.join(h,"*whisper*")) else 1)
EOF
then good "a Whisper model is cached - transcription is fully offline from here"
elif [ "$MODEL" = 1 ]; then
  confirm "download small.en now (~500 MB, once)" && {
    $PY -c "from faster_whisper import WhisperModel; WhisperModel('small.en')"; DID=1; }
else
  warn "not downloaded yet. The FIRST transcription fetches it (~500 MB, once)."
  echo  "       To get it now, while you have wifi:  ./setup-quill.sh --model"
fi

# --- 7. verify ---------------------------------------------------------------
head "7. Checking the whole chain"
$PY "$HERE/quill_platform.py"
RC=$?

echo
if [ "$DRY" = 1 ]; then echo "  DRY RUN complete - nothing was changed."
elif [ "$RC" = 0 ]; then echo "  Ready. Start the web studio:  ./quill"
else echo "  Something above still needs fixing - see the probe output."; fi
echo
