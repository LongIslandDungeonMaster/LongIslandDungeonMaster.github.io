@echo off
title Gnasher's Quill - Pre-game check
REM ============================================================
REM  DOUBLE-CLICK THIS BEFORE GAME NIGHT.
REM
REM  It checks every link in the chain - Python, faster-whisper,
REM  ffmpeg, your microphone, disk space - and prints the exact fix
REM  for anything that is missing. It changes nothing.
REM
REM  -ExecutionPolicy Bypass is here because Windows blocks unsigned
REM  PowerShell scripts by default. It applies to THIS run only.
REM ============================================================

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Quill-Doctor.ps1"

echo.
pause
