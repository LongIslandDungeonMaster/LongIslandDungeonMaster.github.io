# LEDGER - what was promised at this table

> Built by `Quill-Ledger.py` from your session transcripts. Promises, debts and
> threats that were actually *spoken aloud*, in-fiction only.
>
> **This file is yours to edit.** Tick a box when you've paid it off. Write notes
> under any entry. Delete entries you don't care about - they stay deleted.
> Re-running the script never overwrites your edits.
>
> `world` = an NPC committed to something.  `party` = the players did.

**0 open - 0 closed** - not built yet
