# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
quill_chorus — one track per voice, so the transcript knows who said what.

THE PROBLEM THIS SIDESTEPS
    Working out who is speaking from a single room microphone (diarization) is genuinely
    hard, and five people talking over each other at a table defeats it. So don't solve
    it. If every voice records ITSELF, the speaker label is not inferred -- it is known.

    Each player opens a page on their own phone, types their name, and hits record. The
    browser captures their mic locally and streams chunks to this laptop over the LAN.
    Afterwards each track transcribes separately (already knowing its speaker) and the
    tracks merge into one interleaved master transcript.

    Remote play falls out for free: each player records their LOCAL mic, so nobody has to
    capture the voice call. Same merge, whether the table is one room or five states.

CLOCK SYNC, HONESTLY
    Every track needs to sit on one timeline. When a device actually starts recording it
    calls /api/chorus/start and the SERVER stamps that moment; the track's offset is that
    stamp minus the session start. The error is one LAN round-trip -- tens of milliseconds
    -- against transcript segments measured in seconds. That is fine, and it is measured
    rather than assumed. `offset_s` is written into the manifest so the merge can show it.

WHAT IT WRITES
    recordings/chorus/<session>/
        chorus.json          the manifest: speakers, offsets, byte counts
        <speaker>.webm       one continuous track per voice

Stdlib only. Nothing leaves the LAN.
"""
import json
import os
import re
import secrets
import shutil
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CHORUS_ROOT = HERE / "recordings" / "chorus"

# Five phones for five hours is roughly 1.5 GB. Refuse to start below this, and stop
# accepting audio below the floor, so a full disk never takes the DM's own recording
# down with it.
MIN_FREE_TO_OPEN = 3 * 1024**3
MIN_FREE_TO_KEEP = 512 * 1024**2

# A phone sends a chunk every 5s. Four missed in a row means the pocket, the
# screen lock, or the far end of the house -- and the DM needs to know DURING
# the game, not when the merge report says that voice is twenty minutes short.
STALL_AFTER = 20


def free_bytes():
    try:
        return shutil.disk_usage(str(HERE)).free
    except OSError:
        return None

# MediaRecorder gives webm/opus on Android/desktop Chrome and mp4/aac on iOS Safari.
# We keep whatever the device produced; ffmpeg reads both, so the merge does not care.
EXT_FOR = {
    "audio/webm": "webm",
    "audio/ogg": "ogg",
    "audio/mp4": "m4a",
    "audio/mpeg": "mp3",
    "audio/wav": "wav",
}


def safe_name(s, fallback="voice"):
    s = re.sub(r"[^\w\- ]", "", (s or "").strip())[:40].strip()
    s = re.sub(r"\s+", "-", s)
    return s or fallback


class Chorus:
    """The live multi-track session. One instance, guarded by a lock."""

    def __init__(self):
        self.lock = threading.Lock()
        self.open_session = None      # dict or None

    # --- session ----------------------------------------------------------
    def open(self, label="", master_started=None, master_file=None):
        """Start a Chorus session. If the studio's own recorder is already running,
        pass its start time so every phone lands on the DM's timeline."""
        with self.lock:
            if self.open_session:
                return {"ok": True, "already": True, **self._public()}
            free = free_bytes()
            if free is not None and free < MIN_FREE_TO_OPEN:
                return {"ok": False, "error":
                        f"Only {free/1024**3:.1f} GB free. A Chorus session with several "
                        f"phones needs a few GB. Free some space first."}
            started = master_started or time.time()
            name = safe_name(label, "")
            stamp = time.strftime("%Y-%m-%d_%H%M", time.localtime(started))
            session = f"{stamp}_{name}" if name else stamp
            folder = CHORUS_ROOT / session
            folder.mkdir(parents=True, exist_ok=True)
            self.open_session = {
                "session": session,
                # The join link is the credential. Without this, anyone on the Wi-Fi
                # could enumerate the API and write audio into this folder.
                "token": secrets.token_urlsafe(8),
                "folder": folder,
                "started": started,
                "master_file": master_file,
                "tracks": {},          # track_id -> dict
            }
            self._save()
            return {"ok": True, **self._public()}

    def close(self):
        with self.lock:
            if not self.open_session:
                return {"ok": False, "error": "No Chorus session is open."}
            for t in self.open_session["tracks"].values():
                self._close_track(t)
            self._save()
            out = self._public()
            out["folder"] = str(self.open_session["folder"])
            self.open_session = None
            return {"ok": True, "closed": True, **out}

    def check(self, token):
        """Every Chorus call must present the token from the join link."""
        s = self.open_session
        if not s:
            return False
        return bool(token) and secrets.compare_digest(str(token), s["token"])

    # --- a voice ----------------------------------------------------------
    def join(self, speaker, mime=""):
        """Reserve a track. Does NOT set the offset -- the device may sit on the
        join screen for a while before it actually starts recording."""
        with self.lock:
            if not self.open_session:
                return {"ok": False, "error": "No Chorus session is open yet. "
                                              "Ask the DM to start one."}
            base = safe_name(speaker)
            tid, n = base, 2
            while tid in self.open_session["tracks"]:
                tid = f"{base}-{n}"
                n += 1
            ext = EXT_FOR.get((mime or "").split(";")[0].strip(), "webm")
            path = self.open_session["folder"] / f"{tid}.{ext}"
            self.open_session["tracks"][tid] = {
                "id": tid, "speaker": speaker or tid, "path": path,
                "mime": mime, "offset_s": None, "bytes": 0, "chunks": 0,
                "started": None, "ended": None, "fh": None, "last": None,
            }
            self._save()
            return {"ok": True, "track": tid, "session": self.open_session["session"]}

    def start(self, tid):
        """The device's recorder actually started. Stamp the offset here, server-side."""
        with self.lock:
            t = self._track(tid)
            if not t:
                return {"ok": False, "error": "Unknown track - rejoin."}
            now = time.time()
            t["started"] = now
            t["offset_s"] = max(0.0, round(now - self.open_session["started"], 3))
            t["fh"] = open(t["path"], "ab")
            self._save()
            return {"ok": True, "offset_s": t["offset_s"]}

    def chunk(self, tid, blob):
        """Append one MediaRecorder chunk. They must land in order: the first chunk
        carries the container header and the rest are meaningless without it."""
        with self.lock:
            t = self._track(tid)
            if not t:
                return {"ok": False, "error": "Unknown track."}
            if t["fh"] is None:
                t["fh"] = open(t["path"], "ab")
                if t["offset_s"] is None:      # chunk arrived before /start
                    t["started"] = time.time()
                    t["offset_s"] = max(0.0, round(t["started"] - self.open_session["started"], 3))
            t["fh"].write(blob)
            t["fh"].flush()
            os.fsync(t["fh"].fileno())         # a dropped phone must not cost the track
            t["bytes"] += len(blob)
            t["chunks"] += 1
            t["last"] = time.time()
            if t["chunks"] % 20 == 0:
                free = free_bytes()
                if free is not None and free < MIN_FREE_TO_KEEP:
                    self._close_track(t)
                    return {"ok": False, "stop": True,
                            "error": "The laptop is out of disk space. This track was "
                                     "closed cleanly; what you already sent is safe."}
            if t["chunks"] % 10 == 0:
                self._save()
            return {"ok": True, "bytes": t["bytes"]}

    def leave(self, tid):
        with self.lock:
            t = self._track(tid)
            if not t:
                return {"ok": False, "error": "Unknown track."}
            self._close_track(t)
            self._save()
            return {"ok": True, "bytes": t["bytes"]}

    # --- status -----------------------------------------------------------
    def status(self, include_token=False):
        """Session state for the status poll. The table code rides along ONLY when
        the server vouches the request came from the studio machine itself: the
        code is the WRITE credential for this session, and /api/chorus/status is
        readable by every device on the network. Serving the key on the same
        shelf as the lock made the whole gate decorative."""
        with self.lock:
            if not self.open_session:
                return {"open": False}
            out = {"open": True, **self._public()}
            if not include_token:
                out.pop("token", None)
            return out

    # --- internals --------------------------------------------------------
    def _track(self, tid):
        if not self.open_session:
            return None
        return self.open_session["tracks"].get(tid)

    def _close_track(self, t):
        if t.get("fh"):
            try:
                t["fh"].flush()
                os.fsync(t["fh"].fileno())
                t["fh"].close()
            except Exception:
                pass
            t["fh"] = None
        if t.get("ended") is None and t.get("started"):
            t["ended"] = time.time()

    def _public(self):
        s = self.open_session
        el = time.time() - s["started"]
        return {
            "session": s["session"],
            "token": s["token"],
            "elapsed": int(el),
            "voices": [
                {
                    "track": t["id"], "speaker": t["speaker"],
                    "offset_s": t["offset_s"], "bytes": t["bytes"],
                    "live": t["fh"] is not None,
                    # Open file handle but nothing arriving: the phone still
                    # thinks it is recording and the DM would never know.
                    "stalled": bool(t["fh"] is not None and t["last"]
                                    and time.time() - t["last"] > STALL_AFTER),
                    "silent_for": int(time.time() - t["last"]) if t["last"] else None,
                    "seconds": int((t["ended"] or time.time()) - t["started"]) if t["started"] else 0,
                }
                for t in s["tracks"].values()
            ],
        }

    def _save(self):
        """Write the manifest after every meaningful change, so a laptop that dies
        mid-session still leaves the merge everything it needs."""
        s = self.open_session
        if not s:
            return
        man = {
            "session": s["session"],
            "started": s["started"],
            "started_iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(s["started"])),
            "master_file": s["master_file"],
            "tracks": [
                {k: (str(v) if isinstance(v, Path) else v)
                 for k, v in t.items() if k != "fh"}
                for t in s["tracks"].values()
            ],
        }
        tmp = s["folder"] / "chorus.json.tmp"
        tmp.write_text(json.dumps(man, indent=2), encoding="utf-8")
        tmp.replace(s["folder"] / "chorus.json")


chorus = Chorus()
