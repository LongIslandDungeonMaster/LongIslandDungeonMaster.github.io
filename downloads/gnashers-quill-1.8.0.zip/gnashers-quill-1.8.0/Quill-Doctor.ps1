﻿# SPDX-License-Identifier: MIT
# Quill-Doctor.ps1 — "will the Quill actually work tonight?"
#
# Run this BEFORE game night, and first thing on any new machine. It checks every
# part of the chain and tells you exactly what to type to fix whatever is missing.
#
#   Right-click -> Run with PowerShell, or:  powershell -ExecutionPolicy Bypass -File Quill-Doctor.ps1
#
# Deliberately written in PowerShell with no dependencies, because half of what it
# checks IS the dependencies. It has to run on a machine where nothing is installed yet.

$ErrorActionPreference = "SilentlyContinue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$fails = 0; $warns = 0

function Say($state, $label, $detail, $fix) {
    $color = switch ($state) { "ok" {"Green"} "warn" {"Yellow"} default {"Red"} }
    $mark  = switch ($state) { "ok" {"  OK  "} "warn" {" WARN "} default {" FAIL "} }
    # One Write-Host per line on purpose: -NoNewline fragments the output when this
    # is piped or captured, which is exactly when you most want to read it.
    Write-Host ("{0} {1,-22} {2}" -f $mark, $label, $detail) -ForegroundColor $color
    if ($fix -and $state -ne "ok") { Write-Host "         -> $fix" -ForegroundColor Cyan }
    if ($state -eq "fail") { $script:fails++ } elseif ($state -eq "warn") { $script:warns++ }
}

Write-Host ""
Write-Host "  GNASHER'S QUILL - pre-game check" -ForegroundColor White
Write-Host "  $here" -ForegroundColor DarkGray
Write-Host ("  " + ("-" * 62)) -ForegroundColor DarkGray

# --- 1. Python ---------------------------------------------------------------
# The Doctor asks quill_python.ps1 the same question the transcriber asks it, and
# gets the same answer. It used to run its own search in its own order, so it
# happily reported "OK faster-whisper v1.2.1" about an interpreter that nothing
# else in the Quill would ever run. A checker that answers a different question
# than the tool is worse than no checker.
$pyHelper = Join-Path $here "quill_python.ps1"
$py = $null
if (-not (Test-Path $pyHelper)) {
    Say fail "quill_python.ps1" "missing" "Keep the whole Quill folder together - re-extract the download."
} else {
    . $pyHelper
    $py = Find-Python -RequireModule faster_whisper
}

if ($py) {
    Say ok "Python" $py.VersionText $null
    # WHICH one. This is the line that ends the "but it works in the other window"
    # argument -- every other Quill script resolves to this exact path.
    Say ok "  interpreter" $py.Display $null
} elseif (Test-Path $pyHelper) {
    Say fail "Python" "not found" "Install Python 3.12+ from python.org - tick 'Add python.exe to PATH'."
}

# --- 2. faster-whisper -------------------------------------------------------
# Checked IN THE INTERPRETER CHOSEN ABOVE, never "in some python on this machine".
if ($py -and -not $py.ModuleMissing) {
    $fw = Get-QuillPythonVersionText $py "faster_whisper"
    if (-not $fw) { $fw = "present" }
    Say ok "faster-whisper" "v$fw (in the interpreter above)" $null
} elseif ($py) {
    Say fail "faster-whisper" "NOT installed in $($py.Display)" `
        "Python is fine; the module is missing from it. Run 'SETUP (run me first).bat'."
} elseif (Test-Path $pyHelper) {
    Say fail "faster-whisper" "cannot check - no Python" $null
}

# --- 3. ffmpeg ---------------------------------------------------------------
$ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue).Source
if (-not $ff) {
    $ff = "$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe"
    if (-not (Test-Path $ff)) { $ff = $null }
}
if ($ff) {
    $fv = (& $ff -version 2>&1 | Select-Object -First 1)
    Say ok "ffmpeg" (($fv -split " ")[0..2] -join " ") $null
} else {
    Say fail "ffmpeg" "not found - recording is impossible" "winget install Gyan.FFmpeg   (then reopen this window)"
}

# --- 4. microphone -----------------------------------------------------------
if ($ff) {
    # ffmpeg prints its device list to STDERR, and this script sets
    # $ErrorActionPreference='SilentlyContinue' -- under which PowerShell DISCARDS a
    # native command's stderr entirely. Both `2>&1` and PowerShell's own `2> file`
    # come back empty (verified), which is why this first reported "no microphone" on
    # a laptop that plainly had one. Handing the redirect to cmd.exe sidesteps
    # PowerShell's stream handling completely.
    $tmp  = Join-Path $env:TEMP "quill-devices.txt"
    Remove-Item $tmp -ErrorAction SilentlyContinue
    cmd /c "`"$ff`" -hide_banner -list_devices true -f dshow -i dummy 2> `"$tmp`"" | Out-Null
    $mics = @()
    foreach ($ln in (Get-Content $tmp -ErrorAction SilentlyContinue)) {
        $m = [regex]::Match($ln, '"([^"]+)"\s*\(audio\)')   # same matcher as Get-Mic
        if ($m.Success) { $mics += $m.Groups[1].Value }
    }
    Remove-Item $tmp -ErrorAction SilentlyContinue
    if ($mics) { Say ok "Microphone" ("{0} found: {1}" -f $mics.Count, $mics[0]) $null }
    else { Say fail "Microphone" "no audio input device" "Plug in / enable a mic, then check Windows Sound settings." }
} else { Say fail "Microphone" "cannot check - no ffmpeg" $null }

# --- 5. GPU (nice to have) ---------------------------------------------------
if ($py) {
    $cuda = (Invoke-Python $py @("-c", "import ctranslate2;print(ctranslate2.get_cuda_device_count())") 2>&1 | Out-String).Trim()
    if ($cuda -match "^\d+$" -and [int]$cuda -gt 0) {
        Say ok "GPU (CUDA)" "$cuda device(s) - a 6h session transcribes in minutes" $null
    } else {
        Say warn "GPU (CUDA)" "none visible - CPU still works, just slower" "Optional. Nothing to fix unless transcription feels too slow."
    }
}

# --- 6. Whisper model cached (offline readiness) -----------------------------
$hf = Join-Path $env:USERPROFILE ".cache\huggingface\hub"
$models = @()
if (Test-Path $hf) { $models = Get-ChildItem $hf -Directory | Where-Object { $_.Name -match "whisper" } }
if ($models) {
    Say ok "Whisper models cached" (($models.Name -replace "models--Systran--faster-whisper-", "") -join ", ") $null
} else {
    Say warn "Whisper models cached" "none - the FIRST transcription needs internet" "Run one transcription now while you have wifi; after that it is fully offline."
}

# --- 7. folders + disk -------------------------------------------------------
foreach ($d in @("recordings", "transcripts")) {
    $p = Join-Path $here $d
    if (-not (Test-Path $p)) { New-Item -ItemType Directory $p | Out-Null }
    try {
        $t = Join-Path $p ".writetest"; Set-Content $t "x" -ErrorAction Stop; Remove-Item $t -ErrorAction Stop
        Say ok "$d\" "writable" $null
    } catch { Say fail "$d\" "NOT writable" "Move the Quill out of a synced/read-only folder." }
}
$drive = (Get-Item $here).PSDrive
$freeGB = [math]::Round($drive.Free / 1GB, 1)
if ($freeGB -ge 5)      { Say ok   "Disk space" "$freeGB GB free (a 6h session is ~250 MB)" $null }
elseif ($freeGB -ge 1)  { Say warn "Disk space" "$freeGB GB free - tight for a long session" "Free up space before a big game." }
else                    { Say fail "Disk space" "$freeGB GB free" "Free up space now - recording will fail mid-session." }

# --- 8. lexicon --------------------------------------------------------------
$lex = Join-Path $here "lexicon.txt"
if (Test-Path $lex) {
    $n = (Get-Content $lex | Where-Object { $_.Trim() -and -not $_.StartsWith("#") }).Count
    if ($n -gt 100) { Say warn "lexicon.txt" "$n names - over the ~80 guideline" "Trim it. Too many hints makes the model chant names over quiet audio." }
    else { Say ok "lexicon.txt" "$n names" $null }
} else { Say warn "lexicon.txt" "missing" "Optional, but it is why the transcript spells your NPCs right." }

# --- 9. regression guard: the crash-safety + VAD fixes are still in place -----
# There are two recorders and they cannot share code: the terminal studio is PowerShell,
# the web studio is Python. So the real risk is DRIFT -- one gets fixed, the other doesn't.
# Check that both carry the flags AND that the flags are the same string.
$ps1  = Get-Content (Join-Path $here "Quill-Studio.ps1")  -Raw
$plat = Get-Content (Join-Path $here "quill_platform.py") -Raw
$srv  = Get-Content (Join-Path $here "quill_server.py")   -Raw
$rxMov = '\+frag_keyframe\+empty_moov\+default_base_moof'
$psHas   = [regex]::IsMatch($ps1,  $rxMov)
$platHas = [regex]::IsMatch($plat, $rxMov)
$srvUses = $srv -match "record_command" -or [regex]::IsMatch($srv, $rxMov)
if ($psHas -and $platHas -and $srvUses) {
    Say ok "Crash-safe recording" "both recorders agree - a hard stop costs seconds, not the session" $null
} else {
    $miss = @()
    if (-not $psHas)   { $miss += "Quill-Studio.ps1" }
    if (-not $platHas) { $miss += "quill_platform.py" }
    if (-not $srvUses) { $miss += "quill_server.py" }
    Say fail "Crash-safe recording" ("missing in: " + ($miss -join ", ")) `
        "Losing power mid-game would leave an unplayable file. Restore the -movflags fragment settings there."
}
$tr = Get-Content (Join-Path $here "transcribe.py") -Raw
if ($tr -match "max_speech_duration_s") {
    Say ok "VAD span cap" "set - long table audio will not collapse into 30s blobs" $null
} else {
    Say fail "VAD span cap" "MISSING" "Without max_speech_duration_s the transcript silently loses most of the session."
}

# --- 10. the analysis toolchain ----------------------------------------------
$tools = @{
    "quill_lib.py"           = "shared reader (the other tools import it)"
    "Mine-Transcript.py"     = "one-session digest        [8]"
    "Quill-Ledger.py"        = "promises & debts          [9]"
    "Quill-Concordance.py"   = "who's-who + search        [9]"
    "Quill-Mirror.py"        = "how you ran it            [9]"
    "Quill-Lexicon.py"       = "lexicon from your notes   [X]"
    "Quill-ColdOpen.py"      = "pre-session cold open     [O]"
    "Quill-Marker.ps1"       = "floating MARK button      [F]"
    "test_quill.py"          = "the regression net (python test_quill.py)"
    "quill_chorus.py"        = "Chorus server (per-voice tracks)"
    "Quill-Chorus.py"        = "Chorus merge              [T]"
    "web\chorus.html"        = "the page players open on their phones"
}
$missing = @($tools.Keys | Where-Object { -not (Test-Path (Join-Path $here $_)) })
if ($missing.Count -eq 0) {
    Say ok "Analysis tools" "all $($tools.Count) present" $null
} else {
    Say warn "Analysis tools" "$($missing.Count) missing: $($missing -join ', ')" `
        "Recording and transcribing still work; only the reports are affected."
}

# --- verdict -----------------------------------------------------------------
Write-Host ("  " + ("-" * 62)) -ForegroundColor DarkGray
if ($fails -gt 0) {
    Write-Host "  NOT READY - $fails blocking problem(s)." -ForegroundColor Red
} elseif ($warns -gt 0) {
    Write-Host "  READY TO RECORD - $warns advisory note(s) above." -ForegroundColor Yellow
} else {
    Write-Host "  READY TO RECORD." -ForegroundColor Green
}
Write-Host ""
# Only pause when a human is actually watching. Piped or captured (or called
# from Setup-Quill.ps1) this throws in NonInteractive mode.
# Pause only when a human is actually at the console. IsInputRedirected is the
# reliable signal: piped, captured, or launched from Setup-Quill.ps1 it is true,
# and Read-Host would either throw or hang forever waiting on a stdin nobody owns.
if (-not [Console]::IsInputRedirected) {
    try { Read-Host "  press Enter to close" | Out-Null } catch { }
}
