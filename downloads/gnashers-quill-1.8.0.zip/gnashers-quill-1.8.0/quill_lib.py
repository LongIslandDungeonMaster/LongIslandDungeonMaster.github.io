# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
quill_lib — the shared reading brain behind the Quill's analysis tools.

`Mine-Transcript.py`, `Quill-Ledger.py` and `Quill-Concordance.py` all have to answer
the same three questions, and they must answer them the SAME way or their reports
disagree with each other:

    1. what did the table say, and when?              -> load_segments()
    2. is this line story, or is it table talk?       -> in_fiction()
    3. is this word a name, or an ordinary word?      -> name_candidates()

Keeping one copy means a fix to the in-fiction filter improves every report at once.

Stdlib only. Nothing here talks to a network, a model, or a service.
"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))

SEG_RE = re.compile(r"\[(\d{2}):(\d{2}):(\d{2}) -> (\d{2}):(\d{2}):(\d{2})\]\s*(.*)")


def hms(seconds):
    seconds = int(seconds)
    return f"{seconds//3600:02d}:{seconds%3600//60:02d}:{seconds%60:02d}"


def load_segments(path):
    """-> (header_lines, [(start_s, end_s, text), ...]). Tolerates BOMs and bad bytes."""
    head, segs = [], []
    for ln in open(path, encoding="utf-8", errors="replace"):
        s = ln.strip()
        m = SEG_RE.match(s)
        if m:
            a = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
            b = int(m.group(4)) * 3600 + int(m.group(5)) * 60 + int(m.group(6))
            segs.append((a, b, m.group(7).strip()))
        elif s.startswith("#"):
            head.append(ln.rstrip())
    return head, segs


def session_name(path):
    """Transcript filename -> session id. A `_v2`/`_REPAIRED` re-run, a Chorus
    per-voice track (`night__kris`) and the merged `night_chorus` master are all
    copies of the SAME night, and must share one id -- or every cross-session
    report counts a four-voice night six times over.
    (Double underscore is therefore reserved: a session LABELLED `epic__finale`
    would fold into `epic`. Use single separators in labels.)"""
    stem = re.sub(r"\.txt$", "", os.path.basename(path), flags=re.I)
    stem = re.sub(r"(_v\d+|_REPAIRED)$", "", stem, flags=re.I)
    stem = re.sub(r"_chorus$", "", stem, flags=re.I)
    stem = re.sub(r"__[^_]+$", "", stem)
    return stem


def _copy_rank(fname):
    """Which copy of a night gets to represent it? Higher wins.
    0 = one voice of a Chorus night: partial by construction. A single player's
        mostly-silent track read as "the session" wrecks every number downstream
        (the Mirror would report an evening of dead air). Never a session.
    3 = the merged Chorus master -- every voice, on one timeline."""
    low = fname.lower()
    if re.search(r"__[^_]+(_v\d+|_repaired)?\.txt$", low):
        return 0
    if low.endswith("_chorus.txt"):
        return 3
    if re.search(r"(_v\d+|_repaired)\.txt$", low):
        return 2
    return 1


NOTES_FILE = os.path.join(HERE, "NOTES.txt")
DEFAULT_NOTES = "../Campaigns,../World"


def notes_roots(override=""):
    """Where your campaign notes live — asked once, answered for everything.

    Four tools want this and each grew its own flag: --canon on the cold open,
    the concordance and the miner, --notes on the lexicon, all defaulting to
    `../Campaigns,../World`. Those are two folders that exist on nobody's
    machine, so on every real install all four quietly ran in their degraded
    mode -- and two of them then made confident claims about notes they had
    never opened. One file answers it now, and the studio can write that file.

    An explicit override wins; then NOTES.txt; then the historical default, so
    an existing setup keeps working untouched."""
    raw = (override or "").strip()
    if not raw and os.path.exists(NOTES_FILE):
        with open(NOTES_FILE, encoding="utf-8", errors="replace") as f:
            raw = ",".join(ln.strip() for ln in f
                           if ln.strip() and not ln.strip().startswith("#"))
    if not raw:
        raw = DEFAULT_NOTES
    roots = []
    for p in raw.split(","):
        p = p.strip()
        if p:
            roots.append(p if os.path.isabs(p)
                         else os.path.normpath(os.path.join(HERE, p)))
    return roots


def notes_found(roots):
    """Only the roots that are actually there. The difference between 'searched
    and found nothing' and 'never looked' is the whole honesty question."""
    return [r for r in roots if os.path.isdir(r)]


def canon_roots_from_flag(flag):
    """Shared --canon handling: unset means "use the configured notes", an
    explicitly empty string means "don't search notes at all"."""
    if flag is None:
        return notes_roots()
    if not flag.strip():
        return []
    return notes_roots(flag)


def has_segments(path, limit=262144):
    """Does this .txt actually contain a timestamped transcript line?

    `transcripts\\` is a folder people put things in. A README ships in it, and
    a DM will drop session notes there too -- but every cross-session report
    globbed *.txt and took whatever it found, so a notes file silently became
    a "session": it landed in the Concordance as a night, and if it happened to
    be the newest file the Cold Open built from it and failed instead.

    Cheap: a real transcript's first segment sits within a few lines of the top,
    and we stop there. Bounded: a large file that is NOT a transcript is not
    read to its end. The header cannot false-positive -- marked moments are
    written as `#   [00:00:09] ...` and SEG_RE anchors at the line start."""
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            seen = 0
            for line in fh:
                if SEG_RE.match(line):
                    return True
                seen += len(line)
                if seen > limit:
                    return False
    except OSError:
        return False
    return False


def pick_transcripts(folder):
    """Every transcript, but only the BEST copy of each session: the merged
    `_chorus` master beats a `_v2` re-run beats the plain single-mic transcript,
    and a per-voice Chorus track never stands in for a whole night. On equal
    rank the later name wins, so `_v3` still supersedes `_v2`.

    A .txt with no timestamped line is not a transcript at all -- see
    has_segments() -- so notes and READMEs never count as nights."""
    if not os.path.isdir(folder):
        return []
    best = {}
    for f in sorted(os.listdir(folder)):
        if not f.lower().endswith(".txt"):
            continue
        rank = _copy_rank(f)
        if rank == 0:
            continue
        path = os.path.join(folder, f)
        if not has_segments(path):
            continue
        key = session_name(f)
        if key not in best or rank >= best[key][0]:
            best[key] = (rank, path)
    return [best[k][1] for k in sorted(best)]


def load_lexicon(path=None):
    path = path or os.path.join(HERE, "lexicon.txt")
    if not os.path.exists(path):
        return []
    return [l.strip() for l in open(path, encoding="utf-8")
            if l.strip() and not l.startswith("#")]


def lexicon_regex(names):
    if not names:
        return None
    return re.compile("|".join(r"\b" + re.escape(n) + r"\b" for n in names), re.I)


# --- telling story from table talk -------------------------------------------
# Rules chatter, tech support, snacks, the meta layer. Any hit disqualifies a line.
META = re.compile(r"""\b(
 app|laptop|computer|browser|click|clicked|wi-?fi|internet|pdf|json|website|
 link|import|export|download|upload|screen|phone|tab|button|beyond|roll20|
 discord|zoom|foundry|mustard|pizza|beer|soda|snack|bathroom|
 d20|d6|initiative|hit\ points|saving\ throw|advantage|disadvantage|proficiency|
 spell\ slot|subclass|feat|stat\ block|character\ sheet|homebrew|
 transcri|record(ing|er)?|python|server|the\ session|this\ campaign
)\b""", re.I | re.X)

# The DM describing the world. A strong in-fiction signal on its own.
NARRATION = re.compile(r"""\b(
 you\ see|you\ notice|you\ hear|you\ feel|you\ find|
 he\ says|she\ says|they\ say|he'll|she'll|
 explains?\ to\ you|tells?\ you|turns?\ to\ you|looks?\ at\ you|
 in\ front\ of\ you|before\ you|the\ room|the\ street|his\ voice|her\ voice
)\b""", re.I | re.X)


def in_fiction(text, lex_re=None):
    """Three-part filter, no AI:
         reject table-talk vocabulary -> accept narration -> accept your own nouns.
    Measured on a real 5h58m session: 93 raw matches down to 16, nearly all real."""
    if META.search(text):
        return False
    if NARRATION.search(text):
        return True
    return bool(lex_re and lex_re.search(text))


# Capitalised words that are almost never a campaign proper noun.
STOP = set("""
a an the and or but so then than that this these those there here if when while
i i'm i'll i've i'd im id you you're your yours he she it we they them him her his
me my mine our ours their theirs us who whom whose what which why how where
is are was were be been being am do does did doing done have has had having
can could will would shall should may might must
no not yes yeah yep nope nah ok okay oh ah uh um hmm huh well right sure
one two three four five six seven eight nine ten first second third
now just like get got go going gone come came see saw look looking know knew
think thought say said tell told make made take took give gave want wanted need
really actually basically literally maybe probably definitely kind sort lot
good bad great fine nice cool nope wait stop back down up out in on at for with
guys guy man dude thing things stuff time times day days night turn roll rolled
dice hit miss damage save check init initiative round session game play player
players character characters level levels spell spells attack attacks
monday tuesday wednesday thursday friday saturday sunday
january february march april may june july august september october november december
mr mrs ms dr sir lord lady god gods
""".split())

PHRASE_RE = re.compile(r"\b(?:[A-Z][a-z'\-]+\s+){1,2}[A-Z][a-z'\-]+\b")
WORD_RE = re.compile(r"\b[A-Za-z][A-Za-z'\-]+\b")


def name_candidates(segs, known=None, min_len=3):
    """Proper-noun candidates -> (singles, phrases, ctx).

    Counted ONCE PER SEGMENT, never once per utterance. A hallucination loop
    ("Kha'Ziul, Kha'Ziul, Kha'Ziul, Kha'Ziul") sits inside one segment; per-utterance
    counting would rank that above a real name said twice an hour apart.
    """
    from collections import Counter
    known = {k.lower() for k in (known or [])}
    known |= {w.lower() for k in (known or []) for w in re.split(r"[\s'\-]+", k) if w}
    singles, phrases, ctx = Counter(), Counter(), {}

    for a, _b, text in segs:
        seen = set()
        for sent in re.split(r"(?<=[.!?])\s+", text):
            for i, tok in enumerate(WORD_RE.findall(sent)):
                if not tok[0].isupper() or i == 0:      # sentence-initial: no signal
                    continue
                low = tok.lower()
                if low in STOP or low in known or len(tok) < min_len:
                    continue
                if tok not in seen:
                    singles[tok] += 1
                    seen.add(tok)
                ctx.setdefault(tok, (a, sent.strip()))
        seen_p = set()
        for run in PHRASE_RE.findall(text):
            words = run.split()
            if any(w.lower() in STOP for w in words):
                continue
            if all(w.lower() in known for w in words):
                continue
            if run not in seen_p:
                phrases[run] += 1
                seen_p.add(run)
            ctx.setdefault(run, (a, text.strip()))
    return singles, phrases, ctx


def canon_index(roots):
    """Slurp campaign notes so we can ask whether a name is already written down."""
    import glob
    blobs = []
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        for p in glob.glob(os.path.join(root, "**", "*"), recursive=True):
            if os.path.isfile(p) and os.path.splitext(p)[1].lower() in (".md", ".txt", ".html"):
                try:
                    blobs.append(open(p, encoding="utf-8", errors="ignore").read())
                except Exception:
                    pass
    return "\n".join(blobs) if blobs else None


def canon_hits(name, canon):
    """Count only MID-SENTENCE capitalised occurrences.

    Case-sensitive, because a proper noun is capitalised in your notes and "house" is
    not. Mid-sentence only, because "House", "Beyond" and "Dying" are capitalised
    constantly in headings and table cells -- a real name also appears mid-sentence,
    preceded by an ordinary word."""
    return len(re.findall(r"(?<=[a-z,;)]\s)" + re.escape(name) + r"\b", canon))
