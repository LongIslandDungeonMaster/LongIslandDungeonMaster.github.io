﻿# SPDX-License-Identifier: MIT
# Quill-Marker.ps1 — a floating MARK button that stays on top of everything.
#
# WHY THIS EXISTS
#   [M] in the terminal studio only works while that window has focus. You run your game
#   from the Grimoire, or your notes, or a browser — so you never press it. The 5h58m
#   session on 2026-07-19 ended with ZERO marks, which is the whole feature going unused.
#
#   This is a small always-on-top window with one big button. Leave it in a corner over
#   whatever you're actually looking at. Click it when something lands.
#
# IMPORTANT: this is a SEPARATE process. It never touches ffmpeg or the recording.
#   If it crashes, closes, or you never open it, your recording is completely unaffected.
#   It only appends lines to the same recordings\<session>.markers.txt the studio uses,
#   so transcribe.py picks them up into the transcript header exactly the same way.
#
#   Start your recording first (terminal studio [1] or the web studio), then run this.
#
#   Right-click -> Run with PowerShell, or from the studio menu.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$here       = Split-Path -Parent $MyInvocation.MyCommand.Path
$recordings = Join-Path $here "recordings"

function Get-ActiveSession {
    <# The session being recorded right now = the .m4a that is still growing.
       We compare size across a short window; a finished file does not change. #>
    if (-not (Test-Path $recordings)) { return $null }
    $newest = Get-ChildItem $recordings -Filter *.m4a -ErrorAction SilentlyContinue |
              Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $newest) { return $null }
    # If it hasn't been written to in the last 60s, treat it as finished, not live.
    if ((Get-Date) - $newest.LastWriteTime -gt [TimeSpan]::FromSeconds(60)) {
        return [pscustomobject]@{ File = $newest; Live = $false }
    }
    return [pscustomobject]@{ File = $newest; Live = $true }
}

$session = Get-ActiveSession
if (-not $session) {
    [System.Windows.Forms.MessageBox]::Show(
        "No recording found in recordings\.`n`nStart a recording first, then run this.",
        "Gnasher's Quill - Marker") | Out-Null
    return
}

$audio     = $session.File
$markFile  = Join-Path $recordings ($audio.BaseName + ".markers.txt")
# The recording started when the file was created.
$startTime = $audio.CreationTime

$form                 = New-Object System.Windows.Forms.Form
$form.Text            = "Quill - MARK"
$form.Size            = New-Object System.Drawing.Size(250, 218)
$form.TopMost         = $true
$form.FormBorderStyle = "FixedToolWindow"
$form.StartPosition   = "Manual"
$wa                   = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Location        = New-Object System.Drawing.Point(($wa.Width - 270), 40)
$form.BackColor       = [System.Drawing.Color]::FromArgb(28, 24, 18)

$lblSession           = New-Object System.Windows.Forms.Label
$lblSession.Text      = $audio.BaseName
$lblSession.ForeColor = [System.Drawing.Color]::FromArgb(176, 137, 74)
$lblSession.Font      = New-Object System.Drawing.Font("Segoe UI", 7)
$lblSession.Location  = New-Object System.Drawing.Point(10, 6)
$lblSession.Size      = New-Object System.Drawing.Size(225, 14)
$form.Controls.Add($lblSession)

$lblTime              = New-Object System.Windows.Forms.Label
$lblTime.ForeColor    = [System.Drawing.Color]::FromArgb(150, 150, 150)
$lblTime.Font         = New-Object System.Drawing.Font("Consolas", 9)
$lblTime.Location     = New-Object System.Drawing.Point(10, 22)
$lblTime.Size         = New-Object System.Drawing.Size(225, 16)
$form.Controls.Add($lblTime)

$btn                  = New-Object System.Windows.Forms.Button
$btn.Text             = "MARK"
$btn.Font             = New-Object System.Drawing.Font("Segoe UI", 15, [System.Drawing.FontStyle]::Bold)
$btn.Location         = New-Object System.Drawing.Point(10, 42)
$btn.Size             = New-Object System.Drawing.Size(225, 58)
$btn.BackColor        = [System.Drawing.Color]::FromArgb(184, 142, 72)
$btn.ForeColor        = [System.Drawing.Color]::FromArgb(20, 16, 12)
$btn.FlatStyle        = "Flat"
$form.Controls.Add($btn)

$txtNote              = New-Object System.Windows.Forms.TextBox
$txtNote.Location     = New-Object System.Drawing.Point(10, 106)
$txtNote.Size         = New-Object System.Drawing.Size(225, 22)
$txtNote.BackColor    = [System.Drawing.Color]::FromArgb(44, 38, 30)
$txtNote.ForeColor    = [System.Drawing.Color]::White
$txtNote.BorderStyle  = "FixedSingle"
$form.Controls.Add($txtNote)

$lblHint              = New-Object System.Windows.Forms.Label
$lblHint.Text         = "optional note - press Enter to mark"
$lblHint.ForeColor    = [System.Drawing.Color]::FromArgb(110, 110, 110)
$lblHint.Font         = New-Object System.Drawing.Font("Segoe UI", 7)
$lblHint.Location     = New-Object System.Drawing.Point(10, 131)
$lblHint.Size         = New-Object System.Drawing.Size(225, 14)
$form.Controls.Add($lblHint)

$btnUndo              = New-Object System.Windows.Forms.Button
$btnUndo.Text         = "undo last pin"
$btnUndo.Font         = New-Object System.Drawing.Font("Segoe UI", 8)
$btnUndo.Location     = New-Object System.Drawing.Point(10, 148)
$btnUndo.Size         = New-Object System.Drawing.Size(225, 24)
$btnUndo.BackColor    = [System.Drawing.Color]::FromArgb(44, 38, 30)
$btnUndo.ForeColor    = [System.Drawing.Color]::FromArgb(150, 132, 96)
$btnUndo.FlatStyle    = "Flat"
$form.Controls.Add($btnUndo)

$script:count = 0

function Undo-Mark {
    <# One tap, at a table, in the dark -- a mistap was permanent.
       The FILE is the authority, never an in-memory count: the studio window
       writes this same file, so rebuilding from disk is what stops the two
       faces resurrecting each other's deleted lines. #>
    if (-not (Test-Path $markFile)) { $lblHint.Text = "nothing to take back"; return }
    $lines = @(Get-Content -Path $markFile -Encoding UTF8 | Where-Object { $_.Trim() })
    if ($lines.Count -eq 0) { $lblHint.Text = "nothing to take back"; return }
    $gone = $lines[-1]
    $keep = if ($lines.Count -gt 1) { $lines[0..($lines.Count - 2)] } else { @() }
    Set-Content -Path $markFile -Value $keep -Encoding UTF8
    $script:count      = $keep.Count
    $lblHint.Text      = "took back $gone"
    $lblHint.ForeColor = [System.Drawing.Color]::FromArgb(220, 150, 255)
}

$btnUndo.Add_Click({ Undo-Mark })

function Add-Mark {
    $elapsed = (Get-Date) - $startTime
    $stamp   = "{0:00}:{1:00}:{2:00}" -f [int]$elapsed.TotalHours, $elapsed.Minutes, $elapsed.Seconds
    $note    = $txtNote.Text.Trim()
    $line    = if ($note) { "[$stamp] $note" } else { "[$stamp]" }
    # utf8 (no BOM would be nicer, but transcribe.py reads utf-8-sig, so either works)
    Add-Content -Path $markFile -Value $line -Encoding UTF8
    $script:count++
    $txtNote.Clear()
    $lblHint.Text      = "marked $stamp  ($script:count this session)"
    $lblHint.ForeColor = [System.Drawing.Color]::FromArgb(140, 190, 130)
    # flash so you get confirmation without looking away from the table
    $btn.BackColor = [System.Drawing.Color]::FromArgb(140, 190, 130)
    $flash = New-Object System.Windows.Forms.Timer
    $flash.Interval = 220
    $flash.Add_Tick({ $btn.BackColor = [System.Drawing.Color]::FromArgb(184, 142, 72); $flash.Stop(); $flash.Dispose() })
    $flash.Start()
}

$btn.Add_Click({ Add-Mark })
$txtNote.Add_KeyDown({ if ($_.KeyCode -eq "Enter") { $_.SuppressKeyPress = $true; Add-Mark } })

$tick = New-Object System.Windows.Forms.Timer
$tick.Interval = 1000
$tick.Add_Tick({
    $e = (Get-Date) - $startTime
    $live = ((Get-Date) - (Get-Item $audio.FullName).LastWriteTime) -lt [TimeSpan]::FromSeconds(60)
    $lblTime.Text = ("{0:00}:{1:00}:{2:00}" -f [int]$e.TotalHours, $e.Minutes, $e.Seconds) +
                    $(if ($live) { "   ● recording" } else { "   ○ not recording" })
    $lblTime.ForeColor = if ($live) { [System.Drawing.Color]::FromArgb(150,150,150) }
                         else       { [System.Drawing.Color]::FromArgb(190,110,110) }
})
$tick.Start()

[void]$form.ShowDialog()
$tick.Stop()
