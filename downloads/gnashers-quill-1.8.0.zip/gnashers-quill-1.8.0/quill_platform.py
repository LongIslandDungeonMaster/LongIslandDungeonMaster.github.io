# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
quill_platform — the only file that knows what operating system this is.

Everything else in the Quill is already portable: the transcriber, the whole analysis
toolchain and the Chorus server are plain Python. Three things are not, and they all
live here so they can be fixed in one place:

    finding ffmpeg          Windows hides it under WinGet; mac/Linux put it on PATH
    listing microphones     dshow / avfoundation / pulse all report differently
    the ffmpeg input flags  -f dshow -i audio=NAME  vs  -f avfoundation -i :0

WHAT IS AND ISN'T TESTED
    The Windows path is the one this was built and measured on. The macOS and Linux
    paths are written to the documented ffmpeg interfaces but have NOT been run on
    those machines -- see `probe()`, which is the one command to run first on a new
    platform. Saying that plainly is worth more than a confident guess.
"""
import glob
import os
import re
import shutil
import subprocess
import sys

WINDOWS = sys.platform.startswith("win")
MACOS = sys.platform == "darwin"
LINUX = sys.platform.startswith("linux")

PLATFORM = "windows" if WINDOWS else "macos" if MACOS else "linux" if LINUX else "unknown"


def find_ffmpeg():
    """ffmpeg, wherever this machine keeps it."""
    ff = shutil.which("ffmpeg")
    if ff:
        return ff
    cands = []
    if WINDOWS:
        cands.append(os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe"))
        cands += glob.glob(os.path.expandvars(
            r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\**\ffmpeg.exe"), recursive=True)
        cands.append(r"C:\ffmpeg\bin\ffmpeg.exe")
    else:
        # Homebrew (both silicon and intel prefixes), MacPorts, and the usual Linux spots.
        cands += ["/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg",
                  "/opt/local/bin/ffmpeg", "/usr/bin/ffmpeg", "/snap/bin/ffmpeg"]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def install_hint():
    """The exact command to type when ffmpeg is missing."""
    if WINDOWS:
        return "winget install Gyan.FFmpeg"
    if MACOS:
        return "brew install ffmpeg"
    return "sudo apt install ffmpeg     (or your distro's equivalent)"


def _run_devices(ff, args):
    """ffmpeg prints its device list to STDERR and exits non-zero. Both are expected."""
    try:
        p = subprocess.run([ff, "-hide_banner"] + args,
                           capture_output=True, text=True, timeout=20)
        return (p.stderr or "") + (p.stdout or "")
    except (OSError, subprocess.SubprocessError):
        return ""


def list_mics(ff):
    """-> [(id, label)]. `id` is what to hand back to input_args()."""
    if not ff:
        return []
    if WINDOWS:
        out = _run_devices(ff, ["-list_devices", "true", "-f", "dshow", "-i", "dummy"])
        names = re.findall(r'"([^"]+)"\s*\(audio\)', out)
        return [(n, n) for n in dict.fromkeys(names)]
    if MACOS:
        # avfoundation lists audio devices by INDEX, after an "AVFoundation audio devices:"
        # header. The index is what -i takes, not the name.
        out = _run_devices(ff, ["-f", "avfoundation", "-list_devices", "true", "-i", ""])
        block = out.split("audio devices:")[-1] if "audio devices:" in out else ""
        return [(idx, label.strip())
                for idx, label in re.findall(r"\[(\d+)\]\s+(.+)", block)]
    # Linux: prefer PulseAudio/PipeWire, which almost everything runs today.
    if shutil.which("pactl"):
        try:
            p = subprocess.run(["pactl", "list", "short", "sources"],
                               capture_output=True, text=True, timeout=10)
            out = []
            for line in (p.stdout or "").splitlines():
                cols = line.split("\t")
                if len(cols) >= 2 and not cols[1].endswith(".monitor"):
                    out.append((cols[1], cols[1]))
            if out:
                return out
        except (OSError, subprocess.SubprocessError):
            pass
    return [("default", "default (ALSA)")]


def default_mic(ff):
    mics = list_mics(ff)
    return mics[0][0] if mics else None


def input_args(mic):
    """The ffmpeg flags that open `mic` for recording on this platform."""
    if WINDOWS:
        return ["-f", "dshow", "-i", f"audio={mic}"]
    if MACOS:
        # avfoundation wants "video:audio"; a leading colon means audio only.
        return ["-f", "avfoundation", "-i", f":{mic}"]
    if shutil.which("pactl"):
        return ["-f", "pulse", "-i", str(mic)]
    return ["-f", "alsa", "-i", str(mic)]


# Written once so the terminal studio, the web studio and the Chorus can never drift
# apart on the thing that decides whether a crash costs you the night.
CRASH_SAFE_ARGS = [
    "-movflags", "+frag_keyframe+empty_moov+default_base_moof",
    "-frag_duration", "2000000", "-flush_packets", "1",
]

ENCODE_ARGS = ["-ac", "1", "-ar", "16000", "-c:a", "aac", "-b:a", "96k"]


def record_command(ff, mic, out_path):
    """The full ffmpeg command for a session recording, on any platform."""
    return ([ff, "-hide_banner", "-loglevel", "error", "-nostats"]
            + input_args(mic) + ENCODE_ARGS + CRASH_SAFE_ARGS + [str(out_path)])


def probe():
    """Run this first on a machine the Quill has not been tried on:

        python quill_platform.py

    It reports what was detected and prints the exact record command it would use,
    so a wrong guess is visible in one line instead of at 7pm on game night."""
    ff = find_ffmpeg()
    print(f"platform      : {PLATFORM} ({sys.platform})")
    print(f"python        : {sys.version.split()[0]}")
    print(f"ffmpeg        : {ff or 'NOT FOUND  ->  ' + install_hint()}")
    if not ff:
        return 1
    mics = list_mics(ff)
    if mics:
        print(f"microphones   : {len(mics)}")
        for i, (mid, label) in enumerate(mics):
            print(f"   {'*' if i == 0 else ' '} id={mid!r:<28} {label}")
    else:
        print("microphones   : NONE DETECTED")
        print("                On Linux install pulseaudio-utils, or pass a device explicitly.")
        return 1
    print("\nwould record with:")
    print("   " + " ".join(record_command(ff, mics[0][0], "recordings/example.m4a")))
    try:
        from faster_whisper import __version__ as fw
        print(f"\nfaster-whisper: {fw}")
    except ImportError:
        print("\nfaster-whisper: NOT INSTALLED  ->  "
              f"{os.path.basename(sys.executable)} -m pip install faster-whisper")
        return 1
    print("\nlooks runnable.")
    return 0


if __name__ == "__main__":
    raise SystemExit(probe())
