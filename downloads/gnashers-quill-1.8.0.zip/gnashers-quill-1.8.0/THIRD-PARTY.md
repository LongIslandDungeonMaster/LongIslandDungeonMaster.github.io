# Third-party software

Gnasher's Quill is MIT-licensed (see [`LICENSE`](LICENSE)). It **bundles nothing** — no
libraries, no binaries, no models are shipped inside the release. The installers ask your
own package manager and `pip` to fetch what's needed, and the speech model downloads itself
on first use.

That matters, because it's the difference between "you must comply with these licenses" and
"these are simply things installed on your machine."

## What the Quill asks your machine to install

| | license | how it arrives | bundled? |
|---|---|---|---|
| [**ffmpeg**](https://ffmpeg.org/) | LGPL-2.1-or-later, or GPL-2.0-or-later depending on build | `winget` / `brew` / `apt` | **no** |
| [**faster-whisper**](https://github.com/SYSTRAN/faster-whisper) | MIT | `pip` | no |
| [**CTranslate2**](https://github.com/OpenNMT/CTranslate2) | MIT | `pip`, via faster-whisper | no |
| **Whisper model weights** (`Systran/faster-whisper-*`) | MIT | downloaded on first transcription | no |
| **Silero VAD** (used by faster-whisper) | MIT | ships inside faster-whisper | no |
| **Python standard library** | PSF | you already have it | no |

Everything the Quill itself contains is plain Python, PowerShell, shell and HTML written
for this project.

## ⚠ If you ever bundle ffmpeg, read this first

The one thing that would change the picture is shipping an `ffmpeg.exe` inside the download
to save people an install step. **Don't do that casually.**

- ffmpeg is **LGPL-2.1-or-later** in its default build, and **GPL-2.0-or-later** if compiled
  with GPL components (many popular Windows builds, including common `Gyan.FFmpeg`
  configurations, are GPL builds).
- Redistributing a GPL binary alongside your work brings obligations — including offering
  corresponding source — that an MIT project does not otherwise have.
- Keeping ffmpeg as an *installed dependency* rather than a *bundled binary* avoids the
  question entirely, which is why the installers work the way they do.

If you decide a one-download bundle is worth it, check the exact licence of the exact build
you intend to ship, and add its licence text and source offer to the release. This is not
legal advice — it's a flag on the one decision that would change your obligations.

## Attribution

If you build on the Quill, the MIT licence asks only that you keep the copyright and
permission notice. Beyond that: no attribution required, no ask.
