# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Ledger — what you owe your players, and what the world owes them.

A campaign does not die because the DM forgot what happened last session. It dies
because in session 4 an NPC said "come back when you have the seal", the players
wrote it down, and the DM never did. This reads every transcript you have and keeps
a running list of the promises, debts and bargains that were actually spoken aloud.

    python Quill-Ledger.py                     # scan every transcript, update LEDGER.md
    python Quill-Ledger.py --session <file>     # just one
    python Quill-Ledger.py --dry-run            # show what it would add, change nothing

HOW IT TELLS STORY FROM TABLE TALK
    A six-hour recording is mostly people talking about laptops and mustard. The
    filter is three-part and needs no AI:
      1. reject anything carrying table-talk vocabulary (app, click, dice, initiative)
      2. accept anything with narration markers ("he says", "you see", "tells you")
      3. accept anything naming something from lexicon.txt -- your own campaign nouns
    Then a fourth filter, which turned out to matter most: reject DM stage
    direction. Measured on the real 5h58m session of 2026-07-19, the earlier
    patterns returned 18 entries of which only 1 was a real open obligation.
    These return 2, and both are real. Expect FEW entries per session -- a
    ledger of 2 things you actually owe beats 18 you have to search.

THE FILE IS YOURS
    LEDGER.md is plain markdown. Tick a box to close an entry, write notes under it,
    delete lines you don't want. Re-running NEVER overwrites your edits: entries are
    keyed by session + timestamp, and anything already in the file keeps its state.
    Deleted entries stay deleted (they are remembered in a comment at the bottom).
"""
import sys, os, re, argparse
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# The in-fiction filter, the segment reader and the session naming all live in
# quill_lib so this tool, Mine-Transcript and the Concordance never drift apart
# and start disagreeing about what counts as story.
from quill_lib import (HERE, hms, load_segments, load_lexicon, lexicon_regex,
                       in_fiction, session_name, pick_transcripts, NARRATION)

# A DM narrating what an NPC WILL DO is grammatically identical to an NPC PROMISING
# something -- "he'll mention the price" vs "he'll pay you". Measured against the real
# 2026-07-19 session, that single ambiguity produced most of the noise: 18 entries of
# which 13 were not commitments at all. Rejecting stage direction first, then demanding
# a genuine commitment shape, took it to 2 entries with none wrong.
NARRATION_FUTURE = re.compile(r"""(
  \b(he|she|they|it)'?ll\s+(also\s+|then\s+|just\s+|kind\ of\s+|probably\s+|likely\s+)?
     (mention|ask|say|be|go|goes|look|turn|nod|walk|come|start|begin|continue|
      describe|explain|tell\ you\ (about|that)|do|have|get\ (a|the)|take\ (a|the)|show)\b
 |\b(i|we)'?ll\s+(cut|say|go\ ahead|read|describe|start|do\ that|call\ it|
      jump|skip|move\ on|come\ back\ to\ that|let)\b
 |\b(he|she|they)'?ll\s+(bring|take|walk|lead|show)\s+you\s+
     (back|around|through|down|up|over|out|in|to\ the|towards?)\b
 |\b(let'?s|let\ me)\s
 |\bthe\ last\ thing\b
)""", re.I | re.X)

CATEGORIES = [
    ("DEBT", re.compile(r"""(
        \b(a|the|his|her|my|your|their|one)\s+(\w+\s+)?(debt|favou?r|bargain|bounty)\b
       |\b(owes?|owed|owing)\s+(you|me|us|him|her|them)\b
       |\b(i|we|he|she|they)\s+owe\b |\byou\s+owe\b
       |\bin\s+exchange\s+for\b
       |\b(name\ your\ price|the\ price\ is|it\ will\ cost|blood\ price)\b
       |\bpay(s|ing)?\s+(you|me|us)\s+back\b
       |\bunder\s+contract\s+that\b
     )""", re.I | re.X)),
    ("PROMISE", re.compile(r"""(
        \byou\s+have\s+my\s+word\b |\bi\s+promise\b |\bi\s+swear\b
       |\bon\s+my\s+(honou?r|life)\b
       |\bif\s+you\s+[^.?!]{3,60}?\b(i|we)'?ll\s+(pay|give|get|bring|make\ sure|see\ to|
            help|find|deliver|owe)\b
       |\b(i|we)'?ll\s+(pay\ you|make\ sure|see\ to\ (it|that)|deliver|
            send\ (you\ word|for\ you)|have\ it\ (ready|done)|
            (bring|give|get)\ you\ (the|a|an|it|his|her|my|our|their|word|one)\b)
       |\b(he|she|they)'?ll\s+(pay\ you|owe|make\ sure|see\ to\ (it|that)|
            send\ (you\ word|for\ you)|
            (bring|give|get)\ you\ (the|a|an|it|his|her|my|our|their|word|one)\b)
       |\bcome\s+back\s+(when|with|and\s+\w+|to\s+me|to\s+us)\b
       |\bmeet\s+(me|us)\s+(at|in|by|near|when|outside)\b
       |\bbring\s+(me|us)\s+(the|a|back|it|his|her)\b
     )""", re.I | re.X)),
    ("THREAT", re.compile(r"""(
        \bor\s+else\b |\blast\s+(warning|chance)\b |\byou'?ll\s+regret\b
       |\bif\s+you\s+(don'?t|fail|refuse|try\s+to)\b
       |\b(i|we|he|she|they)\s+will\s+(kill|hang|burn|hunt|destroy|end)\b
     )""", re.I | re.X)),
]

MARK_RE = re.compile(r"^- \[([ xX])\]\s*`([^`]+)`\s*\*\*(\w+)\*\*\s*(.*)$")






def side(text):
    """Who made the commitment? Without per-speaker tracks this is a heuristic:
    narration means the world spoke; bare first-person future means the party did."""
    if NARRATION.search(text):
        return "world"
    if re.search(r"\b(i'?ll|i\ will|we'?ll|we\ will|i\ promise|i\ swear)\b", text, re.I):
        return "party"
    return "?"


def scan(path, lex_re, min_words):
    """Pull categorised, in-fiction commitments out of one transcript."""
    _head, segs = load_segments(path)
    session = session_name(path)
    found = []
    for i, (t, _end, text) in enumerate(segs):
        if len(text.split()) < min_words:
            continue
        if not in_fiction(text, lex_re):
            continue
        if NARRATION_FUTURE.search(text):     # stage direction, not a promise
            continue
        for name, rx in CATEGORIES:
            if rx.search(text):
                nxt = segs[i + 1][2] if i + 1 < len(segs) else ""
                found.append({
                    "key": f"{session}@{hms(t)}",
                    "cat": name,
                    "side": side(text),
                    "text": text,
                    "next": nxt,
                    "session": session,
                    "t": t,
                })
                break          # one category per line, first match wins
    return found


def parse_ledger(path):
    """Read the existing LEDGER.md. Returns (state_by_key, retired_keys, preamble_notes).

    state_by_key keeps whatever the human did to the line -- the tick box and any
    trailing note -- so a re-run can put it back exactly."""
    state, retired = {}, set()
    if not os.path.exists(path):
        return state, retired
    body = open(path, encoding="utf-8", errors="replace").read()
    m = re.search(r"<!-- retired:\s*(.*?)\s*-->", body, re.S)
    if m:
        retired = {k.strip() for k in m.group(1).split("|") if k.strip()}
    lines = body.splitlines()
    for i, ln in enumerate(lines):
        mm = MARK_RE.match(ln.strip())
        if mm:
            key = mm.group(1), mm.group(2)
            notes = []
            for j in range(i + 1, len(lines)):
                s = lines[j]
                if s.startswith("- [") or s.startswith("#") or s.startswith("<!--"):
                    break
                if s.strip().startswith(">"):      # the quoted line we generate
                    continue
                if s.strip():
                    notes.append(s.rstrip())
            state[mm.group(2)] = {
                "done": mm.group(1).lower() == "x",
                "notes": notes,
            }
    return state, retired


def render(entries, state, retired):
    by_session = {}
    for e in entries:
        by_session.setdefault(e["session"], []).append(e)

    open_n = sum(1 for e in entries if not state.get(e["key"], {}).get("done"))
    L = []
    L.append("# LEDGER — what was promised at this table")
    L.append("")
    L.append("> Built by `Quill-Ledger.py` from your session transcripts. Promises, debts and")
    L.append("> threats that were actually *spoken aloud*, in-fiction only.")
    L.append(">")
    L.append("> **This file is yours to edit.** Tick a box when you've paid it off. Write notes")
    L.append("> under any entry. Delete entries you don't care about — they stay deleted.")
    L.append("> Re-running the script never overwrites your edits.")
    L.append(">")
    L.append("> `world` = an NPC committed to something.  `party` = the players did.")
    L.append("")
    L.append(f"**{open_n} open · {len(entries) - open_n} closed** · last scan {date.today().isoformat()}")
    L.append("")

    for sess in sorted(by_session):
        L.append(f"## {sess}")
        L.append("")
        for cat in ("DEBT", "PROMISE", "THREAT"):
            rows = [e for e in by_session[sess] if e["cat"] == cat]
            if not rows:
                continue
            for e in sorted(rows, key=lambda x: x["t"]):
                st = state.get(e["key"], {})
                box = "x" if st.get("done") else " "
                L.append(f"- [{box}] `{e['key']}` **{e['cat']}** ({e['side']})")
                L.append(f"  > {e['text']}")
                for n in st.get("notes", []):
                    L.append(n)
            L.append("")

    if retired:
        L.append("<!-- retired: " + " | ".join(sorted(retired)) + " -->")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Build the campaign ledger from session transcripts.")
    ap.add_argument("--session", default=None, help="one transcript .txt (default: all of them)")
    # --out deliberately has NO fixed default. It used to default to <Quill>/LEDGER.md,
    # which meant pointing --transcripts at a second campaign silently OVERWROTE the
    # first campaign's ledger with the second one's contents. The output now follows
    # the input: the ledger lands beside the transcripts folder it was built from.
    ap.add_argument("--out", default=None,
                    help="default: LEDGER.md beside the --transcripts folder")
    ap.add_argument("--transcripts", default=os.path.join(HERE, "transcripts"))
    ap.add_argument("--min-words", type=int, default=8, help="ignore lines shorter than this")
    ap.add_argument("--dry-run", action="store_true", help="report only; write nothing")
    a = ap.parse_args()
    if a.out is None:
        a.out = os.path.join(os.path.dirname(os.path.abspath(a.transcripts)),
                             "LEDGER.md")

    lex = load_lexicon()
    lex_re = re.compile("|".join(r"\b" + re.escape(n) + r"\b" for n in lex), re.I) if lex else None

    if a.session:
        files = [a.session]
    else:
        files = pick_transcripts(a.transcripts)

    if not files:
        print("no transcripts found.")
        return 1

    state, retired = parse_ledger(a.out)

    entries, skipped = [], 0
    for f in files:
        for e in scan(f, lex_re, a.min_words):
            if e["key"] in retired:
                skipped += 1
                continue
            entries.append(e)

    # dedupe by key (a line can't be two entries)
    seen, uniq = set(), []
    for e in entries:
        if e["key"] in seen:
            continue
        seen.add(e["key"])
        uniq.append(e)
    entries = uniq

    fresh = [e for e in entries if e["key"] not in state]
    print(f"scanned {len(files)} transcript(s)")
    print(f"  {len(entries)} entries  ({len(fresh)} new, "
          f"{len(entries)-len(fresh)} already in the ledger, {skipped} retired)")
    for e in fresh[:12]:
        print(f"    + [{e['cat']:7}] {e['key']}  {e['text'][:76]}")
    if len(fresh) > 12:
        print(f"    ... and {len(fresh)-12} more")

    if a.dry_run:
        print("\n(dry run - nothing written)")
        return 0

    open(a.out, "w", encoding="utf-8").write(render(entries, state, retired))
    print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
