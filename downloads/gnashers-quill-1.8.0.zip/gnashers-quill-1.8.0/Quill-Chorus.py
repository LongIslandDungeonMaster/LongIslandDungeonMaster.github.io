# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Chorus — braid the per-voice tracks into one transcript that knows who spoke.

    python Quill-Chorus.py                     # newest Chorus session
    python Quill-Chorus.py --session 2026-08-02_1900_saltmere
    python Quill-Chorus.py --model medium.en
    python Quill-Chorus.py --list

Each device recorded ITSELF, so the speaker is known rather than guessed. This
transcribes every track separately, shifts each onto the session timeline using the
offset the server stamped at join, and interleaves them:

    [01:42:08 -> 01:42:13] [DM]      The warden's hands are shaking.
    [01:42:15 -> 01:42:17] [KRIS]    I step between them.
    [01:42:19 -> 01:42:23] [GARTHAX] Bad idea. I ready an action.

WHY THAT EXACT SHAPE
    It is the ordinary Quill segment format with the speaker inside the text, so every
    other tool -- Mine-Transcript, the Ledger, the Concordance, the Mirror -- reads a
    Chorus transcript with no changes at all. The speaker tag is a bonus, not a new format.

A track that failed to upload, or a phone that locked mid-session, costs that voice and
nothing else. The others merge normally and the report says plainly which voice is short.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import hms, load_segments

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

HERE = Path(__file__).resolve().parent
CHORUS_ROOT = HERE / "recordings" / "chorus"
TRANSCRIPTS = HERE / "transcripts"


def sessions():
    if not CHORUS_ROOT.is_dir():
        return []
    out = []
    for d in sorted(CHORUS_ROOT.iterdir()):
        man = d / "chorus.json"
        if man.is_file():
            out.append(d)
    return out


def transcribe_track(audio, out_txt, model):
    """Run the normal engine on one voice's track. Same VAD fixes, same lexicon."""
    cmd = [sys.executable, str(HERE / "transcribe.py"), str(audio),
           "--model", model, "--out", str(out_txt), "--no-log"]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        return False, (p.stderr or p.stdout or "").strip().splitlines()[-1:] or ["failed"]
    return True, []


def main():
    ap = argparse.ArgumentParser(description="Merge Chorus tracks into one speaker-labelled transcript.")
    ap.add_argument("--session", default=None, help="folder name under recordings/chorus/")
    ap.add_argument("--model", default="medium.en")
    ap.add_argument("--out", default=None)
    ap.add_argument("--list", action="store_true", help="list Chorus sessions and exit")
    ap.add_argument("--redo", action="store_true", help="re-transcribe tracks already done")
    a = ap.parse_args()

    all_s = sessions()
    if a.list:
        if not all_s:
            print("no Chorus sessions recorded yet.")
            return 0
        for d in all_s:
            man = json.loads((d / "chorus.json").read_text(encoding="utf-8"))
            who = ", ".join(t["speaker"] for t in man.get("tracks", []))
            print(f"  {d.name:<34} {len(man.get('tracks', []))} voice(s)  {who}")
        return 0

    if not all_s:
        print("no Chorus sessions found under recordings/chorus/.")
        return 1
    folder = (CHORUS_ROOT / a.session) if a.session else all_s[-1]
    man_path = folder / "chorus.json"
    if not man_path.is_file():
        print(f"no chorus.json in {folder}")
        return 1
    man = json.loads(man_path.read_text(encoding="utf-8"))
    tracks = man.get("tracks", [])
    if not tracks:
        print("that session has no tracks.")
        return 1

    print(f"session : {man['session']}")
    print(f"started : {man.get('started_iso','?')}")
    print(f"voices  : {len(tracks)}\n")

    TRANSCRIPTS.mkdir(exist_ok=True)
    merged, notes = [], []

    # The DM's own ffmpeg recording, if the Chorus adopted a live session, is just
    # another voice -- offset 0, because the session clock started with it.
    if man.get("master_file") and Path(man["master_file"]).is_file():
        tracks = [{"speaker": "DM", "path": man["master_file"], "offset_s": 0.0,
                   "bytes": Path(man["master_file"]).stat().st_size}] + tracks

    for t in tracks:
        speaker = (t.get("speaker") or t.get("id") or "voice").upper()
        audio = Path(t["path"])
        off = float(t.get("offset_s") or 0.0)
        if not audio.is_file() or audio.stat().st_size < 2048:
            notes.append(f"{speaker}: no usable audio ({audio.name}) - skipped")
            continue
        out_txt = TRANSCRIPTS / f"{man['session']}__{speaker.lower()}.txt"
        if a.redo or not out_txt.is_file() or out_txt.stat().st_mtime < audio.stat().st_mtime:
            print(f"  transcribing {speaker:<12} ({audio.stat().st_size/1e6:.1f} MB, offset {off:.1f}s) ...")
            ok, err = transcribe_track(audio, out_txt, a.model)
            if not ok:
                notes.append(f"{speaker}: transcription failed - {' '.join(err)}")
                continue
        else:
            print(f"  reusing      {speaker:<12} (already transcribed)")

        _head, segs = load_segments(out_txt)
        if not segs:
            notes.append(f"{speaker}: transcribed to nothing - silent or unreadable track")
            continue
        for s, e, text in segs:
            if text:
                merged.append((s + off, e + off, speaker, text))

    if not merged:
        print("\nnothing to merge.")
        for n in notes:
            print("  ! " + n)
        return 1

    merged.sort(key=lambda r: (r[0], r[2]))
    width = max(len(r[2]) for r in merged)

    out_path = Path(a.out) if a.out else TRANSCRIPTS / f"{man['session']}_chorus.txt"
    voices = sorted({r[2] for r in merged})
    head = [
        f"# Chorus transcript - {man['session']}",
        f"# {len(voices)} voice(s): {', '.join(voices)} | model: {a.model}",
        "# Each voice recorded its own microphone, so the speaker is KNOWN, not inferred.",
        "# Standard Quill segment format - Mine-Transcript, the Ledger, the Concordance",
        "# and the Mirror all read this file unchanged.",
    ]
    if notes:
        head.append("#")
        head.append("# INCOMPLETE:")
        for n in notes:
            head.append(f"#   {n}")
    head.append("")

    lines = [f"[{hms(s)} -> {hms(e)}] [{spk:<{width}}] {txt}" for s, e, spk, txt in merged]
    out_path.write_text("\n".join(head + lines) + "\n", encoding="utf-8")

    print(f"\nmerged {len(merged)} segments from {len(voices)} voice(s)")
    for v in voices:
        n = sum(1 for r in merged if r[2] == v)
        w = sum(len(r[3].split()) for r in merged if r[2] == v)
        print(f"    {v:<12} {n:>5} segments  {w:>7,} words")
    for n in notes:
        print("  ! " + n)
    print(f"\n-> {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
