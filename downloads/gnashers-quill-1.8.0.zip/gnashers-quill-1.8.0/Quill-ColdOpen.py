# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-ColdOpen — the one page you read twenty minutes before the players arrive.

    python Quill-ColdOpen.py                  # from your newest session
    python Quill-ColdOpen.py --session <file>
    python Quill-ColdOpen.py --out COLD-OPEN.md

Every session opens with "right — previously..." and most DMs improvise it from memory,
which is why the callback lands about half the time. Everything needed to do it properly
is already sitting in the Quill; it was just spread across four files. This puts it on
one page, in the order you actually need it:

    1. HOW IT ENDED      the last in-fiction stretch of the night, verbatim.
                         Your cold open is in there, in your own words.
    2. WHAT YOU PINNED   the moments you marked, with the audio just before each.
    3. WHAT YOU OWE      still-open entries from LEDGER.md. The line a player
                         remembers and you don't is the one that kills a campaign.
    4. WHO TURNED UP     names said at the table that are in none of your notes.
                         Write them down before they evaporate.
    5. WHERE THEY LEANED IN   the densest stretch of talk. Whatever that was, they
                         cared about it more than whatever you had prepped.

It invents nothing. Every line is quoted from your own recording, with a timestamp
you can go back and listen to.
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import (HERE, hms, load_segments, load_lexicon, lexicon_regex,
                       canon_roots_from_flag,
                       pick_transcripts, session_name, name_candidates,
                       canon_index, canon_hits, in_fiction, META)

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def closing_beats(segs, lex_re, want=14, minutes=12):
    """The last stretch of the night that was actually in fiction.

    Not simply the final lines: a session ends with "great game everyone", packing up,
    and scheduling. Walk backwards past that and take the last real run of play."""
    def is_play(i):
        t = segs[i][2]
        return (in_fiction(t, lex_re) and not META.search(t) and len(t.split()) >= 5)

    story = [i for i in range(len(segs)) if is_play(i)]
    if not story:
        return segs[-want:]
    end = story[-1]
    # Only quote lines that read as play. An earlier version kept anything merely
    # non-meta, which let "I think it's paladin only" and "we'll go back out and see"
    # into the read-aloud you are about to open the night with. Search back further
    # rather than lower the bar.
    # Bound it in TIME, not in line count. Requiring real play lines means a chatty
    # stretch makes the search reach further and further back, and a cold open that
    # opens on something from half an hour before the end is not a cold open.
    floor = segs[end][0] - minutes * 60
    run = [segs[i] for i in range(len(segs))
           if is_play(i) and segs[i][0] >= floor and i <= end]
    return run[-want:] if run else [segs[end]]


def marks_from(head):
    pins, started = [], False
    for ln in head:
        if "MARKED MOMENT" in ln.upper():
            started = True
            continue
        if not started:
            continue
        m = re.match(r"\[?(\d{1,2}):(\d{2}):(\d{2})\]?\s*(.*)", ln.lstrip("# ").strip())
        if m:
            pins.append((int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3)),
                         m.group(4).strip()))
    return pins


def open_ledger_entries(path, session):
    """Unticked entries, this session first, then anything else still owed."""
    if not os.path.exists(path):
        return [], []
    body = open(path, encoding="utf-8", errors="replace").read()
    mine, older = [], []
    for m in re.finditer(r"- \[( )\] `([^`]+)` \*\*(\w+)\*\* \((\w+|\?)\)\n  > (.*)", body):
        key, cat, side, text = m.group(2), m.group(3), m.group(4), m.group(5)
        (mine if key.startswith(session) else older).append((key, cat, side, text))
    return mine, older


def densest(segs, window=180):
    best, at = 0, None
    if not segs:
        return None
    for s in range(0, int(segs[-1][1]), window // 2):
        w = sum(len(t.split()) for a, _b, t in segs if s <= a < s + window)
        if w > best:
            best, at = w, s
    return at


def main():
    ap = argparse.ArgumentParser(description="Build the pre-session cold open sheet.")
    ap.add_argument("--session", default=None, help="a transcript .txt (default: newest)")
    ap.add_argument("--transcripts", default=os.path.join(HERE, "transcripts"))
    ap.add_argument("--ledger", default=os.path.join(HERE, "LEDGER.md"))
    ap.add_argument("--out", default=None, help="default: COLD-OPEN.md beside the transcripts")
    ap.add_argument("--canon", default=None,
                    help='campaign-note folders. Unset uses NOTES.txt; "" skips them.')
    ap.add_argument("--beats", type=int, default=14, help="how many closing lines to quote")
    ap.add_argument("--minutes", type=int, default=12,
                    help="how far back from the end of play to look for those lines "
                         "(default 12). Widen it if your last scene was slow.")
    a = ap.parse_args()

    if a.session:
        path = a.session
    else:
        files = pick_transcripts(a.transcripts)
        if not files:
            print("no transcripts yet - record and transcribe a session first.")
            return 1
        path = max(files, key=os.path.getmtime)
    if a.out is None:
        a.out = os.path.join(os.path.dirname(os.path.abspath(a.transcripts)), "COLD-OPEN.md")

    head, segs = load_segments(path)
    if not segs:
        print(f"{os.path.basename(path)} has no timestamped segments.")
        return 1
    sess = session_name(path)
    lexicon = load_lexicon()
    lex_re = lexicon_regex(lexicon)

    L = [f"# COLD OPEN — before your next session", ""]
    L.append(f"*Built from `{os.path.basename(path)}` ({hms(segs[-1][1])} recorded). "
             f"Everything below is quoted from that recording — nothing here is invented.*")
    L.append("")

    # 1 -----------------------------------------------------------------
    L.append("## 1. How it ended")
    L.append("")
    L.append("*The last stretch of actual play, in your own words. Your \"previously…\" is in here.*")
    L.append("")
    for a_, b_, t in closing_beats(segs, lex_re, a.beats, a.minutes):
        L.append(f"> **[{hms(a_)}]** {t}")
        L.append(">")
    L.append("")

    # 2 -----------------------------------------------------------------
    pins = marks_from(head)
    L.append(f"## 2. What you pinned — {len(pins)}")
    L.append("")
    if pins:
        for t, note in pins:
            L.append(f"### [{hms(t)}]" + (f" — {note}" if note else ""))
            L.append("")
            for x, y, txt in segs:
                if t - 75 <= y <= t + 10 and len(txt.split()) >= 4:
                    L.append(f"> **[{hms(x)}]** {txt}")
            L.append("")
    else:
        L.append("*Nothing was marked. `[M]` at the table, or the floating button `[F]`, is "
                 "what makes a six-hour recording searchable — press it when something lands.*")
        L.append("")

    # 3 -----------------------------------------------------------------
    mine, older = open_ledger_entries(a.ledger, sess)
    L.append(f"## 3. What you still owe — {len(mine) + len(older)} open")
    L.append("")
    if mine or older:
        L.append("*Spoken aloud, in fiction, and not yet ticked off in `LEDGER.md`. "
                 "The one a player remembers and you don't is the one that costs you.*")
        L.append("")
        for key, cat, side, text in mine + older:
            when = key.rsplit("@", 1)[-1]
            whose = {"world": "an NPC promised this", "party": "the party promised this"}.get(side, "unclear who")
            L.append(f"- **{cat}** · `{when}` · *{whose}*")
            L.append(f"  > {text}")
        L.append("")
    else:
        L.append("*Nothing open. Either a clean slate, or nobody committed to anything out loud.*")
        L.append("")

    # 4 -----------------------------------------------------------------
    singles, phrases, ctx = name_candidates(segs, known=lexicon)
    cand = {}
    cand.update({p: n * 2 for p, n in phrases.items()})
    for w, n in singles.items():
        cand[w] = max(cand.get(w, 0), n)
    parts = {w for k in cand if " " in k for w in k.split()}
    cand = {k: v for k, v in cand.items() if " " in k or k not in parts}

    roots = canon_roots_from_flag(a.canon)
    canon = canon_index(roots) if roots else None
    fresh = [(k, v) for k, v in sorted(cand.items(), key=lambda x: -x[1])
             if v >= 3 and (not canon or canon_hits(k, canon) < 3)][:10]

    # canon_index() returns None when the notes folders don't exist -- which is the
    # normal case on a machine that isn't where the campaign is written. This section
    # used to assert "present in none of your campaign files" and, when the list came
    # back empty, "your notes are keeping up with your table" -- both claims about
    # notes that were never opened. The whole sheet's worth is that it invents
    # nothing, so it has to say which question it actually answered.
    checked = canon is not None
    L.append("## 4. Who turned up that you never wrote down" if checked
             else "## 4. The names your table said most")
    L.append("")
    if not checked:
        L.append("*No campaign notes were searched, so this cannot tell "
                 "**already written down** from **new at the table** — these are simply the "
                 "names said most often. Point `--canon` at your notes folder and this "
                 "section starts doing the real job.*")
        L.append("")
    if fresh:
        if checked:
            L.append("*Said repeatedly at the table and present in none of your campaign "
                     "files. Some are your players' real names — prune those and keep the rest.*")
            L.append("")
        for k, n in fresh:
            t, line = ctx.get(k, (0, ""))
            L.append(f"- **{k}** ×{n} — first at `{hms(t)}`")
            L.append(f"  > {line[:170]}")
        L.append("")
    else:
        L.append("*Nothing new — your notes are keeping up with your table.*" if checked
                 else "*No name was said often enough to be worth listing.*")
        L.append("")

    # 5 -----------------------------------------------------------------
    at = densest(segs)
    if at is not None:
        L.append("## 5. Where they leaned in")
        L.append("")
        L.append(f"The densest three minutes of the night began at **[{hms(at)}]**. "
                 f"Whatever that was, they cared about it more than whatever you had prepped — "
                 f"so it is the safest thing to open on.")
        L.append("")
        for x, y, t in segs:
            if at <= x < at + 100 and len(t.split()) >= 5:
                L.append(f"> **[{hms(x)}]** {t}")
        L.append("")

    L.append("---")
    L.append("")
    L.append("*Gnasher's Quill — the Quill records → the Grimoire holds → the Satchel carries.*")

    open(a.out, "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"cold open for {sess}")
    print(f"  closing beats : {a.beats}")
    print(f"  marks         : {len(pins)}")
    print(f"  open debts    : {len(mine) + len(older)}")
    print(f"  unwritten     : {len(fresh)}")
    print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
