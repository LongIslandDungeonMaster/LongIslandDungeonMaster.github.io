# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Mine-Transcript — turn a raw session transcript into something you can actually use.

The Quill records and transcribes. That leaves you with 120 KB of unpunctuated
table talk, which nobody reads. This is the missing step: it reads the transcript
FOR the four things worth stealing, and tells you if the transcript is even sound.

    python Mine-Transcript.py transcripts/<session>.txt
    python Mine-Transcript.py transcripts/<session>.txt --out digest.md
    python Mine-Transcript.py transcripts/          # newest transcript in the folder

WHAT IT REPORTS

  1. HEALTH      Did the transcription actually capture the room, or did the
                 voice-activity detector swallow it? (See the 2026-07-30 fix in
                 transcribe.py.) A transcript with a ~30s median segment is about
                 a third of your session wearing a transcript's clothes.
  2. MARKS       Every moment you pinned with [M], with the audio BEFORE it --
                 marks are retroactive, so the beat sits behind the pin.
  3. NEW NAMES   Proper nouns your table said that are NOT in lexicon.txt. This is
                 the good stuff: the nicknames they invented, the NPCs you never
                 named. Paste-ready, because adding them to lexicon.txt makes the
                 NEXT transcription spell them right.
  4. HOT         The densest stretches of talk -- where the table leaned in.

Stdlib only. Nothing leaves the machine.
"""
import sys, os, re, argparse, statistics
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import (hms, load_segments as load, load_lexicon, lexicon_regex,
                       name_candidates, canon_index, canon_hits, STOP,
                       canon_roots_from_flag)

# The Windows console defaults to cp1252 and mangles the em-dashes/multiplication
# signs in this report. Ask for UTF-8; harmless everywhere else.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def health(segs):
    """The collapse check. Returns (verdict, [lines])."""
    out = []
    durs = [b - a for a, b, _ in segs]
    if not durs:
        return "EMPTY", ["no timestamped segments found - is this a Quill transcript?"]
    med = statistics.median(durs)
    words = sum(len(t.split()) for _, _, t in segs)
    span = sum(durs) or 1
    starved = [(a, b, t) for a, b, t in segs if b - a >= 20 and len(t.split()) <= 3]
    loops = 0
    for a, b, t in segs:
        w = t.split()
        for n in (2, 3, 4):
            g = [" ".join(w[i:i+n]) for i in range(len(w)-n+1)]
            if g and max([g.count(x) for x in set(g)] + [0]) >= 3:
                loops += 1
                break

    out.append(f"segments {len(segs)}  |  median segment {med:.1f}s  |  "
               f"{words:,} words  |  {words/span:.2f} words/sec of speech")

    if med >= 20:
        verdict = "BAD"
        out.append(f"!! median segment is {med:.0f}s. Natural speech runs 5-10s. The voice-activity")
        out.append("   detector merged long runs of room noise into single spans and the model")
        out.append("   returned one line for each. You are reading a fraction of this session.")
        out.append("   FIX: re-transcribe. transcribe.py now caps spans (--max-speech 20).")
    elif med >= 12:
        verdict = "SUSPECT"
        out.append(f"~  median segment {med:.0f}s is high. Noisy room. Consider --max-speech 12.")
    else:
        verdict = "GOOD"
        out.append("   segment length looks like real speech.")

    if starved:
        out.append(f"!! {len(starved)} segment(s) swallow 20s+ of audio and return <=3 words. Worst:")
        for a, b, t in sorted(starved, key=lambda s: -(s[1]-s[0]))[:3]:
            out.append(f'     [{hms(a)}] {b-a:.0f}s -> "{t}"')
    if loops:
        out.append(f"~  {loops} segment(s) contain a repeated phrase 3+ times - check for")
        out.append("   hallucination loops (the model chanting instead of transcribing).")
    return verdict, out


def marks(head, segs, lookback):
    """Marks are retroactive: show the audio BEFORE each pin.

    Only read lines AFTER the 'MARKED MOMENTS' banner. Scanning the whole header is
    wrong: the `# source: ... | duration: 05:57:55` line also contains an hh:mm:ss,
    and it was being reported as a mark at exactly the session length -- so a session
    with NO marks looked like it had one, pointing at the last seconds of the night."""
    pins = []
    started = False
    for ln in head:
        if "MARKED MOMENT" in ln.upper():
            started = True
            continue
        if not started:
            continue
        m = re.match(r"\[?(\d{1,2}):(\d{2}):(\d{2})\]?\s*(.*)", ln.lstrip("# ").strip())
        if m:
            t = int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3))
            pins.append((t, m.group(4).strip()))
    out = []
    for t, note in pins:
        out.append(f"\n### [{hms(t)}]" + (f" — {note}" if note else ""))
        out.append(f"*(the beat is in the {lookback}s before this pin)*\n")
        for a, b, txt in segs:
            if t - lookback <= b <= t + 15 and txt:
                out.append(f"  [{hms(a)}] {txt}")
    return pins, out



def hot(segs, window=180, top=5):
    """Densest talk windows -- where the table leaned in."""
    if not segs:
        return []
    end = segs[-1][1]
    scored = []
    for start in range(0, int(end), window // 2):
        w = [t for a, b, t in segs if start <= a < start + window]
        if w:
            scored.append((sum(len(x.split()) for x in w), start))
    scored.sort(reverse=True)
    picked, used = [], []
    for words, start in scored:
        if any(abs(start - u) < window for u in used):
            continue
        picked.append((start, words))
        used.append(start)
        if len(picked) >= top:
            break
    return picked


def main():
    ap = argparse.ArgumentParser(description="Mine a Quill transcript for what's worth stealing.")
    ap.add_argument("target", help="a transcript .txt, or a folder (uses the newest)")
    ap.add_argument("--out", default=None, help="write the digest to a file instead of stdout")
    ap.add_argument("--lookback", type=int, default=90, help="seconds of context before each mark")
    ap.add_argument("--names", type=int, default=25, help="how many new-name candidates to show")
    ap.add_argument("--min-said", type=int, default=3,
                    help="ignore names said fewer than this many times (default 3)")
    ap.add_argument("--canon", default=None,
                    help="comma-separated folders of campaign notes, searched to tell "
                         "'already written down' from 'new at the table'. "
                         'Pass "" to skip.')
    a = ap.parse_args()
    # NOTES.txt answers this for every tool; --canon overrides, "" opts out.
    # (Paths resolve relative to this script, never the shell's cwd.)
    a.canon = ",".join(canon_roots_from_flag(a.canon))

    path = a.target
    if os.path.isdir(path):
        cands = [os.path.join(path, f) for f in os.listdir(path) if f.lower().endswith(".txt")]
        if not cands:
            print("no .txt transcripts in that folder.")
            return 1
        path = max(cands, key=os.path.getmtime)

    head, segs = load(path)
    lex_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lexicon.txt")
    lexicon = []
    if os.path.exists(lex_file):
        lexicon = [l.strip() for l in open(lex_file, encoding="utf-8")
                   if l.strip() and not l.startswith("#")]

    L = []
    L.append(f"# Session digest — {os.path.basename(path)}\n")

    verdict, hl = health(segs)
    L.append(f"## 1. Health — **{verdict}**\n")
    L += ["```"] + hl + ["```\n"]

    pins, mk = marks(head, segs, a.lookback)
    L.append(f"## 2. Marked moments — {len(pins)}\n")
    if pins:
        L += mk
    else:
        L.append("*No marks in the header. Press **M** at the table next time — it is the "
                 "difference between a searchable session and a wall of text.*")
    L.append("")

    counts, phrases, ctx = name_candidates(segs, known=lexicon)
    cand = Counter()
    cand.update({p: n * 2 for p, n in phrases.items()})   # multi-word runs score higher
    for w, n in counts.items():
        cand[w] = max(cand.get(w, 0), n)
    cand = [(k, v) for k, v in cand.most_common() if v >= a.min_said]
    # A multi-word hit ("the Salt Compact") makes its own components ("Iron", "Oath") noise.
    multi = [k for k, _ in cand if " " in k]
    parts = {w for m in multi for w in m.split()}
    cand = [(k, v) for k, v in cand if " " in k or k not in parts]

    canon = canon_index(a.canon.split(",")) if a.canon else None
    L.append("## 3. Names your table said that `lexicon.txt` does not know\n")

    if canon is None:
        L.append("*(no canon folder searched — pass `--canon <dir>` to split these into "
                 "'already written down' vs 'new')*\n")
        for w, n in cand[:a.names]:
            t, sent = ctx.get(w, (0, ""))
            L.append(f"- **{w}** ×{n} — first at [{hms(t)}]")
    else:
        known, fresh = [], []
        for w, n in cand[:a.names * 2]:
            (known if canon_hits(w, canon) >= 3 else fresh).append((w, n))

        L.append("### Already in your campaign files — but the transcriber didn't know them\n")
        L.append("*Add these to `lexicon.txt`. They are real canon; the model was guessing "
                 "at their spelling all session.*\n")
        if known:
            L.append("```")
            L += [w for w, _ in known[:a.names]]
            L.append("```")
        else:
            L.append("*(none — your lexicon is keeping up)*")

        L.append("\n### Said at the table, and in **no file you have**\n")
        L.append("*This is the material at risk. Names your table used repeatedly that exist "
                 "nowhere in your notes — nicknames they coined, NPCs you improvised, places "
                 "you invented mid-sentence. Write down the real ones now or lose them.*\n")
        if fresh:
            L.append("| name | said | first heard | what was being said |")
            L.append("|---|---|---|---|")
            for w, n in fresh[:a.names]:
                t, sent = ctx.get(w, (0, ""))
                sent = (sent[:80] + "…") if len(sent) > 80 else sent
                L.append(f"| **{w}** | {n} | [{hms(t)}] | {sent.replace('|', '/')} |")
            L.append("\n*Some of these are your players' actual first names, mishearings, or "
                     "pop-culture asides. This is a net, not a verdict — prune it.*")
        else:
            L.append("*(none)*")
    L.append("")

    L.append("## 4. Densest stretches — where the table leaned in\n")
    for start, words in hot(segs):
        L.append(f"- **[{hms(start)}]** — {words} words in 3 min")
    L.append("")

    text = "\n".join(L)
    if a.out:
        open(a.out, "w", encoding="utf-8").write(text)
        print(f"digest -> {a.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
