@echo off
title Gnasher's Quill
REM ============================================================
REM  Double-click this to record & transcribe a table session.
REM  Works for ANY campaign - the session label keeps them straight.
REM
REM  PORTABLE: it looks for Quill-Studio.ps1 next to itself first, so
REM  the whole Quill folder can move to any drive or any machine and
REM  still work. Only if it can't find it there does it fall back to
REM  the old fixed path - which is what makes dragging a COPY of this
REM  .bat to the Desktop still work.
REM
REM  The Quill records -> the Grimoire holds -> the Satchel carries.
REM ============================================================
setlocal

set "STUDIO=%~dp0Quill-Studio.ps1"

if not exist "%STUDIO%" (
  echo.
  echo   Can't find Quill-Studio.ps1.
  echo   Looked next to this file: %~dp0
  echo   and at the fallback path.
  echo.
  echo   Keep this .bat inside the Quill folder, or edit the
  echo   fallback path on line 18 to wherever the Quill now lives.
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%STUDIO%"
if errorlevel 1 pause
endlocal
