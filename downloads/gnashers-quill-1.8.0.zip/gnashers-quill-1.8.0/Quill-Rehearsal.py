# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Rehearsal — put a fake table through the Chorus before you ask a real one.

    python Quill-Rehearsal.py                three voices, the whole loop
    python Quill-Rehearsal.py --voices 5
    python Quill-Rehearsal.py --keep         leave the artifacts to look at
    python Quill-Rehearsal.py --model small.en

WHY THIS EXISTS
    The Chorus asks five friends to put their phones on the table and trust that
    the DM's laptop is catching all of it. Whether that was true is a question
    you normally answer at the merge -- the morning after, when the session is
    gone and nobody is going to say it again.

    So rehearse it. This stands up a studio on its own port, invents a table,
    gives every seat a real speaking voice, and pushes their audio through the
    SAME HTTP path a phone uses: MediaRecorder-shaped chunks, strictly in order,
    table code and all. Then it closes the session, runs the real merge, and
    reads the braid back.

    The check that matters is the last one. Every voice's own words must come
    back under that voice's own name, and under nobody else's. That is the whole
    promise of the Chorus -- speaker KNOWN, not inferred -- and it is the one
    thing no unit test can tell you, because it depends on ffmpeg, on whisper,
    on the clock, and on the wire all being right at once.

WHAT IT TOUCHES
    A session folder under recordings/chorus/ named ..._rehearsal, and its
    transcripts. Both are deleted at the end unless you pass --keep. It never
    touches a real recording, and it runs on port 8021 so it cannot collide
    with a studio you have open for an actual game.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from quill_lib import SEG_RE                                    # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

PORT = 8021                    # not 8020: a real game may be running next door
LATE_S = 8                     # how long the last seat dawdles before joining

# Lines lifted from the Chorus's own promise in ROADMAP.md, so a passing
# rehearsal is literally the documented example coming true. Each carries one
# distinctive noun that appears in no other line -- that noun is how we prove
# the words came back under the right name.
TABLE = [
    ("ADA",  "The warden's hands are shaking as he lifts the lantern.", "warden"),
    ("BRAN", "I step between them and draw my blade.",                  "blade"),
    ("CASS", "Bad idea. I ready an action and watch the door.",         "door"),
    ("DELL", "The seal on that chest was broken a long time ago.",      "chest"),
    ("ERIN", "I keep one hand on the rope and count to ten.",           "rope"),
]

C_OK, C_BAD, C_DIM, C_GOLD, C_OFF = (
    "\033[92m", "\033[91m", "\033[90m", "\033[93m", "\033[0m")


def say(label, msg, colour=""):
    print(f"  {colour}{label:<10}{C_OFF} {msg}")


# --------------------------------------------------------------- the voices --

def synth_track(text, voice, rate, delay_s, total_s, out_webm, tmp):
    """One phone's recording: silence, then the line, then quiet to the end.

    Staggering the speech INSIDE each track rather than staggering the joins is
    both faster and more truthful -- a real table joins all at once at the start
    and then people talk when they talk."""
    wav = tmp / f"{out_webm.stem}.wav"
    ps = tmp / f"{out_webm.stem}.ps1"
    ps.write_text(
        "Add-Type -AssemblyName System.Speech\n"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
        f'try {{ $s.SelectVoice("{voice}") }} catch {{ }}\n'
        f"$s.Rate = {rate}\n"
        f'$s.SetOutputToWaveFile("{wav}")\n'
        f'$s.Speak("{text}")\n'
        "$s.Dispose()\n", encoding="ascii")
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                        "-File", str(ps)], capture_output=True, text=True)
    if r.returncode != 0 or not wav.exists() or wav.stat().st_size < 1024:
        return False
    # webm/opus at 48k is exactly what Chrome's MediaRecorder hands a phone.
    f = subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(wav),
         "-af", f"adelay={int(delay_s * 1000)},apad", "-t", str(total_s),
         "-ac", "1", "-ar", "48000", "-c:a", "libopus", "-b:a", "32k",
         str(out_webm)], capture_output=True, text=True)
    return f.returncode == 0 and out_webm.exists() and out_webm.stat().st_size > 1024


def tone_track(seed, delay_s, total_s, out_webm):
    """No speech engine? Still prove the plumbing, and say so plainly."""
    f = subprocess.run(
        ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
         "-f", "lavfi", "-i", f"sine=frequency={220 + seed * 110}:duration=3",
         "-af", f"adelay={int(delay_s * 1000)},apad", "-t", str(total_s),
         "-ac", "1", "-ar", "48000", "-c:a", "libopus", "-b:a", "32k",
         str(out_webm)], capture_output=True, text=True)
    return f.returncode == 0 and out_webm.exists()


# ---------------------------------------------------------------- the wire ---

def api(path, body=None, raw=None, query=""):
    url = f"http://127.0.0.1:{PORT}{path}{query}"
    if raw is not None:
        req = urllib.request.Request(url, data=raw, method="POST",
                                     headers={"Content-Type": "application/octet-stream"})
    elif body is not None:
        req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                     headers={"Content-Type": "application/json"})
    else:
        req = urllib.request.Request(url)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode() or "{}")
        except Exception:
            return {"ok": False, "error": f"http {e.code}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


class Studio:
    """A studio of our own, on our own port, torn down afterwards."""

    def __enter__(self):
        env = dict(os.environ, QUILL_PORT=str(PORT))
        self.p = subprocess.Popen([sys.executable, str(HERE / "quill_server.py")],
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  env=env, cwd=str(HERE))
        for _ in range(60):
            if api("/api/status").get("hearth") is not None:
                return self
            time.sleep(0.25)
        raise RuntimeError(f"the rehearsal studio never came up on port {PORT}")

    def __exit__(self, *a):
        self.p.terminate()
        try:
            self.p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.p.kill()


def upload_like_a_phone(track_id, token, webm, chunks=4):
    """MediaRecorder emits a container in pieces, the first carrying the header,
    and the server refuses to reorder them. Send them the same way."""
    data = webm.read_bytes()
    step = max(1, len(data) // chunks)
    sent = 0
    for i in range(0, len(data), step):
        part = data[i:i + step]
        r = api("/api/chorus/chunk", raw=part,
                query=f"?t={token}&track={track_id}")
        if not r.get("ok"):
            return sent, r.get("error", "chunk refused")
        sent += len(part)
    return sent, None


# ------------------------------------------------------------------- checks --

class Report:
    def __init__(self):
        self.rows = []

    def add(self, ok, what, detail=""):
        self.rows.append((ok, what, detail))
        say("✓ pass" if ok else "✗ FAIL", what + (f"  {C_DIM}{detail}{C_OFF}" if detail else ""),
            C_OK if ok else C_BAD)
        return ok

    def failed(self):
        return [r for r in self.rows if not r[0]]


def main():
    ap = argparse.ArgumentParser(description="Rehearse a Chorus night end to end.")
    ap.add_argument("--voices", type=int, default=3, help="how many seats at the fake table (1-5)")
    ap.add_argument("--model", default="base.en", help="whisper model for the merge")
    ap.add_argument("--keep", action="store_true", help="leave the session and transcripts behind")
    a = ap.parse_args()
    seats = TABLE[:max(1, min(a.voices, len(TABLE)))]

    print(f"\n  {C_GOLD}GNASHER'S QUILL - Chorus rehearsal{C_OFF}")
    print("  " + "-" * 62)
    print(f"  {len(seats)} voice(s) · model {a.model} · studio on port {PORT}")
    print("  Nothing here touches a real recording.\n")

    rep = Report()
    tmp = Path(tempfile.mkdtemp(prefix="quill_rehearsal_"))
    session = None
    spoken = True
    try:
        # 1. voices ---------------------------------------------------------
        voices = ["Microsoft Zira Desktop", "Microsoft David Desktop"]
        # The last seat speaks at the top of its OWN track -- its place in the
        # night comes from the offset the server stamps when it joins late, not
        # from silence baked into the audio. That is precisely what makes it a
        # test of the clock rather than of the file.
        n_early = len(seats) - 1 if len(seats) > 1 else len(seats)
        for i, (name, line, _kw) in enumerate(seats):
            wm = tmp / f"{name}.webm"
            lead = 0.5 if (len(seats) > 1 and i == len(seats) - 1) else 0.5 + i * 5.5
            ok = synth_track(line, voices[i % len(voices)], -1 + (i % 3),
                             lead, lead + 6, wm, tmp)
            if not ok:
                spoken = False
                ok = tone_track(i, lead, lead + 6, wm)
            if not ok:
                rep.add(False, f"make {name}'s track", "neither speech nor tone would encode")
                return 1
        rep.add(True, "every seat has a recording",
                "spoken" if spoken else "TONES ONLY - no speech engine, wording unchecked")

        # 2. open -----------------------------------------------------------
        o = api("/api/chorus/open", {"label": "rehearsal"})
        if not rep.add(bool(o.get("ok")), "the Chorus opens", o.get("error", "")):
            return 1
        session, token = o["session"], o["token"]
        say("session", session, C_DIM)

        # 3. the wrong code is refused --------------------------------------
        bad = api("/api/chorus/join", {"speaker": "Mallory", "mime": "audio/webm",
                                       "t": token + "x"})
        rep.add(not bad.get("ok"), "a wrong table code is turned away",
                "" if not bad.get("ok") else "IT LET A STRANGER IN")

        # 4. join + upload --------------------------------------------------
        # The last seat joins LATE on purpose. Every phone starting at once
        # leaves offset_s at 0 for everybody, and then the braid is ordered by
        # within-track timestamps alone -- the clock sync, which is the hardest
        # thing the Chorus does, would go completely unexercised while the
        # rehearsal reported success. A latecomer is also just true to life:
        # somebody always turns up in the second hour.
        tracks, offsets = {}, {}
        early = seats[:-1] if len(seats) > 1 else seats
        late = seats[-1] if len(seats) > 1 else None

        def seat(name):
            j = api("/api/chorus/join", {"speaker": name, "mime": "audio/webm", "t": token})
            if not j.get("ok"):
                rep.add(False, f"{name} joins", j.get("error", ""))
                return None
            tracks[name] = j["track"]
            s = api("/api/chorus/start", {"track": j["track"], "t": token})
            offsets[name] = s.get("offset_s")
            return j["track"]

        for name, _l, _k in early:
            if seat(name) is None:
                return 1
        if late:
            say("waiting", f"{LATE_S}s, then {late[0]} turns up late", C_DIM)
            time.sleep(LATE_S)
            if seat(late[0]) is None:
                return 1
        rep.add(True, "every phone joined and started",
                ", ".join(f"{n}+{offsets[n]:.0f}s" for n in tracks))

        total_sent = 0
        for name, _line, _kw in seats:
            sent, err = upload_like_a_phone(tracks[name], token, tmp / f"{name}.webm")
            total_sent += sent
            if err:
                rep.add(False, f"{name}'s audio uploads", err)
                return 1
            api("/api/chorus/leave", {"track": tracks[name], "t": token})
        rep.add(True, "all chunks accepted, in order",
                f"{total_sent/1024:.0f} KB across {len(seats)} tracks")

        # 5. what actually landed on disk -----------------------------------
        st = api("/api/chorus/status")
        on_disk = sum(v["bytes"] for v in st.get("voices", []))
        rep.add(on_disk == total_sent, "every byte sent is a byte stored",
                f"sent {total_sent}, stored {on_disk}")

        folder = HERE / "recordings" / "chorus" / session
        rep.add(all((folder / f"{t}.webm").stat().st_size > 1024 for t in tracks.values()),
                "each voice has its own file")

        # 6. close + merge ---------------------------------------------------
        c = api("/api/chorus/close", {})
        if not rep.add(bool(c.get("ok")), "the Chorus closes", c.get("error", "")):
            return 1

        print(f"\n  {C_DIM}merging - each voice transcribes on its own, then they braid...{C_OFF}\n")
        m = subprocess.run([sys.executable, str(HERE / "Quill-Chorus.py"),
                            "--session", session, "--model", a.model],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=str(HERE))
        for ln in (m.stdout or "").splitlines():
            print(f"    {C_DIM}{ln}{C_OFF}")
        if not rep.add(m.returncode == 0, "the merge runs",
                       (m.stderr or "").strip().splitlines()[-1:] and
                       (m.stderr or "").strip().splitlines()[-1] or ""):
            return 1

        braid = HERE / "transcripts" / f"{session}_chorus.txt"
        if not rep.add(braid.is_file(), "a braided transcript exists", braid.name):
            return 1

        # 7. read the braid back --------------------------------------------
        rows = []
        for ln in braid.read_text(encoding="utf-8").splitlines():
            mm = SEG_RE.match(ln)
            if mm:
                t = int(mm.group(1)) * 3600 + int(mm.group(2)) * 60 + int(mm.group(3))
                rest = mm.group(7)
                who = rest[1:rest.index("]")].strip() if rest.startswith("[") and "]" in rest else "?"
                rows.append((t, who, rest.split("]", 1)[-1].strip()))
        rep.add(bool(rows), "downstream tools can parse it",
                f"{len(rows)} segments in standard Quill format")

        heard = {w for _t, w, _x in rows}
        rep.add(heard == set(tracks), "every voice made it into the braid",
                f"heard {sorted(heard)}")

        times = [t for t, _w, _x in rows]
        rep.add(times == sorted(times), "the braid is in time order")

        # The clock. A latecomer's audio starts at 0 in its OWN file, so if the
        # offset were dropped their line would land at the top of the night
        # instead of where it belongs. This is the check that separates "the
        # merge concatenates" from "the merge knows what time it was".
        if late:
            lname = late[0]
            off = offsets.get(lname) or 0
            firsts = [t for t, w, _x in rows if w == lname]
            rep.add(off >= LATE_S - 2, "the late phone's clock was corrected",
                    f"{lname} joined +{off:.1f}s (waited {LATE_S}s)")
            if firsts:
                want, got = off + 0.5, firsts[0]
                rep.add(abs(got - want) <= 3,
                        "their line lands where the clock says, not at the top",
                        f"expected ~{want:.0f}s, found {got}s")

        # 8. THE one that matters -------------------------------------------
        if spoken:
            said = {}
            for _t, who, txt in rows:
                said[who] = said.get(who, "") + " " + txt.lower()
            right = wrong = 0
            for name, _line, kw in seats:
                mine = kw in said.get(name, "")
                theirs = [o for o in said if o != name and kw in said[o]]
                right += bool(mine)
                wrong += bool(theirs)
                if not mine or theirs:
                    say("  detail", f"'{kw}' expected under {name}"
                        + (f", found under {theirs}" if theirs else ", not found"), C_BAD)
            rep.add(right == len(seats) and wrong == 0,
                    "each voice's words came back under its own name",
                    f"{right}/{len(seats)} matched, {wrong} cross-attributed")
        else:
            say("- skip", "wording unchecked (tones, not speech)", C_DIM)

        print(f"\n  {C_GOLD}the braid{C_OFF}")
        for t, who, txt in rows[:12]:
            print(f"    {C_DIM}[{t//3600:02d}:{t//60%60:02d}:{t%60:02d}]{C_OFF} "
                  f"{C_GOLD}{who:<6}{C_OFF} {txt[:66]}")

    finally:
        if session and not a.keep:
            shutil.rmtree(HERE / "recordings" / "chorus" / session, ignore_errors=True)
            for f in (HERE / "transcripts").glob(f"{session}*"):
                f.unlink(missing_ok=True)
        elif session:
            print(f"\n  {C_DIM}kept: recordings/chorus/{session} and its transcripts{C_OFF}")
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n  " + "-" * 62)
    bad = rep.failed()
    if bad:
        print(f"  {C_BAD}{len(bad)} check(s) failed - do not trust the Chorus tonight{C_OFF}")
        for _ok, what, _d in bad:
            print(f"    - {what}")
        print()
        return 1
    print(f"  {C_OK}all {len(rep.rows)} checks passed - the Chorus is ready for a real table{C_OFF}\n")
    return 0


if __name__ == "__main__":
    with Studio():
        raise SystemExit(main())
