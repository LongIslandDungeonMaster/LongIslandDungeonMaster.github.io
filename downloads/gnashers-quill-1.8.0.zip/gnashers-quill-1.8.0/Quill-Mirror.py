# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Mirror — how you ran the session, not what happened in it.

Every session tool tells a DM what happened. None of them tell a DM anything about
their own craft. This does: the shape of the night, where combat ate the clock, how
long your longest unbroken monologue actually ran, and where the room went quiet.

    python Quill-Mirror.py transcripts/<session>.txt
    python Quill-Mirror.py transcripts/            # newest session
    python Quill-Mirror.py <session> --out mirror.md

HONESTY ABOUT WHAT THIS CAN KNOW
    One microphone cannot tell who is speaking. Everything here is inferred from
    VOCABULARY and TIMING, and every number is labelled with how it was derived.
    Where a figure is an estimate it says "est." and means it.

    Per-player airtime -- who actually got to talk -- genuinely needs one track per
    person. That is the Chorus, and it is not built yet. This tool reports what a
    single track can honestly support and refuses to invent the rest.

No AI, no network. Vocabulary lists and arithmetic.
"""
import os
import re
import sys
import argparse
import statistics

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import (hms, load_segments, load_lexicon, lexicon_regex, NARRATION, META,
                       pick_transcripts, name_candidates, canon_index, canon_hits,
                       canon_roots_from_flag, notes_found)

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

COMBAT = re.compile(r"""\b(
 initiative|roll(s|ed|ing)?\ (for|to\ hit|damage|initiative)|
 attack(s|ed|ing)?|hits?\ (for|him|her|it|them)|misses|damage|
 saving\ throw|save\ (vs|against|dc)|dc\ \d+|ac\ (is\ )?\d+|
 hit\ points?|hp\b|temp\ hp|healing|heal(s|ed)?|
 d20|d4|d6|d8|d10|d12|natural\ (twenty|one|1|20)|crit(ical)?|
 advantage|disadvantage|bonus\ action|reaction|opportunity\ attack|
 spell\ slot|concentration|cantrip|
 unconscious|death\ save|stabilis|stabiliz|prone|grappled|restrained
)\b""", re.I | re.X)


SPEAKER_RE = re.compile(r"^\[([A-Za-z0-9 _'\-]{1,24}?)\s*\]\s*(.*)$")


def split_speakers(segs):
    """A Chorus transcript tags every line `[NAME] text`. -> (segs_without_tag, by_speaker)

    Returns by_speaker = {} for an ordinary single-mic transcript, which is the signal
    to skip the airtime section entirely rather than invent it."""
    clean, by = [], {}
    for a, b, text in segs:
        m = SPEAKER_RE.match(text)
        if m:
            who, body = m.group(1).strip().upper(), m.group(2)
            by.setdefault(who, []).append((a, b, body))
            clean.append((a, b, body))
        else:
            clean.append((a, b, text))
    return clean, (by if len(by) >= 2 else {})


def bucket(segs, size):
    """Group into fixed time buckets -> [(start, words, [texts])]."""
    if not segs:
        return []
    end = segs[-1][1]
    out = []
    for s in range(0, int(end), size):     # not end+size: that invents a
                                          # bucket after the session ended
        rows = [t for a, _b, t in segs if s <= a < s + size]
        out.append((s, sum(len(r.split()) for r in rows), rows))
    return out


def classify(text, lex_re):
    """combat / story / table / unclassified -- vocabulary only, first match wins.

    "unclassified" is a real answer and must stay one. An earlier version defaulted
    everything unmatched into "table talk" and duly reported that 76% of a session was
    off-topic chatter -- but a line like "I step between them and draw" carries no
    narration marker, no campaign noun and no dice word, and it is obviously play.
    A bucket that swallows the leftovers will always look like the biggest bucket, and
    the number it produces is a lie. Better to say plainly what could not be told."""
    if COMBAT.search(text):
        return "combat"
    if META.search(text):
        return "table"
    if NARRATION.search(text) or (lex_re and lex_re.search(text)):
        return "story"
    return "unclassified"


def smooth(labels, segs, window=90):
    """Fill the gaps from the neighbourhood, because a scene has duration.

    Per-segment vocabulary matching hits a hard ceiling: on a real 5h58m session it
    could label only 27% of the talk, because most lines are fragments, continuations
    and half-sentences carrying no marker at all. Widening the word lists bought 3
    points and a lot of maintenance -- the wrong lever.

    The right one is that conversation happens in RUNS. A line with no signal sitting
    between two story lines is story. Weighting nearby labelled segments by closeness
    takes "couldn't tell" from 73% to 12% on that same session, and the split it
    produces (mostly roleplay, little combat) matches what the night actually was.

    Returns (labels, inferred_count) so the report can say how much was read directly
    and how much was inferred rather than presenting them as the same thing."""
    out, inferred = list(labels), 0
    known = [(i, l) for i, l in enumerate(labels) if l != "unclassified"]
    for i, lab in enumerate(labels):
        if lab != "unclassified":
            continue
        a = segs[i][0]
        near = {}
        for j, jl in known:
            d = abs(segs[j][0] - a)
            if d <= window:
                near[jl] = near.get(jl, 0) + (window - d)
        if near:
            out[i] = max(near, key=near.get)
            inferred += 1
    return out, inferred


def sparkline(values, width_chars="▁▂▃▄▅▆▇█"):
    if not values:
        return ""
    hi = max(values) or 1
    return "".join(width_chars[min(len(width_chars) - 1, int(v / hi * (len(width_chars) - 1)))]
                   for v in values)


def longest_monologue(segs):
    """Longest unbroken run of DM narration -- the read-aloud that ran long.

    A run is consecutive narration-marked segments with no more than a 5s gap. This is
    the closest a single track gets to "you talked for how long?"."""
    best = (0, None, None)     # (duration, start, text)
    run_start, run_end, run_txt = None, None, []
    for a, b, t in segs:
        if NARRATION.search(t):
            if run_start is None or a - run_end > 5:
                run_start, run_txt = a, []
            run_end = b
            run_txt.append(t)
            if run_end - run_start > best[0]:
                best = (run_end - run_start, run_start, " ".join(run_txt))
        else:
            run_start = None
    return best


def main():
    ap = argparse.ArgumentParser(description="Craft analytics for a session transcript.")
    ap.add_argument("target", nargs="?", default="transcripts",
                    help="a transcript .txt or a folder (default: newest in transcripts/)")
    ap.add_argument("--out", default=None)
    ap.add_argument("--transcripts", default=None,
                    help="synonym for the positional target, so the Ledger, the "
                         "Concordance and the Mirror all take the same flag")
    ap.add_argument("--bucket", type=int, default=600, help="seconds per bar (default 600 = 10 min)")
    ap.add_argument("--canon", default=None,
                    help='campaign-note folders, to measure prep against improvisation. '
                         'Unset uses NOTES.txt; "" skips it.')
    ap.add_argument("--window", type=int, default=90, metavar="SEC",
                    help="how far a labelled line lends its label to unlabelled "
                         "neighbours (default 90). 0 disables smoothing entirely.")
    a = ap.parse_args()

    path = a.transcripts or a.target
    if os.path.isdir(path):
        # pick_transcripts, not a raw *.txt scan. A bare listing counts a README
        # as a session, and -- worse -- counts each of a Chorus night's per-voice
        # tracks as its own night, so "the newest transcript" could be one
        # player's mostly-silent microphone and the Mirror would report an
        # evening of dead air.
        c = pick_transcripts(path)
        if not c:
            print("no transcripts found.")
            return 1
        path = max(c, key=os.path.getmtime)

    _head, segs = load_segments(path)
    if not segs:
        print("no timestamped segments - is this a Quill transcript?")
        return 1

    segs, by_speaker = split_speakers(segs)
    lex_re = lexicon_regex(load_lexicon())
    total = segs[-1][1]
    words = sum(len(t.split()) for _a, _b, t in segs)

    raw = [classify(t, lex_re) for _a, _b, t in segs]
    labels, inferred = smooth(raw, segs, a.window)
    direct = sum(1 for l in raw if l != "unclassified")
    kinds = {"combat": 0, "story": 0, "table": 0, "unclassified": 0}
    kseconds = {"combat": 0, "story": 0, "table": 0, "unclassified": 0}
    for (a_, b_, t), k in zip(segs, labels):
        kinds[k] += len(t.split())
        kseconds[k] += (b_ - a_)
    spoken = sum(kseconds.values()) or 1

    buckets = bucket(segs, a.bucket)
    dur, mstart, mtext = longest_monologue(segs)

    # dead air: gaps between consecutive segments
    gaps = [(segs[i + 1][0] - segs[i][1], segs[i][1])
            for i in range(len(segs) - 1) if segs[i + 1][0] - segs[i][1] >= 45]

    L = []
    L.append(f"# MIRROR — {os.path.basename(path)}")
    L.append("")
    L.append(f"**{hms(total)}** on the clock · **{words:,} words** · "
             f"**{words/(total/60):.0f} words/min** average")
    L.append("")
    L.append("> Inferred from vocabulary and timing on a single microphone. Everything below")
    L.append("> is an estimate and says so. Per-player airtime needs one track per person")
    L.append("> (the Chorus) and is deliberately not guessed at here.")
    L.append("")

    L.append("## The shape of the night")
    L.append("")
    L.append("```")
    L.append(sparkline([b[1] for b in buckets]))
    L.append(f"{hms(0)}{' ' * max(0, len(buckets) - 16)}{hms(total)}")
    L.append(f"(each bar = {a.bucket//60} min of talk)")
    L.append("```")
    quiet = [b for b in buckets if b[1] < (words / max(len(buckets), 1)) * 0.4]
    if quiet:
        L.append(f"Quietest stretches: " +
                 ", ".join(f"**{hms(q[0])}**" for q in quiet[:5]) +
                 " — breaks, or the table stalling.")
    L.append("")

    if by_speaker:
        L.append("## Who got to talk")
        L.append("")
        L.append("*One track per voice, so this is **measured, not estimated**. This is the "
                 "number no single-microphone tool can give you.*")
        L.append("")
        rows = []
        for who, rs in by_speaker.items():
            secs = sum(b - a for a, b, _ in rs)
            wds = sum(len(t.split()) for _a, _b, t in rs)
            longest = max((b - a for a, b, _ in rs), default=0)
            rows.append((secs, who, len(rs), wds, longest))
        rows.sort(reverse=True)
        allsecs = sum(r[0] for r in rows) or 1
        L.append("| voice | share of speech | speaking time | turns | words | longest turn |")
        L.append("|---|---|---|---|---|---|")
        for secs, who, turns, wds, longest in rows:
            L.append(f"| **{who}** | {100*secs/allsecs:.0f}% | {int(secs//60)}m {int(secs%60)}s | "
                     f"{turns} | {wds:,} | {int(longest)}s |")
        L.append("")
        top, bottom = rows[0], rows[-1]
        if len(rows) > 1 and bottom[0] > 0 and top[0] / bottom[0] >= 3:
            L.append(f"**{bottom[1]} spoke {top[0]/bottom[0]:.0f}× less than {top[1]}.** Worth "
                     f"knowing before next session — that is the player who gets talked over, "
                     f"and it is invisible from behind the screen.")
        elif len(rows) > 1:
            L.append(f"Spread is reasonable — {top[1]} to {bottom[1]} is "
                     f"{top[0]/max(bottom[0],1):.1f}×.")
        L.append("")

    L.append("## Where the time went (est.)")
    L.append("")
    L.append("| | share of speech | words |")
    L.append("|---|---|---|")
    for k, label in (("combat", "Combat & rules"), ("story", "Story & roleplay"),
                     ("table", "Table talk (tech, food, meta)"),
                     ("unclassified", "Couldn't tell")):
        L.append(f"| {label} | {100*kseconds[k]/spoken:.0f}% | {kinds[k]:,} |")
    L.append("")
    L.append(f"*{direct} of {len(segs)} lines carried a marker of their own; the other "
             f"{inferred} were inferred from what was happening either side of them "
             f"(within {a.window}s). Classified by vocabulary: dice/AC/saving-throw language reads as combat; "
             "narration or one of your own campaign nouns reads as story; laptops and snacks "
             "read as table talk. **Couldn't tell** is the honest bucket — plain dialogue "
             "like \"I step between them\" carries none of those markers. It is not a "
             "measure of wasted time. Naming more of your world in `lexicon.txt` moves lines "
             "out of it and into story.*")
    L.append("")

    if mstart is not None and dur > 0:
        L.append("## Your longest unbroken stretch of narration (est.)")
        L.append("")
        L.append(f"**{int(dur//60)}m {int(dur%60)}s** starting at **{hms(mstart)}**.")
        L.append("")
        L.append(f"> {mtext[:400]}{'…' if len(mtext) > 400 else ''}")
        L.append("")
        if dur > 180:
            L.append("*Over three minutes. Worth knowing — that is a long time for a table to "
                     "listen without a decision to make.*")
        L.append("")

    if gaps:
        L.append("## Dead air")
        L.append("")
        L.append(f"{len(gaps)} gap(s) of 45s or more with nothing transcribed. Longest:")
        for g, at in sorted(gaps, reverse=True)[:5]:
            L.append(f"- **{int(g)}s** at {hms(at)}")
        L.append("")
        L.append("*Some of this is a break. Some is people reading their sheets. If a gap sits "
                 "right after a big reveal, that one is the table thinking — the good kind.*")
        L.append("")

    # --- prep against improvisation ------------------------------------------
    # The rest of the Mirror measures the SHAPE of the night. This measures where
    # it came from: of the proper nouns your table said in fiction, how many were
    # already in your notes and how many arrived at the table. Neither number is
    # the good one -- a night of pure prep and a night of pure improv are both
    # real ways to run a game -- but most DMs have never seen the ratio.
    roots = canon_roots_from_flag(a.canon)
    searched = notes_found(roots) if roots else []
    L.append("## Prep and improvisation (est.)")
    L.append("")
    if not searched:
        L.append("*Not measured: no campaign notes were searched, so there is nothing to "
                 "compare tonight's names against. Put your notes folder in `NOTES.txt` "
                 "(or set it in the web studio) and this section starts reporting how much "
                 "of the night was already written down.*")
        L.append("")
    else:
        canon = canon_index(searched)
        singles, phrases, ctx = name_candidates(segs, known=[])
        cand = dict(phrases)
        for w, n in singles.items():
            cand[w] = max(cand.get(w, 0), n)
        parts = {w for k in cand if " " in k for w in k.split()}
        cand = {k: v for k, v in cand.items() if " " in k or k not in parts}
        said = [(k, v) for k, v in sorted(cand.items(), key=lambda x: -x[1]) if v >= 2]
        if not said:
            L.append("*Nothing said often enough to measure.*")
            L.append("")
        else:
            written = [(k, v) for k, v in said if canon_hits(k, canon) >= 3]
            fresh = [(k, v) for k, v in said if (k, v) not in written]
            pct = round(100 * len(written) / len(said))
            L.append(f"Of the **{len(said)}** names your table said more than once tonight, "
                     f"**{len(written)}** ({pct}%) are already in your notes and "
                     f"**{len(fresh)}** arrived at the table.")
            L.append("")
            L.append(f"*Searched: {', '.join('`' + os.path.basename(r) + '`' for r in searched)}. "
                     f"A name counts as written down if it appears in your notes at least "
                     f"three times, so a passing mention does not count as prep.*")
            L.append("")
            if fresh:
                L.append("**Arrived at the table** — these exist nowhere but the recording "
                         "until you write them down:")
                for k, v in fresh[:12]:
                    t, line = ctx.get(k, (0, ""))
                    L.append(f"- **{k}** ×{v} — first at `{hms(t)}`")
                L.append("")
            if written:
                L.append("**Already yours**: " + ", ".join(f"{k} ×{v}" for k, v in written[:12]))
                L.append("")

    text = "\n".join(L) + "\n"
    if a.out:
        open(a.out, "w", encoding="utf-8").write(text)
        print(f"-> {a.out}")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
