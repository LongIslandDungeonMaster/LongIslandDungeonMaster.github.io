Your session audio lands here. Nothing in this folder ships.
