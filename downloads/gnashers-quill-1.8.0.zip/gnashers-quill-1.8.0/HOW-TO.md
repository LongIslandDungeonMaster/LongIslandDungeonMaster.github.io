# Gnasher's Quill — capture any session (no writing, no monthly fees)

**The Quill records → the Grimoire holds → the Satchel carries.**

The whole loop is: **record → transcribe locally → mine the transcript → ready for session prep.**
Nothing goes to the cloud, nothing costs money, and no AI listens to the live table.
Works for **any** campaign — the session label keeps them straight.

## Two faces, one engine
- **`The Quill.bat`** — the terminal studio. Fast, keyboard-driven, runs anywhere.
- **`Gnashers Quill Web.bat`** — the web studio: same engine behind a browser page.
  Big buttons, live timer, ledger with click-to-read transcripts. The console window it
  opens IS the studio — leave it open while you play; closing it stops everything.
  **Phone trick:** the console prints a `http://192.168.x.x:8020` address — open it on any
  phone on the same Wi-Fi and the phone becomes a remote MARK button for the table.

## Before game night: the pre-game check

Double-click **`The Quill.bat`** → **[D]**, or right-click `Quill-Doctor.ps1` → Run with PowerShell.

It checks the whole chain — Python, faster-whisper, ffmpeg, **a working microphone**, GPU, whether
the Whisper model is cached (so you don't need internet), disk space, folder permissions, and that
the crash-safety and VAD fixes are still in place. Anything missing comes with the exact command to
fix it. Run it once on any new machine and once before a session you care about.

The worst failure this tool has is discovering at 7pm that something isn't installed. This is the
thirty seconds that prevents it.

## Your recording survives a crash (since 2026-07-30)

A normal `.m4a` writes its index at the **very end** of the file. That means if the laptop died at
hour five of a six-hour game — power, a closed window, a force-quit — you got an **unplayable file
and no session.** Measured: a hard kill produced a **44-byte** file.

The recorder now writes the audio in self-contained 2-second fragments and flushes as it goes.
Tested with a real mic and a hard kill mid-recording: **10.3 of 12 seconds recovered, decoding
cleanly, and it transcribed normally.** A crash now costs you the last couple of seconds instead of
the whole night. It is still an ordinary `.m4a` — nothing else in the chain changes.

Still stop with **Q** when you can. This is the seatbelt, not the brakes.

## The terminal way
Double-click **`The Quill.bat`**. You get the studio menu:
- **[1] Record** — pick a label (e.g. `saltmere-harbour-riot`), leave the window open through the game.
  - Press **M** anytime to **mark a moment**. Optional one-line note.
  - Press **Q** to stop — Q saves the file; don't just close the window.
- **[2] Transcribe (fast)** — `small.en`. Good for a close mic / quiet room.
- **[3] Transcribe (high accuracy)** — `medium.en`. Sharper. With the GPU (see below) this is now the default choice — it's fast either way.
- **[6] Session ledger** — every transcription auto-logs a line in `SESSION-LOG.md` (date, session, duration, model).
- **[8] Mine a transcript** — pick a session, get a digest: health, your marks with the audio before
  them, names your table said that aren't in your lexicon or your notes, and the densest stretches.
  Writes `transcripts\<session>_digest.md`. See below.
- **[D] Pre-game check** — is this machine actually ready to record?

## How marks work (pin in the tail, not a prophecy)
A mark is **retroactive** — you press M *just after* something big lands, and it pins
the timestamp of the press. The moment itself sits shortly **before** the pin, and
whoever builds the recap reads backward from each mark. So:
- Big reveal happens → *then* you press M. No need to see it coming.
- Moment slipped by ten minutes ago? Mark it now with a note like `the reveal w/ Corrin, ~10 min back` — the note aims the search, the timestamp just says where you were when you remembered.
- Marks land in `recordings\<name>.markers.txt` and get copied into the transcript header as **MARKED MOMENTS**, so they're the first thing visible when prepping the recap.
- **Mistap? Take it back.** `[U]` in the terminal studio, **⤺ undo last pin** on the web
  page, or the **undo last pin** button on the floating marker. All three edit the same
  file and all three re-read it before undoing, so they never resurrect each other's
  deletions — you can pin from your phone and undo from the laptop.

## Mine the transcript (the step that makes it worth doing)

A six-hour session is 120 KB of unpunctuated table talk. Nobody reads that. So:

```
python Mine-Transcript.py transcripts\<session>.txt
python Mine-Transcript.py transcripts\          # just uses the newest
python Mine-Transcript.py transcripts\<session>.txt --out digest.md
```

Four things come back:

1. **Health** — did the transcription actually capture the room? See the warning below.
2. **Marked moments** — every `[M]` pin with the 90 seconds *before* it, because marks are retroactive.
3. **Names your table said that `lexicon.txt` doesn't know**, split two ways — the ones already in
   your campaign files (**paste those into `lexicon.txt`**; the model was guessing at them all
   session) and the ones in **no file you have**. That second list is the point: nicknames the
   table coined, NPCs you improvised, places you invented mid-sentence. Write them down or lose them.
4. **Densest stretches** — where the table leaned in.

## The Chorus — one track per voice, so the transcript knows who spoke

Working out who is talking from one room microphone is genuinely hard, and five people
talking over each other defeats it. So the Chorus doesn't try. **If every voice records
itself, the speaker isn't inferred — it's known.**

### Rehearse it first

You are about to ask several people to put their phones down and trust that your
laptop is catching all of it. Normally you find out whether that was true at the
merge — the morning after, when the session is gone and nobody is going to say any
of it again.

So don't find out then. **`[R] Rehearse the Chorus`** in the terminal studio (or
`python Quill-Rehearsal.py`) invents a table, gives every seat a real speaking
voice, and pushes their audio through the *same* path a phone uses — chunks in
order, table code and all. Then it merges and reads the braid back. It takes a
couple of minutes, runs on its own port so it can't disturb a live game, and
deletes everything it made.

Sixteen checks, and these are the two that matter:

- **Every voice's words come back under that voice's own name**, and under nobody
  else's. That is the entire promise of the Chorus — speaker *known*, not inferred.
- **A latecomer lands where the clock says.** One seat joins deliberately late, so
  its audio starts at zero in its own file. If the offset were ever dropped, their
  line would appear at the top of the night instead of in the middle of it. (That
  is not hypothetical: the check was written by breaking the merge on purpose and
  confirming the rehearsal refuses to pass. Every other check stayed green — only
  this one noticed.)

If it ends with *"do not trust the Chorus tonight,"* believe it, and run the plain
single-mic recording instead.

### Running one

1. Start the **web studio** — `Gnashers Quill Web.bat` — and press
   **● RECORD + ♫ CHORUS**. One button, and it matters which way round: the Chorus adopts
   your recording's clock only while that recording is *live*, so starting both together
   is what puts **your own voice on the players' timeline**. Open the Chorus first, or
   start recording afterwards, and you quietly end up missing from your own merge.
   (Want the players' tracks only, no room mic? **♫ Open the Chorus** on its own still works.)
2. Each player opens the join link shown on the page — `http://<your-ip>:8020/chorus?t=CODE`
   — on **their own phone**, types their name, and taps **I'm in — join the table**.
   **The `?t=` part is the table code and it matters:** it is the only thing stopping
   someone else on the same wifi writing audio into your session. Send the whole link
   (tap it on the studio page to copy). A phone that opens the bare `/chorus` URL is
   told to ask you for the real link.
3. Play. The page shows each voice, its offset, and how much has arrived. A phone that
   goes quiet — pocketed, screen locked, wandered out of range — turns **red on the voice
   table within 20 seconds**, saying how long it has been silent. Its owner's screen still
   says "recording", so this row is the only warning you get, and it is worth a glance
   between scenes: the alternative is finding out at the merge that a voice is an hour short.
4. Afterwards: **Close the Chorus** — the **⚒ MERGE** button appears right there in the
   web studio and streams its progress onto the page. (**[T]** in the terminal studio
   still works and adds session/model prompts.)

Every device records its own microphone locally and streams to your laptop over Wi-Fi.
**Nothing leaves the room.**

### What you get

```
[01:42:08 -> 01:42:13] [DM]      The warden's hands are shaking.
[01:42:15 -> 01:42:17] [KRIS]    I step between them.
[01:42:19 -> 01:42:23] [GARTHAX] Bad idea. I ready an action.
```

That's the ordinary Quill segment format with the speaker inside the line, so
**Mine-Transcript, the Ledger, the Concordance and the Mirror all read a Chorus transcript
with no changes.** The Mirror gains a section it can't produce any other way — **who
actually got to talk**, measured rather than estimated. That's the quiet player nobody
notices from behind the screen.

### Remote tables get this for free

Playing over voice chat? Each player's phone records their **local** mic — nobody has to
capture the call, and nobody's audio is degraded by it. Same merge, same transcript,
whether the table is one room or five states.

### Honest limits

- **Phones stop the mic when the screen locks.** The page requests a wake lock, but if a
  phone sleeps anyway, that player reopens the page and rejoins — everything already
  uploaded is safe on disk.
- **Clock sync is one LAN round-trip**, tens of milliseconds, against segments measured in
  seconds. The server stamps each track's offset when the device actually starts recording,
  and writes it into `chorus.json` so the merge shows its work.
- **A dropped phone costs that voice only.** The others merge normally and the transcript
  header names which track came up short.
- Tracks land in `recordings/chorus/<session>/`. Chunks are flushed and fsync'd as they
  arrive, so a laptop that dies mid-session still leaves usable tracks.
- **Disk is checked.** A Chorus session refuses to open below 3 GB free, and stops
  accepting audio below 512 MB, so a full disk can never take your own recording down
  with it. Five phones for five hours is roughly 1.5 GB.
- **Restarting the studio ends the session.** Track files on disk are safe and still
  merge, but phones cannot rejoin an interrupted session — they would need a new one.

## What the studio exposes on your network

The web studio listens on every interface, because that is how phones reach it. Since
2026-07-31 it does not take that on trust:

| | who can use it |
|---|---|
| start/stop recording · transcribe · **read transcripts** | **only the machine running the studio** |
| the Chorus (join, upload, leave) | anyone holding the **table code** from the join link |
| status, the phone MARK button, and undo | anyone on the network |

Before this, anyone on the same wifi could start or stop your recording, pin your GPU,
and **read any transcript of your campaign**. At home that was nothing. At a convention,
a game store, or a shared flat it was somebody reading your game.

**And "only this machine" is checked twice.** A loopback check alone answers *"did this
come from this machine?"* — it cannot answer *"did a human here mean it?"* A web page can
publish a hostname that re-resolves to `127.0.0.1`, and the browser will happily carry its
requests to the studio *from* `127.0.0.1`. So the studio also refuses any request that
arrives under a **name**: `localhost` and plain IP addresses are accepted, anything else
gets a 421. That is every way you or a phone actually reach it, and rebinding needs a name
to re-resolve, so the attack has nothing to stand on. Cross-site POSTs are refused too.

It is still a LAN tool with a shared code, not a hardened server. Don't run it on a
network you would not hand a USB stick to.

## Asking the table

The join screen tells every player, in their own hands, exactly what is about to happen —
that their phone records their own voice, that it goes to your laptop, that it stays there,
and that they can stop whenever they like. Tapping **I'm in** is the consent, given at the
moment it matters rather than promised in a README they never read. Still ask out loud.
A recorder nobody agreed to is a betrayal, not a tool.

## Tell it where your notes are (one answer, four questions)

Four of these tools want to know the same thing: **is this name new at the table, or
something you already wrote down?** The Cold Open asks it to spot what you'd otherwise
lose. The Mirror asks it to measure prep against improvisation. The Concordance asks it
to mark names *written* or *UNWRITTEN*. The Lexicon asks it to decide what to teach the
transcriber.

Put your notes folder in **`NOTES.txt`**, one per line — or set it in the web studio under
**The House → Campaign notes**, which writes the same file. Anything readable as text
works: markdown, an Obsidian vault, exported OneNote, a folder of session write-ups.

**Until you do, all four still run — but they run blind, and they say so.** They will not
tell you a name is "recorded nowhere else" when they never opened your notes to check.
That distinction is the whole reason to bother: a report that quietly guesses is worse
than one that admits what it doesn't know.

`--canon` (or `--notes` on the Lexicon) still overrides per-run, and `--canon ""` skips
notes entirely.

## Campaign reports — the tools that read ACROSS sessions

Menu **[9]**, or run them directly. These get more useful the longer you play.

### The Reading Room — every sheet, in the web studio

They are all plain markdown files in the Quill folder, and for a long time that is the
only place you could read them: you built them from a menu, then went and found them in
a folder. The web studio now has a **Reading Room** at the top of the page — one card,
five tabs, **Cold Open · Mirror · Ledger · Concordance · Session Log** — that renders each
one, tells you which is out of date, and rebuilds any of them (or all four) with a button.

Three things it does that a folder cannot:

- **A dot on a tab means that sheet is stale.** The Cold Open and the Mirror are about one
  night, so they name the night they were built from; the Ledger and the Concordance read
  every transcript there is, so they simply go stale when any of them changes. Finish a
  transcription or a Chorus merge and the dots appear on their own.
- **The Ledger's boxes are real checkboxes.** Tick a promise off from the page and it
  writes the tick into `LEDGER.md` — one character, on one line, leaving every note you
  have written in that file exactly where it was.
- **The Session Log has no Rebuild button, because it has nothing to rebuild.** The other
  four are summaries, and a summary can fall behind. This one is `SESSION-LOG.md`, which
  gains a row the moment a transcription finishes — so it is never stale, and the tab
  shows no button and no dot rather than a control that would do nothing.

The sheets are quotes from your own table, so like the transcripts they are readable
**only on the machine running the studio.** A phone on the table cannot open them.

### The rest of the studio, in the browser

The terminal had four things the web face did not. It has them now, so you can run a
whole campaign from either one:

- **⌕ mine** on any scribed session in **The Shelf** — the per-session digest: how healthy
  that transcript is, every mark with the audio just before it, and the names your table
  said that `lexicon.txt` doesn't know.
- **Pre-game check** in **The House** — the full `Quill-Doctor` run, streamed onto the page.
  (It stays a PowerShell script rather than being rewritten in Python: two health checks
  that could disagree with each other is worse than one.)
- **Rehearse the Chorus**, same card — the whole fake-table run without leaving the browser.
- **Suggest names** — point it at your campaign notes and it lists the proper nouns worth
  teaching the transcriber, **with a tick box each.** This is the one place the web face is
  better than the terminal: `[X]` there asks *y/N to the entire list*, and half of any list
  is your players' real first names. Here you take the three that are real and leave the rest.

Only the folder shortcuts stayed behind — a browser opening File Explorer is a spawned
process for no real gain, and the paths are printed on the page anyway.

### `LEDGER.md` — what you owe your players

```
python Quill-Ledger.py
```

Promises, debts, bargains and threats that were **spoken aloud, in fiction**, across every
session, each with its timestamp and whether an NPC or the party made the commitment.

A campaign doesn't die because you forgot last session. It dies because in session 4 an NPC
said *"come back when you have the seal"*, the players wrote it down, and you never did.

**LEDGER.md is yours to edit.** Tick `- [x]` when a debt is paid — by hand, or by clicking
the box in the Reading Room. Write notes under any entry. Delete ones you don't care about.
Re-running never overwrites your edits — entries are keyed by session and timestamp, and
deleted ones stay deleted.

### `CONCORDANCE.md` — a who's-who that builds itself

```
python Quill-Concordance.py
python Quill-Concordance.py --find Rasseter        # every mention, every session
python Quill-Concordance.py --find "silk debt" --context 2
```

Every name across every night: how many sessions it survived, when you first heard it, and
whether it's **written down in your campaign notes or exists nowhere but the recording.**
The search alone is worth it — *"when did we first meet Meera?"* is one command.

### `COLD-OPEN.md` — the page you read before the players arrive — menu **[O]**

```
python Quill-ColdOpen.py
```

Everything you need for "right — previously…", on one page, in the order you need it:
**how it ended** (the last real scene, quoted verbatim from your own recording),
**what you pinned**, **what you still owe** (open entries from the Ledger),
**who turned up that you never wrote down**, and **where they leaned in** — the densest
stretch of the night, which is usually the safest thing to open on.

It invents nothing. Every line is a quote with a timestamp you can go back and listen to.

### `MIRROR.md` — how you ran it, not what happened

```
python Quill-Mirror.py transcripts
```

The shape of the night as a sparkline, where the clock went (combat / story / table talk),
your longest unbroken stretch of narration, and every gap of dead air.

With `NOTES.txt` set it adds **prep against improvisation**: of the names your table said
more than once tonight, how many were already in your notes and how many arrived at the
table — with the new ones listed, because those exist nowhere but the recording until you
write them down. Neither number is the good one. A night of pure prep and a night of pure
improv are both real ways to run a game; most DMs have simply never seen their own ratio.

One mic can't tell who's speaking, so everything is marked as an estimate and there's an
honest **"couldn't tell"** bucket rather than a made-up number. Only about a quarter of a
real session's lines carry a marker of their own; the rest are labelled from what was
happening either side of them, because scenes have duration. The report says how many were
read directly and how many were inferred. `--window 0` turns the inference off. Per-player airtime needs the
Chorus (one track per person) and is deliberately not guessed at.

### `SESSION-LOG.md` — the transcription history

Nothing to run. It gains a row every time a transcription finishes, and it is the fifth
tab in the Reading Room.

It looks like a duplicate of **The Shelf** and isn't. The Shelf lists what is in your
`recordings\` folder — how big, how many marks, scribed or not. This lists **the work**:
the date the transcription ran, how long the night actually was, which model heard it,
and how many segments came back. Four things follow from that which the Shelf can't tell
you:

- **A second row appears when you re-run a session.** The Shelf just keeps showing ✓ — it
  cannot tell you that this transcript is the `medium.en` re-run rather than the first
  `small.en` pass.
- **Segment count is the cheap health tell.** Fifty segments for a five-hour night means
  the transcription didn't hear the room (see the VAD warning above).
- **It outlives the audio.** Delete a 400 MB `.m4a` and the session drops off the Shelf
  entirely; the log still says the night happened, how long it ran, and links the transcript.
- **Click a session name and its transcript opens** in the same reader the Shelf uses.

### Rebuild the lexicon from notes you already wrote — menu **[X]**

```
python Quill-Lexicon.py             # show what it would add
python Quill-Lexicon.py --write     # add it
```

Nobody hand-types sixty proper nouns before their first session — so most people skip the
lexicon and get a worse transcript forever. The names are already in your campaign notes.
This reads them, skips ordinary words that merely get title-cased (`Gate`, `Watch`, `Prince` —
feeding those as hints makes the model mis-hear them), and appends suggestions in a marked
block. **Your own entries and line endings are left byte-for-byte alone.**

## ⚠ Check the timestamps on any transcript made before 2026-07-30

There was a real bug here, and it was silent.

The voice-activity detector had **no cap** on how long one unbroken "speech" stretch could be. At a
real table there is never a clean pause — five people, dice, snacks — so it merged minutes of room
noise into a single stretch, and the model returned **one line for the whole thing.** On the
2026-07-19 session (5h58m) the median chunk covered **31 seconds**; one covered 67 seconds and said,
in full: `Okay.`

Fixed 2026-07-30 in `transcribe.py` (`max_speech_duration_s`, tighter silence threshold, word-level
timestamps). Measured on a 20-minute slice of that same audio: median chunk **30.7s → 6.2s**, long
stretches yielding ≤3 words **4 → 0**, speech density **+56%**.

**If you have old transcripts, run `Mine-Transcript.py` on them.** If health says **BAD**, the audio
is still in `recordings\` — just transcribe it again. Nothing was lost that a re-run won't recover.

Two knobs if a room is especially loud: `--max-speech 12` (split harder) and `--no-hotwords` (if the
model starts chanting campaign names over quiet stretches instead of transcribing them).

## The lexicon (make it spell your world right)
`lexicon.txt` is a plain list of campaign proper nouns — PCs, NPCs, wards, places.
The transcriber feeds it to the speech model as spelling hints, so you get
"Vethric Ashgrave" and "the Undercroft" instead of phonetic soup. **When a new NPC enters the
campaign, add the name to lexicon.txt.** Takes effect next transcription.

## The manual way (if you recorded elsewhere)
1. Record the session however you like — **a phone's voice recorder app works great**. One file.
2. Move it into `Quill\recordings\` and name it `2026-07-19_saltmere-shackles.m4a` (date + campaign + what happened). Any audio format works (.m4a/.mp3/.wav/...).
3. Right-click **`Transcribe-Session.ps1`** → **Run with PowerShell** (or use menu [2]/[3]).
   A `.txt` lands in `Quill\transcripts\`.

## What it runs on
- **The studio itself is Windows-only** (PowerShell + ffmpeg + Python) — a laptop, a Windows tablet,
  any Windows machine. **You do not have to set any of that up by hand:** double-click
  **`SETUP (run me first).bat`** and it installs Python, ffmpeg and `faster-whisper`, then verifies
  the whole chain. Nothing in this folder needs its paths edited.
- **Phones and iPads can't run the studio, but they can join it** as a remote MARK button via the
  web studio (same Wi-Fi), or by recording audio with any voice-recorder app and dropping the file
  into `recordings\`.
  - ⚠ **The Chorus cannot use a phone as a microphone over plain Wi-Fi.** Browsers only hand out the
    mic on `https://` or on the machine itself, and the studio serves plain `http://` on a LAN
    address — so the join page will say so and disable its own record button. The Chorus works from
    the studio machine; multi-phone recording needs HTTPS and is not solved in this build.
- **Windows Firewall:** the first time you start the web studio, Windows asks whether to allow it.
  Tick **Private networks** and Allow, or no phone on your Wi-Fi can reach the MARK button.
- **GPU:** transcription auto-detects CUDA and uses it — on an RTX-class GPU an hours-long session
  takes a couple of minutes. No GPU? It falls back to CPU: same results, much slower.
  Force CPU with `python transcribe.py <file> --cpu`.
- **How long CPU actually takes.** Budget roughly **1–2× the session length on `small.en`** and
  **2–4× on `medium.en`**. A six-hour game on a CPU-only laptop is an overnight run, not a coffee
  break — start it when you go to bed. `medium.en` also wants ~2–3 GB of free RAM. If you have no
  GPU, prefer **`[2] small.en`**.
- **Disk:** the model cache lives under your user profile on `C:` even if the Quill is on another
  drive — `small.en` is ~500 MB, `medium.en` ~1.5 GB, and the Chorus wants 3 GB free for a night.

## How it actually works (no AI at the table)
- **ffmpeg** captures the mic to a small mono 16kHz `.m4a` (~40MB/hr).
- **faster-whisper** (Whisper `small.en` / `medium.en`) turns sound → text, on GPU or CPU.
  This is a *speech-to-text* model — ears only. It doesn't understand or summarize.
  It reads `lexicon.txt` as hotword hints and transcribes each window independently
  (stops the repetition-loop hallucinations long noisy recordings can cause).
- The transcription step needs zero internet after the first model download — the table
  never depends on a connection.

## Good to know
- **It doesn't tell speakers apart** (no "who said what") — one running transcript.
  Say a name out loud at big moments ("okay, Corrin just cracked") and mark it with **M** —
  between the two, the beat is easy to reconstruct.
- **Raw transcripts are backup** — they don't get deleted when recaps are built from them.
- **Speaker diarization** (who-said-what) is the one big feature deliberately left out:
  it needs an extra model and one-room crosstalk defeats it anyway. Future item.
