# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Lexicon — build the campaign lexicon from notes you already wrote.

`lexicon.txt` is what makes the transcriber spell "Vethric Ashgrave" instead of phonetic
soup. It is also the single worst setup chore in the Quill: nobody is going to hand-type
sixty proper nouns before their first session, so most people will skip it and get a
worse transcript forever.

They don't have to. The names are already sitting in your campaign notes.

    python Quill-Lexicon.py                 # show what it would add, change nothing
    python Quill-Lexicon.py --write         # actually update lexicon.txt
    python Quill-Lexicon.py --notes ../MyCampaign --write

WHAT IT WILL NOT DO
    It never deletes or reorders what you wrote. Your hand-curated entries and your
    comments are preserved exactly; suggestions land in a clearly marked block at the
    end that you can prune or delete wholesale. Run it again any time.

WHY A CAP
    The lexicon is fed to the model as spelling *hints*. Too many hints and it starts
    chanting names over quiet audio instead of transcribing -- a real failure we
    measured on a live session. Default ceiling is 80, which matches the file's own
    guidance. Frequency in your notes decides who makes the cut.
"""
import os
import re
import sys
import argparse
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import (HERE, STOP, load_lexicon, pick_transcripts, load_segments,
                       notes_roots)

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# Words that are capitalised all over TTRPG notes but are not campaign nouns.
GAME_STOP = set("""
strength dexterity constitution intelligence wisdom charisma
acrobatics arcana athletics deception history insight intimidation investigation
medicine nature perception performance persuasion religion sleight stealth survival
fighter wizard rogue cleric bard druid monk paladin ranger sorcerer warlock barbarian
artificer human elf dwarf halfling gnome orc tiefling dragonborn
armor armour weapon shield potion scroll wand ring amulet cloak
session sessions chapter arc act scene encounter combat initiative
dungeon master player character npc npcs pc pcs dm gm
challenge rating hit dice speed senses languages actions reactions traits
lawful chaotic neutral good evil
note notes summary overview index appendix contents introduction reference
campaign world setting map maps handout handouts
""".split())

# Proper noun: capitalised, appearing MID-SENTENCE (preceded by an ordinary word).
# Headings capitalise everything, so a title-only word proves nothing.
MID = re.compile(r"(?<=[a-z,;)]\s)([A-Z][a-z'\-]{2,}(?:\s+[A-Z][a-z'\-]{2,}){0,2})\b")

TEXT_EXT = (".md", ".txt")


def normalise(name):
    """"the Magistrate's" and "the Magistrate" are the same hint. Keep the base form."""
    return re.sub(r"['’]s$", "", name).strip()


def harvest_notes(roots):
    counts, ctx = Counter(), {}
    lower_counts = Counter()      # how often the same word appears in lower case
    files = 0
    for root in roots:
        if not os.path.isdir(root):
            continue
        for dirpath, _dirs, names in os.walk(root):
            for n in names:
                if not n.lower().endswith(TEXT_EXT):
                    continue
                p = os.path.join(dirpath, n)
                try:
                    body = open(p, encoding="utf-8", errors="ignore").read()
                except Exception:
                    continue
                files += 1
                body = re.sub(r"```.*?```", " ", body, flags=re.S)   # skip code blocks
                body = re.sub(r"\|", " ", body)                       # and table pipes
                for m in MID.finditer(body):
                    name = normalise(m.group(1))
                    words = name.split()
                    if not words:
                        continue
                    if any(w.lower() in STOP or w.lower() in GAME_STOP for w in words):
                        continue
                    counts[name] += 1
                    ctx.setdefault(name, os.path.relpath(p, root))
                for w in re.findall(r"\b[a-z][a-z'\-]{2,}\b", body):
                    lower_counts[w] += 1
    return counts, ctx, files, lower_counts


def proper_ratio(name, counts, lower_counts):
    """How reliably is this word a NAME rather than an ordinary word?

    "Valdren" never appears lower case. "gate", "watch", "prince" and "seat" do,
    constantly -- they are ordinary words that happen to get title-cased. Feeding those
    to the transcriber as spelling hints is worse than useless: it biases the model
    toward hearing "Gate" every time somebody says "gate". Multi-word names are safe
    by construction, so they skip the test."""
    if " " in name:
        return 1.0
    cap = counts[name]
    low = lower_counts.get(name.lower(), 0)
    return cap / (cap + low) if (cap + low) else 0.0


def harvest_transcripts(folder):
    """Names actually SAID at the table carry more weight than names only written."""
    said = Counter()
    for f in pick_transcripts(folder):
        _h, segs = load_segments(f)
        for _a, _b, text in segs:
            for m in MID.finditer(text):
                name = m.group(1).strip()
                if any(w.lower() in STOP or w.lower() in GAME_STOP for w in name.split()):
                    continue
                said[name] += 1
    return said


def merge_into_lexicon(path, additions):
    """Append a marked block. Never touches a line the human wrote.

    newline="" on BOTH ends is not decoration. Without it Python helpfully rewrites
    every line ending in the file to the platform default -- so a tool whose whole
    promise is "I don't touch what you wrote" silently reformats all 71 of your lines
    the first time it runs. Read raw, detect what the file already uses, match it."""
    existing = ""
    if os.path.exists(path):
        with open(path, encoding="utf-8", newline="") as f:
            existing = f.read()
    eol = "\r\n" if existing.count("\r\n") > existing.count("\n") - existing.count("\r\n") else "\n"

    # The block is REBUILT every run, and that broke its own promise twice over.
    #
    #   Accepted names vanished. A name suggested last week is now IN the file,
    #   so load_lexicon() counts it as already covered, so it is not in this
    #   run's picks -- and rebuilding from picks alone deleted it. Measured: run
    #   one added "Valdren" and "Salt Compact"; run two left only the new name.
    #   The transcriber then quietly stopped spelling them right, which reads as
    #   the lexicon forgetting your NPCs at random.
    #
    #   Pruned names came back. Delete a bad suggestion -- a player's real name,
    #   say -- and it is no longer in the file, so it is no longer "covered", so
    #   the very next run offers it again. "Prune freely" was never true.
    #
    # Both need one thing the file did not record: what has been OFFERED before,
    # as distinct from what is in it now. With that, kept = still wanted, and
    # offered-minus-kept = deliberately thrown away. A bad hint actively harms
    # transcription, so a name the DM removed must stay removed.
    marker = "# --- suggested by Quill-Lexicon.py (prune freely) ---"
    OFFERED = "# offered:"
    NOTE = "# delete any line below and it will not be suggested again."
    kept, offered = [], []
    if marker in existing:
        head, _sep, tail = existing.partition(marker)
        for ln in tail.splitlines():
            s = ln.strip()
            if s.startswith(OFFERED):
                offered = [x.strip() for x in s[len(OFFERED):].split("|") if x.strip()]
            elif s and not s.startswith("#"):
                kept.append(s)
        existing = head
    existing = existing.rstrip("\r\n")

    ever = set(offered) | set(kept)
    merged = kept + [n for n in additions if n not in ever]
    ever |= set(merged)

    lines = [marker, NOTE, OFFERED + " " + " | ".join(sorted(ever))] + merged
    block = eol * 2 + eol.join(lines) + eol
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(existing + block)


def main():
    ap = argparse.ArgumentParser(description="Build lexicon.txt from your campaign notes.")
    ap.add_argument("--notes", default=None,
                    help="comma-separated folders of campaign notes "
                         "(unset uses NOTES.txt)")
    ap.add_argument("--transcripts", default=os.path.join(HERE, "transcripts"))
    ap.add_argument("--lexicon", default=os.path.join(HERE, "lexicon.txt"))
    ap.add_argument("--cap", type=int, default=80, help="max total entries (default 80)")
    ap.add_argument("--min-hits", type=int, default=4,
                    help="ignore names appearing fewer times than this in your notes")
    ap.add_argument("--ratio", type=float, default=0.75,
                    help="how strongly a word must prefer being capitalised to count as a "
                         "name (0-1, default 0.75). Lower it to let more common words in.")
    ap.add_argument("--write", action="store_true", help="actually update lexicon.txt")
    ap.add_argument("--only", action="append", default=None, metavar="NAME",
                    help="write just these names (repeatable). The web studio uses it to "
                         "add suggestions one at a time; without it --write takes the lot, "
                         "which usually includes your players' real names.")
    a = ap.parse_args()

    roots = notes_roots(a.notes or "")

    counts, ctx, nfiles, lower_counts = harvest_notes(roots)
    said = harvest_transcripts(a.transcripts)
    current = load_lexicon(a.lexicon)
    # Compare on a flattened key so "the Free Tribes" already in the file blocks "Jura Dai"
    # from being suggested as if it were a different name.
    def key(s):
        return re.sub(r"[\s'\-]+", "", s).lower()
    have = {key(c) for c in current}
    have |= {w.lower() for c in current for w in re.split(r"[\s'\-]+", c) if w}

    # Score: how often it is written, weighted up hard if the table has said it aloud.
    scored, rejected = [], 0
    for name, n in counts.items():
        if n < a.min_hits or key(name) in have or name.lower() in have:
            continue
        if proper_ratio(name, counts, lower_counts) < a.ratio:
            rejected += 1
            continue
        spoken = said.get(normalise(name), 0)
        scored.append((n + spoken * 3, n, spoken, name))
    scored.sort(reverse=True)

    room = max(0, a.cap - len(current))
    picks = scored[:room]

    print(f"scanned {nfiles} note file(s) in {', '.join(os.path.basename(r) for r in roots)}")
    print(f"lexicon has {len(current)} entries; cap {a.cap} leaves room for {room}")
    print(f"{len(scored)} candidate(s) not already covered "
          f"({rejected} rejected as ordinary words that merely get title-cased)\n")
    if not picks:
        print("nothing to add.")
        return 0

    print(f"{'name':<28}{'in notes':>9}{'said':>6}   first seen in")
    for _s, n, spoken, name in picks:
        print(f"{name:<28}{n:>9}{spoken:>6}   {ctx.get(name,'')[:38]}")

    if not a.write:
        print("\n(dry run — pass --write to add these to lexicon.txt)")
        return 0

    chosen = [p[3] for p in picks]
    if a.only:
        want = set(a.only)
        chosen = [n for n in chosen if n in want]
        missed = want - set(chosen)
        if missed:
            # Usually means the page was showing a stale list. Say so rather than
            # writing a subset and reporting success.
            print(f"\nnot offered right now, so not written: {', '.join(sorted(missed))}")
        if not chosen:
            print("nothing to add.")
            return 0

    merge_into_lexicon(a.lexicon, chosen)
    print(f"\nadded {len(chosen)} entr(y/ies) -> {a.lexicon}")
    print("Everything you wrote yourself is untouched; suggestions are in a marked block.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
