#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
quill_server.py - Gnasher's Quill, web studio edition.

A tiny local web server wrapping the same engine as the terminal studio:
ffmpeg records, faster-whisper transcribes (via transcribe.py), everything
stays on this machine. Open the page on a phone on the same Wi-Fi and the
phone becomes a remote MARK button for the table.

Run:  python quill_server.py        (or double-click "Gnashers Quill Web.bat")
Stop: close the console window (Ctrl+C).

No new dependencies - Python standard library only.
"""
import glob
import ipaddress
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from quill_chorus import chorus, free_bytes
from quill_lib import pick_transcripts
import quill_platform as P

HERE        = Path(__file__).resolve().parent
RECORDINGS  = HERE / "recordings"
TRANSCRIPTS = HERE / "transcripts"
WEB_PAGE    = HERE / "web" / "index.html"
SESSION_LOG = HERE / "SESSION-LOG.md"
COLD_OPEN   = HERE / "COLD-OPEN.md"
                            # QUILL_PORT lets the rehearsal stand up its own studio
                            # on another port without disturbing a live session.
PORT        = int(os.environ.get("QUILL_PORT") or 8020)

RECORDINGS.mkdir(exist_ok=True)
TRANSCRIPTS.mkdir(exist_ok=True)

AUDIO_EXTS = {".m4a", ".mp3", ".wav", ".flac", ".ogg", ".wma", ".aac", ".mp4"}

# ---------------------------------------------------------------- helpers ----

def find_ffmpeg():
    """Delegated to quill_platform so Windows/macOS/Linux stay in step."""
    return P.find_ffmpeg()

def find_mic(ff):
    """Default input device id for THIS platform (a dshow name on Windows, an
    avfoundation index on macOS, a pulse source on Linux)."""
    return P.default_mic(ff)

def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"

def fmt_elapsed(seconds):
    seconds = int(seconds)
    return f"{seconds // 3600:02d}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"

# ------------------------------------------------------------- recorder ------

class Recorder:
    """One recording at a time; same piped-stdin graceful-stop as the terminal studio."""
    def __init__(self):
        self.lock = threading.Lock()
        self.proc = None
        self.name = None
        self.out = None
        self.markfile = None
        self.started = None          # monotonic, for elapsed display
        self.started_wall = None     # wall clock, so the Chorus can share this timeline
        self.marks = []

    def active(self):
        return self.proc is not None and self.proc.poll() is None

    def started_epoch(self):
        """Wall-clock start, or None. The Chorus uses this so every phone's track
        offset is measured against the DM's recording rather than its own join time."""
        return self.started_wall if self.active() else None

    def master_path(self):
        """The LIVE recording's file, or None -- guarded by active() exactly like
        started_epoch(). self.out deliberately survives stop() (the size report
        reads it afterwards), so an unguarded read here handed a FINISHED
        recording to the next Chorus session, and last week's audio was merged
        into tonight's transcript as the DM's voice, at offset 0, silently."""
        return self.out if self.active() else None

    def start(self, label):
        with self.lock:
            if self.active():
                return {"ok": False, "error": "Already recording."}
            ff = find_ffmpeg()
            if not ff:
                return {"ok": False, "error": "ffmpeg not found on this machine."}
            mic = find_mic(ff)
            if not mic:
                return {"ok": False, "error": "No microphone detected."}
            stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
            clean = re.sub(r"[^\w\-]", "-", label.strip()) if label.strip() else ""
            self.name = f"{stamp}_{clean}" if clean else stamp
            self.out = RECORDINGS / f"{self.name}.m4a"
            self.markfile = RECORDINGS / f"{self.name}.markers.txt"
            self.marks = []
            # One definition of the record command, in quill_platform, shared with the
            # terminal studio -- including the crash-safe fragmented-MP4 flags.
            self.proc = subprocess.Popen(
                P.record_command(ff, mic, self.out),
                stdin=subprocess.PIPE)
            self.started = time.monotonic()
            self.started_wall = time.time()
            return {"ok": True, "name": self.name, "mic": mic}

    def mark(self, note):
        with self.lock:
            if not self.active():
                return {"ok": False, "error": "Not recording."}
            ts = fmt_elapsed(time.monotonic() - self.started)
            entry = f"[{ts}] {note.strip()}" if note.strip() else f"[{ts}]"
            self.marks.append(entry)
            with open(self.markfile, "a", encoding="utf-8") as f:
                f.write(entry + "\n")
            return {"ok": True, "entry": entry}

    def unmark(self):
        """Take back the last pin. The marking flow is one tap, at a table, in
        the dark, often on a phone -- so a mistap is easy and was permanent.

        The FILE is the authority here, not self.marks: the floating marker is a
        separate process writing the same file, so rebuilding the list from disk
        is what keeps the two faces agreeing instead of resurrecting each other's
        deleted lines."""
        with self.lock:
            if not self.active():
                return {"ok": False, "error": "Not recording."}
            try:
                lines = [ln for ln in self.markfile.read_text(
                    encoding="utf-8-sig").splitlines() if ln.strip()]
            except OSError:
                lines = []
            if not lines:
                self.marks = []
                return {"ok": False, "error": "No moments to take back."}
            gone = lines.pop()
            self.markfile.write_text(
                "".join(ln + "\n" for ln in lines), encoding="utf-8")
            self.marks = lines
            return {"ok": True, "removed": gone, "left": len(lines)}

    def stop(self):
        with self.lock:
            if self.proc is None:
                return {"ok": False, "error": "Not recording."}
            proc, out, name, marks = self.proc, self.out, self.name, list(self.marks)
            try:
                proc.stdin.write(b"q")
                proc.stdin.flush()
            except OSError:
                pass
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                try:
                    proc.stdin.close()
                    proc.wait(timeout=5)
                except (OSError, subprocess.TimeoutExpired):
                    proc.kill()
            self.proc = None
            self.started = None
            self.started_wall = None
            ok = out.exists() and out.stat().st_size > 10_240
            mb = round(out.stat().st_size / 1_048_576, 1) if out.exists() else 0
            return {"ok": ok, "name": name, "mb": mb, "marks": len(marks),
                    "error": None if ok else "File looks empty - mic muted or blocked?"}

    def status(self):
        if not self.active():
            return {"active": False}
        return {"active": True, "name": self.name,
                "elapsed": fmt_elapsed(time.monotonic() - self.started),
                "marks": list(self.marks)}

# ------------------------------------------------------------ transcriber ----

class Scribe:
    """Runs transcribe.py over untranscribed recordings, one at a time."""
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.log = []
        self.model = None

    def _log(self, line):
        with self.lock:
            self.log.append(line)
            self.log = self.log[-200:]

    def start(self, model):
        if merger.status()["running"]:
            return {"ok": False, "error": "The Chorus is merging - let it finish first."}
        with self.lock:
            if self.running:
                return {"ok": False, "error": "Already transcribing."}
            self.running = True
            self.model = model
            self.log = []
        threading.Thread(target=self._work, args=(model,), daemon=True).start()
        return {"ok": True}

    def _work(self, model):
        try:
            todo = [p for p in sorted(RECORDINGS.iterdir())
                    if p.suffix.lower() in AUDIO_EXTS
                    and not (TRANSCRIPTS / (p.stem + ".txt")).exists()]
            if not todo:
                self._log("Nothing new to transcribe.")
                return
            for audio in todo:
                self._log(f"=== {audio.name}  [model: {model}] ===")
                p = subprocess.Popen(
                    [sys.executable, str(HERE / "transcribe.py"), str(audio),
                     "--model", model],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace", bufsize=1)
                for line in p.stdout:
                    self._log(line.rstrip())
                p.wait()
                self._log(f"--- done (exit {p.returncode}) ---")
            self._log("All finished. Transcripts are in transcripts\\.")
        finally:
            with self.lock:
                self.running = False

    def status(self):
        with self.lock:
            return {"running": self.running, "model": self.model,
                    "log": list(self.log)}

# ------------------------------------------------------------------ merger ----

class Merger:
    """Runs Quill-Chorus.py: transcribe every voice, braid one transcript.

    This used to be the flow's cliff. The web studio ran the whole Chorus night,
    then ended with 'now go run python Quill-Chorus.py in a terminal' -- a
    context-switch to a command line at 11pm, at the exact moment of payoff.
    Same shape as the Scribe: one at a time, log streamed to the page."""
    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.log = []

    def _log(self, line):
        with self.lock:
            self.log.append(line)
            self.log = self.log[-200:]

    def start(self, model="medium.en"):
        # Scribe and Merger both spawn a whisper child; together they fight for
        # the same GPU and everything takes twice as long. One at a time.
        if scribe.status()["running"]:
            return {"ok": False, "error": "The scribe is working - let it finish first."}
        with self.lock:
            if self.running:
                return {"ok": False, "error": "Already merging."}
            self.running = True
            self.log = []
        threading.Thread(target=self._work, args=(model,), daemon=True).start()
        return {"ok": True}

    def _work(self, model):
        try:
            p = subprocess.Popen(
                [sys.executable, str(HERE / "Quill-Chorus.py"), "--model", model],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                cwd=str(HERE))
            for line in p.stdout:
                self._log(line.rstrip())
            p.wait()
            self._log(f"--- done (exit {p.returncode}) ---")
        finally:
            with self.lock:
                self.running = False

    def status(self):
        with self.lock:
            return {"running": self.running, "log": list(self.log)}

# --------------------------------------------------------------- sessions ----

def sessions():
    out = []
    for p in sorted(RECORDINGS.iterdir(), reverse=True):
        if p.suffix.lower() not in AUDIO_EXTS:
            continue
        markfile = RECORDINGS / (p.stem + ".markers.txt")
        nmarks = 0
        if markfile.exists():
            nmarks = len([ln for ln in markfile.read_text(
                encoding="utf-8-sig").splitlines() if ln.strip()])
        out.append({
            "name": p.stem,
            "mb": round(p.stat().st_size / 1_048_576, 1),
            "when": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
            "transcribed": (TRANSCRIPTS / (p.stem + ".txt")).exists(),
            "marks": nmarks,
        })
    # Merged Chorus nights are transcripts with no recording twin. List them so
    # a braided night is readable from the page -- and visibly DONE.
    for t in sorted(TRANSCRIPTS.glob("*_chorus.txt")):
        out.append({
            "name": t.stem,
            "mb": round(t.stat().st_size / 1_048_576, 1),
            "when": datetime.fromtimestamp(t.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
            "transcribed": True,
            "marks": 0,
            "chorus": True,
        })
    out.sort(key=lambda r: r["when"], reverse=True)
    return out

BOOT = {"sniffed": False, "ffmpeg": None, "mic": None}

def hearth():
    """Will tonight work? The web face's answer to the terminal studio's hearth
    line -- asked at the top of the page rather than discovered at 7pm.

    ffmpeg and the mic are sniffed ONCE: listing dshow devices spawns ffmpeg,
    which is far too heavy for a once-a-second poll. Free space is a syscall and
    genuinely changes during a night, so it stays live -- it is also the one that
    actually bites, since the Chorus refuses to open under 3 GB."""
    if not BOOT["sniffed"]:
        BOOT["ffmpeg"] = find_ffmpeg()
        BOOT["mic"] = find_mic(BOOT["ffmpeg"])
        BOOT["sniffed"] = True
    free = free_bytes()
    return {"ffmpeg": bool(BOOT["ffmpeg"]), "mic": BOOT["mic"],
            "free_gb": round(free / 1024**3, 1) if free else None}

# The sheets the campaign produces. The terminal studio has always been able to
# build all of them; the web face could only read one, so the others dead-ended
# in a folder exactly the way the cold open used to.
#
# `script: None` means A SHEET WITH NO GENERATOR. SESSION-LOG.md is written one
# row at a time by transcribe.py as each transcription finishes -- there is
# nothing to run and nothing to rebuild, so it can never be stale either: it is
# a record of what happened, not a summary that falls behind. The alternative
# was a second registry, which would have meant every reader of REPORTS growing
# a "...and also check the other dict" branch. One dict, one honest null.
REPORTS = {
    "coldopen":    {"file": "COLD-OPEN.md",   "script": "Quill-ColdOpen.py",    "args": [],
                    "title": "Cold Open",
                    "blurb": "the one page you read before the players arrive"},
    "mirror":      {"file": "MIRROR.md",      "script": "Quill-Mirror.py",
                    "args": ["transcripts", "--out", "MIRROR.md"],
                    "title": "Mirror",
                    "blurb": "how you actually ran the last night"},
    "ledger":      {"file": "LEDGER.md",      "script": "Quill-Ledger.py",      "args": [],
                    "title": "Ledger",
                    "blurb": "promises spoken aloud and still open — tick them off here"},
    "concordance": {"file": "CONCORDANCE.md", "script": "Quill-Concordance.py", "args": [],
                    "title": "Concordance",
                    "blurb": "who and what this campaign has said out loud"},
    # The Shelf below lists RECORDINGS -- what is on disk, how big, how many
    # marks, scribed or not. This lists TRANSCRIPTIONS -- the work, as it
    # happened. Different things, and the gaps are the point: the night's real
    # duration, which model heard it, a second row when you re-ran a session at
    # medium.en, and a row that survives after you delete the audio and the
    # session drops off the Shelf entirely.
    "log":         {"file": "SESSION-LOG.md", "script": None,                   "args": [],
                    "title": "Session Log",
                    "blurb": "every transcription as it happened — when it ran, how long "
                             "the night was, which model heard it. Written a row at a time; "
                             "there is nothing to rebuild."},
}

report_lock = threading.Lock()
cold_open_lock = report_lock            # the cold open was here first

# The terminal studio's THE HOUSE section, brought across. These are the checks
# and chores you run BEFORE a game or when something is wrong -- long enough to
# want a live log, so they stream exactly like the Scribe and the Merger.
# Quill-Doctor stays a .ps1 rather than being reimplemented in Python: two
# health checks that could disagree is worse than one that runs in a subprocess.
HOUSE = {
    "doctor":    {"cmd": ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                          "-File", "Quill-Doctor.ps1"],
                  "title": "Pre-game check",
                  "blurb": "the full check — ffmpeg, mic, python, models, disk, ports"},
    "rehearsal": {"cmd": [None, "Quill-Rehearsal.py"],
                  "title": "Rehearse the Chorus",
                  "blurb": "a fake table, end to end, before you ask a real one"},
}

class Runner:
    """One house tool at a time, its output streamed to the page."""
    def __init__(self):
        self.lock = threading.Lock()
        self.running = None
        self.log = []
        self.done = None

    def _log(self, line):
        with self.lock:
            self.log.append(line)
            self.log = self.log[-400:]

    def start(self, name):
        spec = HOUSE.get(name)
        if not spec:
            return {"ok": False, "error": "No such check."}
        with self.lock:
            if self.running:
                return {"ok": False, "error": f"{self.running} is already running."}
            self.running = name
            self.log = []
            self.done = None
        threading.Thread(target=self._work, args=(name, spec), daemon=True).start()
        return {"ok": True}

    def _work(self, name, spec):
        try:
            cmd = [(c if c is not None else sys.executable) for c in spec["cmd"]]
            cmd = [str(HERE / c) if c.endswith((".ps1", ".py")) else c for c in cmd]
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, encoding="utf-8", errors="replace",
                                 bufsize=1, cwd=str(HERE))
            for line in p.stdout:
                # the tools colour their own output for a console; strip it for HTML
                self._log(re.sub(r"\x1b\[[0-9;]*m", "", line.rstrip()))
            p.wait()
            self.done = (p.returncode == 0)
            self._log(f"--- {'all clear' if self.done else 'finished with problems'} ---")
        except Exception as e:
            self.done = False
            self._log(f"could not run it: {e}")
        finally:
            with self.lock:
                self.running = None

    def status(self):
        with self.lock:
            return {"running": self.running, "log": list(self.log), "done": self.done}

runner = Runner()

def cold_open_state():
    """The cold open sheet, and whether it still describes your newest session.

    Staleness is answered with the SAME pick_transcripts() the generator uses,
    so what the drawer calls stale and what a rebuild would actually read can
    never disagree. (A Chorus night therefore counts once, by its merged
    master -- the whole point of the ranking in quill_lib.)"""
    files = pick_transcripts(str(TRANSCRIPTS))
    newest = os.path.basename(max(files, key=os.path.getmtime)) if files else None
    if not COLD_OPEN.exists():
        return {"exists": False, "newest": newest, "stale": bool(newest)}
    text = COLD_OPEN.read_text(encoding="utf-8", errors="replace")
    m = re.search(r"Built from `([^`]+)`", text)
    built = m.group(1) if m else None
    return {
        "exists": True, "text": text, "built_from": built, "newest": newest,
        "stale": bool(newest and built and built != newest),
        "when": datetime.fromtimestamp(COLD_OPEN.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
    }

def report_state(name, with_text=True):
    """One sheet: does it exist, what was it built from, has it gone stale.

    THREE honest answers to "stale", because the sheets answer different
    questions. The cold open and the mirror are about ONE night, so they name it
    and staleness means a newer night exists. The ledger and the concordance
    read every transcript there is, so the only sensible question is whether any
    transcript has changed since they were built. A sheet with no generator is
    never stale -- staleness means "a rebuild would say something different",
    and there is no rebuild. Saying "stale" beside a button that cannot exist
    would be an instruction the DM cannot follow."""
    spec = REPORTS[name]
    base = {"name": name, "title": spec["title"], "blurb": spec["blurb"],
            "buildable": bool(spec["script"])}
    if name == "coldopen":
        s = cold_open_state()
        if not with_text:
            s.pop("text", None)
        return {**base, **s}
    p = HERE / spec["file"]
    files = pick_transcripts(str(TRANSCRIPTS))
    newest = max(files, key=os.path.getmtime) if files else None
    nname = os.path.basename(newest) if newest else None
    if not p.is_file():
        return {**base, "exists": False, "newest": nname,
                "stale": bool(newest) and base["buildable"]}
    text = p.read_text(encoding="utf-8", errors="replace")
    m = re.search(r"^#\s*MIRROR\s*[—\-]\s*(.+)$", text, re.M)
    built = m.group(1).strip() if m else None
    if not base["buildable"]:
        built, stale = None, False
    elif built and nname:
        stale = built != nname                       # session-scoped
    else:
        stale = bool(newest and p.stat().st_mtime < os.path.getmtime(newest))
    out = {**base, "exists": True, "built_from": built, "newest": nname, "stale": stale,
           "when": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")}
    if with_text:
        out["text"] = text
    return out


def build_report(name):
    """Run one sheet's generator. Unlike the Scribe and the Merger these load no
    speech model -- they are text over transcripts that already exist -- so they
    need no turn-taking with them, only a guard against a double-click."""
    spec = REPORTS.get(name)
    if not spec:
        return {"ok": False, "error": "No such report."}
    if not spec["script"]:
        # The page hides the button for these, but the route is a POST anyone on
        # this machine can make, and `HERE / None` is a TypeError -- a 500 where
        # a sentence belongs.
        return {"ok": False,
                "error": f"{spec['title']} writes itself — there is nothing to rebuild."}
    if not report_lock.acquire(blocking=False):
        return {"ok": False, "error": "Already building."}
    try:
        p = subprocess.run([sys.executable, str(HERE / spec["script"]), *spec["args"]],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=str(HERE), timeout=600)
        if p.returncode != 0:
            out = ((p.stdout or "") + (p.stderr or "")).strip()
            return {"ok": False, "error": out.splitlines()[-1] if out else "build failed"}
        return {"ok": True, **report_state(name)}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "The build took too long and was stopped."}
    finally:
        report_lock.release()


def build_cold_open():
    return build_report("coldopen")


def mine_session(name):
    """The per-session digest -- terminal menu [8]. Health of the transcript,
    every mark with the audio just before it, and names the lexicon doesn't know.
    Writes transcripts/<session>_digest.md (a .md, so it can never be mistaken
    for a transcript by the picker)."""
    safe = Path(name).name
    src = TRANSCRIPTS / (safe + ".txt")
    if not src.is_file():
        return {"ok": False, "error": "No such transcript."}
    out = TRANSCRIPTS / (safe + "_digest.md")
    if not report_lock.acquire(blocking=False):
        return {"ok": False, "error": "Already building."}
    try:
        p = subprocess.run([sys.executable, str(HERE / "Mine-Transcript.py"),
                            str(src), "--out", str(out)],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=str(HERE), timeout=600)
        if p.returncode != 0 or not out.is_file():
            msg = ((p.stdout or "") + (p.stderr or "")).strip()
            return {"ok": False, "error": msg.splitlines()[-1] if msg else "mining failed"}
        return {"ok": True, "session": safe,
                "text": out.read_text(encoding="utf-8", errors="replace")}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "That took too long and was stopped."}
    finally:
        report_lock.release()


def notes_setting():
    """What NOTES.txt currently says, and whether those folders are really there.

    'Configured' and 'present' are different answers and the difference is the
    whole point: a typo'd path is not the same as no path, and both leave four
    reports running blind."""
    from quill_lib import NOTES_FILE, notes_roots, notes_found
    raw = []
    if os.path.exists(NOTES_FILE):
        with open(NOTES_FILE, encoding="utf-8", errors="replace") as f:
            raw = [ln.strip() for ln in f
                   if ln.strip() and not ln.strip().startswith("#")]
    roots = notes_roots()
    found = notes_found(roots)
    return {"value": "\n".join(raw), "configured": bool(raw),
            "roots": roots, "found": found,
            "missing": [r for r in roots if r not in found]}


def save_notes(value):
    """Rewrite NOTES.txt's paths, keeping every comment line in it. The comments
    are the only documentation of what the file is for, so a save from the web
    studio must not silently strip them."""
    from quill_lib import NOTES_FILE
    paths, seen = [], set()
    for p in re.split(r"[\r\n,]+", value or ""):
        p = p.strip().strip('"')
        if p and p not in seen:
            seen.add(p)
            paths.append(p)
    comments = []
    if os.path.exists(NOTES_FILE):
        with open(NOTES_FILE, encoding="utf-8", errors="replace") as f:
            comments = [ln.rstrip("\n") for ln in f if ln.strip().startswith("#")]
    if not comments:
        # The header is the only explanation of what this file is for, and it is
        # one careless `> NOTES.txt` away from being gone for good. Rebuild it
        # rather than silently saving a bare path nobody will understand later.
        comments = [
            "# Where your campaign notes live. One folder per line.",
            "#",
            "# The Cold Open, the Mirror, the Concordance and the Lexicon all ask whether",
            "# a name is new at the table or something you already wrote down. Without",
            "# this they run blind, and say so rather than guess.",
            "#",
            "# Set it here, or in the web studio: The House -> \"Campaign notes\".",
        ]
    body = "\n".join(comments + ([""] if comments else []) + paths)
    Path(NOTES_FILE).write_text(body + "\n", encoding="utf-8")
    return {"ok": True, **notes_setting()}


def lexicon_candidates(notes):
    """What Quill-Lexicon would add, as data rather than a printed table, so the
    page can offer them one at a time. The terminal only asks y/N to the whole
    list -- half of which is usually your players' real names."""
    args = [sys.executable, str(HERE / "Quill-Lexicon.py")]
    if notes:
        args += ["--notes", notes]
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", cwd=str(HERE), timeout=300)
    out = (p.stdout or "") + (p.stderr or "")
    names, started = [], False
    for ln in out.splitlines():
        if ln.startswith("name") and "in notes" in ln:
            started = True
            continue
        if not started or not ln.strip() or ln.startswith("("):
            continue
        m = re.match(r"^(.+?)\s{2,}(\d+)\s+(\d+)\s+(.*)$", ln)
        if m:
            names.append({"name": m.group(1).strip(), "notes": int(m.group(2)),
                          "said": int(m.group(3)), "where": m.group(4).strip()})
    head = [l for l in out.splitlines() if l.startswith(("scanned", "lexicon has", "nothing to add"))]
    return {"ok": p.returncode == 0, "candidates": names, "summary": " · ".join(head),
            "error": None if p.returncode == 0 else (out.strip().splitlines() or ["failed"])[-1]}


def lexicon_add(names, notes):
    """Write only the ticked names. The SCRIPT does the writing -- it is the one
    that knows how to preserve your line endings, your own entries, and which
    suggestions you have already thrown away."""
    if not names:
        return {"ok": False, "error": "Nothing selected."}
    args = [sys.executable, str(HERE / "Quill-Lexicon.py"), "--write"]
    if notes:
        args += ["--notes", notes]
    for n in names[:200]:
        args += ["--only", str(n)]
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", cwd=str(HERE), timeout=300)
    if p.returncode != 0:
        msg = ((p.stdout or "") + (p.stderr or "")).strip()
        return {"ok": False, "error": msg.splitlines()[-1] if msg else "write failed"}
    return {"ok": True, "added": len(names)}


def tick_ledger(key, done):
    """Tick a promise off from the page instead of opening the file.

    LEDGER.md is the one sheet the DM is invited to EDIT -- ticked boxes,
    hand-written notes under entries, whole entries deleted on purpose -- and
    re-running the generator preserves all of it. So this rewrites exactly one
    character on exactly one line and leaves every other byte alone. Anything
    cleverer would eventually eat somebody's notes."""
    p = HERE / REPORTS["ledger"]["file"]
    if not p.is_file():
        return {"ok": False, "error": "No ledger yet — build it first."}
    text = p.read_text(encoding="utf-8")
    pat = re.compile(r"^(- \[)[ xX](\] `" + re.escape(key) + r"`)", re.M)
    new, n = pat.subn(r"\g<1>" + ("x" if done else " ") + r"\g<2>", text)
    if not n:
        return {"ok": False, "error": "That entry is no longer in the ledger."}
    p.write_text(new, encoding="utf-8")
    return {"ok": True, "key": key, "done": done, "changed": n}

def chorus_nights():
    """How many Chorus nights sit on disk, and how many still lack a merged
    transcript. This is what lights the merge button."""
    root = RECORDINGS / "chorus"
    if not root.is_dir():
        return {"total": 0, "unmerged": 0}
    total = unmerged = 0
    for d in sorted(root.iterdir()):
        if not (d / "chorus.json").is_file():
            continue
        total += 1
        if not (TRANSCRIPTS / f"{d.name}_chorus.txt").exists():
            unmerged += 1
    return {"total": total, "unmerged": unmerged}

# ---------------------------------------------------------------- server -----

recorder = Recorder()
scribe = Scribe()
merger = Merger()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep the console clean

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _local(self):
        """True only for the DM's own browser.

        The studio binds 0.0.0.0 so phones can reach the MARK button and the Chorus.
        That also meant anyone on the same Wi-Fi could start/stop the recording, pin the
        GPU, and READ ANY TRANSCRIPT. At home that is nothing; at a convention, a game
        store or a shared flat it is somebody reading your campaign. Control and
        read endpoints are now the local machine's alone; phones keep exactly the two
        things they actually need (status and mark) plus the token-gated Chorus."""
        return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def _host_ok(self):
        """Reject DNS rebinding, which defeats the loopback check exactly.

        `_local()` answers "did this come from this machine?" -- it cannot answer
        "did a human at this machine mean it?", and a browser is a confused deputy
        for precisely that. The DM opens any page whose hostname re-resolves to
        127.0.0.1; that page's requests to :8020 then arrive FROM 127.0.0.1 and
        sail through _local(), reading every transcript in the house.

        The fix is one observation: rebinding needs a NAME to re-resolve. An IP
        literal cannot be rebound, and an attacker cannot forge the Host header
        from a browser. So allow localhost and bare IP literals -- which is every
        way a DM or a phone ever actually reaches this studio -- and refuse any
        other hostname."""
        host = (self.headers.get("Host") or "").strip()
        if not host:
            return False                      # HTTP/1.1 requires it; a bot omitted it
        if host.startswith("["):              # [::1]:8020
            name = host[1:host.index("]")] if "]" in host else host
        else:
            name = host.rsplit(":", 1)[0] if host.count(":") == 1 else host
        if name.lower() == "localhost":
            return True
        try:
            ipaddress.ip_address(name)
            return True
        except ValueError:
            return False

    def _same_origin(self):
        """A cross-site page must not drive the studio. Absent Origin is the
        normal case (typing the address, or the phone's own page); present and
        foreign is a browser telling us it is somebody else's errand."""
        o = self.headers.get("Origin")
        if not o:
            return True
        return o.rstrip("/").lower() == f"http://{(self.headers.get('Host') or '').strip()}".lower()

    def _deny(self):
        self._json({"ok": False, "error":
                    "That control is only available on the machine running the studio."}, 403)

    def _refuse_host(self):
        self._json({"ok": False, "error":
                    "Reach the studio at its address (localhost or its IP), not by name."}, 421)

    def _read_body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n == 0:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}

    def do_GET(self):
        if not self._host_ok():
            self._refuse_host(); return
        url = urlparse(self.path)
        if url.path in ("/", "/index.html"):
            if not WEB_PAGE.exists():
                self._json({"error": "web/index.html missing"}, 500)
                return
            body = WEB_PAGE.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif url.path in ("/chorus", "/chorus.html"):
            page = HERE / "web" / "chorus.html"
            if not page.exists():
                self._json({"error": "web/chorus.html missing"}, 500)
                return
            b = page.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
        elif url.path == "/api/chorus/status":
            # Status stays open to the room -- it drives the studio's voice table
            # and costs the phones nothing. But the table code is the write
            # credential for the session; serving it here handed the key to
            # anyone on the wifi. Only the DM's own browser needs it, to print
            # the join link.
            self._json(chorus.status(include_token=self._local()))
        elif url.path == "/api/status":
            # This one endpoint has to stay open to the room -- it is what drives
            # the phone's REC chip and its MARK button. But "open to the room"
            # was quietly shipping the whole session SHELF with it: every label
            # the DM ever typed, which is the campaign name and what happened in
            # it, readable by anyone on the café wifi without a code. The
            # transcript bodies were locked down and their titles were not.
            # A phone needs the recording state, not the archive.
            self._json({
                "recording": recorder.status(),
                "scribe": scribe.status(),
                "merge": merger.status(),
                "hearth": hearth(),
                "chorus_nights": chorus_nights(),
                "sessions": sessions() if self._local() else [],
                "phone": f"http://{lan_ip()}:{PORT}",
            })
        elif url.path == "/api/house":
            if not self._local():
                self._deny(); return
            self._json({"tools": [{"name": k, "title": v["title"], "blurb": v["blurb"]}
                                  for k, v in HOUSE.items()],
                        "run": runner.status(), "notes": notes_setting()})
        elif url.path in ("/api/report", "/api/reports"):
            # Every sheet is built out of verbatim session quotes -- the ledger is
            # literally what your NPCs promised. Gated exactly like /api/transcript.
            if not self._local():
                self._deny(); return
            if url.path == "/api/reports":
                self._json({"reports": [report_state(k, with_text=False)
                                        for k in REPORTS]})
            else:
                nm = (parse_qs(url.query).get("name") or [""])[0]
                self._json(report_state(nm) if nm in REPORTS
                           else {"error": "no such report"})
        elif url.path == "/api/coldopen":
            # Every line of the cold open is a verbatim quote from the session --
            # it is the transcript's best parts, concentrated. Gated exactly like
            # /api/transcript, for exactly the same reason.
            if not self._local():
                self._deny(); return
            self._json(cold_open_state())
        elif url.path == "/api/transcript":
            if not self._local():
                self._deny(); return
            name = (parse_qs(url.query).get("name") or [""])[0]
            # basename only - no path tricks
            safe = Path(name).name
            f = TRANSCRIPTS / (safe + ".txt")
            if f.exists():
                self._json({"ok": True, "text": f.read_text(encoding="utf-8")})
            else:
                self._json({"ok": False, "error": "No transcript yet."}, 404)
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        if not self._host_ok() or not self._same_origin():
            self._refuse_host(); return
        url = urlparse(self.path)

        # --- the Chorus ---------------------------------------------------
        # Audio chunks are RAW BINARY and must be read before any JSON parsing
        # is attempted, or the body is consumed and the upload is lost.
        if url.path == "/api/chorus/chunk":
            q = parse_qs(url.query)
            # Read the body BEFORE deciding, even when the answer is no. Replying 403
            # while the client is still sending several hundred KB closes the socket
            # mid-upload, and the phone reports a connection error instead of the real
            # reason -- so a wrong table code looked like "can't reach the laptop".
            n = int(self.headers.get("Content-Length") or 0)
            blob = self.rfile.read(n) if n else b""
            if not chorus.check((q.get("t") or [""])[0]):
                self._json({"ok": False, "error":
                            "Bad or missing table code - use the link the DM gave you."}, 403)
                return
            tid = (q.get("track") or [""])[0]
            self._json(chorus.chunk(tid, blob))
            return

        if url.path.startswith("/api/chorus/"):
            body = self._read_body()
            act = url.path.rsplit("/", 1)[-1]
            # Opening, closing and merging are the DM's call, from the DM's machine.
            if act in ("open", "close", "merge") and not self._local():
                self._deny(); return
            # Everything a phone does needs the token that was in its join link.
            if act in ("join", "start", "leave") and not chorus.check(body.get("t", "")):
                self._json({"ok": False, "error":
                            "Bad or missing table code - use the link the DM gave you."}, 403)
                return
            if act == "open":
                # If the studio's own recorder is RUNNING, adopt its start time
                # AND its file so every phone lands on the DM's timeline. Both
                # reads are active()-guarded; a finished recording must never
                # ride into a new session.
                st = recorder.started_epoch()
                mf = recorder.master_path()
                self._json(chorus.open(str(body.get("label", "")), st,
                                       str(mf) if mf else None))
            elif act == "close":
                self._json(chorus.close())
            elif act == "merge":
                if chorus.status().get("open"):
                    self._json({"ok": False, "error":
                                "Close the Chorus first - phones may still be uploading."})
                else:
                    m = str(body.get("model", "medium.en"))
                    if m not in ("tiny.en", "base.en", "small.en", "medium.en"):
                        m = "medium.en"
                    self._json(merger.start(m))
            elif act == "join":
                self._json(chorus.join(str(body.get("speaker", "")),
                                       str(body.get("mime", ""))))
            elif act == "start":
                self._json(chorus.start(str(body.get("track", ""))))
            elif act == "leave":
                self._json(chorus.leave(str(body.get("track", ""))))
            else:
                self._json({"error": "not found"}, 404)
            return

        body = self._read_body()
        if self.path in ("/api/record/start", "/api/record/stop", "/api/transcribe",
                         "/api/coldopen/build", "/api/report/build", "/api/report/tick",
                         "/api/house/run", "/api/mine", "/api/lexicon",
                         "/api/lexicon/add", "/api/notes") and not self._local():
            self._deny(); return
        if self.path == "/api/notes":
            self._json(save_notes(str(body.get("value", "")))); return
        if self.path == "/api/house/run":
            self._json(runner.start(str(body.get("name", "")))); return
        if self.path == "/api/mine":
            self._json(mine_session(str(body.get("name", "")))); return
        if self.path == "/api/lexicon":
            self._json(lexicon_candidates(str(body.get("notes", "")).strip())); return
        if self.path == "/api/lexicon/add":
            names = body.get("names") or []
            self._json(lexicon_add([str(n) for n in names if str(n).strip()],
                                   str(body.get("notes", "")).strip())); return
        if self.path == "/api/coldopen/build":
            self._json(build_cold_open()); return
        if self.path == "/api/report/build":
            self._json(build_report(str(body.get("name", "")))); return
        if self.path == "/api/report/tick":
            self._json(tick_ledger(str(body.get("key", "")),
                                   bool(body.get("done")))); return
        if self.path == "/api/record/start":
            self._json(recorder.start(str(body.get("label", ""))))
        elif self.path == "/api/record/unmark":
            # Deliberately NOT studio-only: the mistap this undoes happens on
            # the phone, by the same hand that made the mark a second earlier.
            self._json(recorder.unmark())
        elif self.path == "/api/record/mark":
            self._json(recorder.mark(str(body.get("note", ""))))
        elif self.path == "/api/record/stop":
            self._json(recorder.stop())
        elif self.path == "/api/transcribe":
            model = str(body.get("model", "small.en"))
            if model not in ("tiny.en", "base.en", "small.en", "medium.en"):
                model = "small.en"
            self._json(scribe.start(model))
        else:
            self._json({"error": "not found"}, 404)

def main():
    banner = r"""
   ==================================================================
     G N A S H E R ' S   Q U I L L          . web studio .
     record . transcribe . remember
     the Quill records -> the Grimoire holds -> the Satchel carries
   ==================================================================
"""
    print(banner)
    h = hearth()                      # sniffs once; the page reads the same answer
    ff, mic = BOOT["ffmpeg"], BOOT["mic"]
    print(f"   ffmpeg : {'ok' if ff else 'NOT FOUND - recording disabled'}")
    print(f"   mic    : {mic or 'none detected'}")
    print(f"   studio : http://127.0.0.1:{PORT}")
    print(f"   phone  : http://{lan_ip()}:{PORT}   (same Wi-Fi = remote MARK button)")
    print("\n   Leave this window open. Ctrl+C (or close it) to stop the studio.\n")
    try:
        server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    except OSError:
        print("   The studio is already running (port 8020 is busy).")
        print("   Opening the page in your browser instead...")
        __import__("webbrowser").open(f"http://127.0.0.1:{PORT}")
        time.sleep(4)
        return
    threading.Timer(0.8, lambda: __import__("webbrowser").open(
        f"http://127.0.0.1:{PORT}")).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n   The Quill sleeps. The Grimoire remembers.")

if __name__ == "__main__":
    main()
