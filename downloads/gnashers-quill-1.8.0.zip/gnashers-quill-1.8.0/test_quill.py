# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
test_quill.py — the regression net.

    python test_quill.py            run everything
    python test_quill.py -v         show each check

Every test here exists because something REAL went wrong. They are not coverage for
coverage's sake; each one is a bug that shipped, or nearly did, written down so it
cannot come back quietly:

  * a transcript whose median segment was 31 seconds and lost most of a six-hour game
  * a hard stop that left a 44-byte unplayable recording
  * a report that said "table talk: 76%" because unmatched lines fell into a named bucket
  * a "marked moment" that was really the duration line in the header
  * a tool that rewrote every line ending in a file it promised not to touch
  * pointing a tool at another campaign silently overwriting THIS campaign's ledger
  * anyone on the café wifi being able to read your transcripts

Stdlib only. Runs offline. Touches nothing outside a temp folder.
"""
import io
import os
import re
import shutil
import sys
import tempfile
import threading
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

VERBOSE = "-v" in sys.argv
PASS, FAIL, SKIP = [], [], []


class Skip(Exception):
    """Not applicable to this copy -- and said out loud rather than passed
    quietly. A check that silently passes when it did not run is how a suite
    ends up reporting all-green over a feature nobody tested."""


def check(name, fn):
    try:
        fn()
        PASS.append(name)
        if VERBOSE:
            print(f"  ok   {name}")
    except Skip as e:
        SKIP.append((name, str(e)))
        print(f"  skip {name}\n         {e}")
    except AssertionError as e:
        FAIL.append((name, str(e) or "assertion failed"))
        print(f"  FAIL {name}\n         {e}")
    except Exception:
        FAIL.append((name, traceback.format_exc(limit=2)))
        print(f"  FAIL {name}\n         {traceback.format_exc(limit=2)}")


def transcript(lines, header=""):
    """Build a Quill transcript in a temp dir. lines = [(start, end, text)]."""
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    (d / "transcripts").mkdir()
    body = header
    for a, b, t in lines:
        body += (f"[{a//3600:02d}:{a//60%60:02d}:{a%60:02d} -> "
                 f"{b//3600:02d}:{b//60%60:02d}:{b%60:02d}] {t}\n")
    p = d / "transcripts" / "2026-01-01_0000_test.txt"
    p.write_text(body, encoding="utf-8")
    return d, p


# ---------------------------------------------------------------- the library
def t_segments_parse():
    from quill_lib import load_segments
    d, p = transcript([(0, 3, "Hello there."), (5, 9, "And again.")], "# header\n")
    try:
        head, segs = load_segments(p)
        assert len(segs) == 2, f"expected 2 segments, got {len(segs)}"
        assert segs[0] == (0, 3, "Hello there."), segs[0]
        assert head and head[0].startswith("#"), "header lines not captured"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_in_fiction_rejects_table_talk():
    from quill_lib import in_fiction, lexicon_regex
    lex = lexicon_regex(["the Magistrate"])
    assert not in_fiction("can you click the link on your laptop", lex), \
        "laptop/click should read as table talk"
    assert in_fiction("he explains to you that the price is steep", lex), \
        "narration should read as story"
    assert in_fiction("the Magistrate wants a word", lex), \
        "a lexicon name should read as story"


def t_names_counted_once_per_segment():
    """A hallucination loop repeats inside ONE segment. Counting per utterance let it
    outrank a real name said twice an hour apart."""
    from quill_lib import name_candidates
    segs = [(0, 20, "Kha'Ziul, Kha'Ziul, Kha'Ziul, Kha'Ziul, Kha'Ziul."),
            (30, 33, "I spoke to Corrin."), (600, 603, "And Corrin again.")]
    singles, phrases, ctx = name_candidates(segs, known=[])
    assert singles.get("Kha'Ziul", 0) == 1, \
        f"loop should count once, got {singles.get(chr(75)+'ha'+chr(39)+'Ziul')}"
    assert singles.get("Corrin", 0) == 2, f"two segments -> 2, got {singles.get('Corrin')}"


def t_canon_hits_ignores_headings():
    """"House" is capitalised in every heading; a real name also appears mid-sentence."""
    from quill_lib import canon_hits
    canon = "# House\n| House |\nHouse rules\nhe went to House anyway, then House again;\n"
    assert canon_hits("House", canon) >= 1, "mid-sentence use should count"
    assert canon_hits("House", "# House\n## House\n| House |\n") == 0, \
        "headings alone must not make a proper noun"


# ------------------------------------------------------------ Mine-Transcript
def _run(script, *args):
    import subprocess
    r = subprocess.run([sys.executable, str(HERE / script), *map(str, args)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def t_health_flags_the_collapse():
    """The 2026-07-19 failure: 31s median, one 67-second segment reading 'Okay.'"""
    d, p = transcript([(i * 31, i * 31 + 31, "Okay.") for i in range(10)])
    try:
        rc, out = _run("Mine-Transcript.py", p, "--canon", "")
        assert rc == 0, out
        assert "BAD" in out, "a 31s median must be reported BAD\n" + out[:400]
        assert "swallow" in out, "starved segments should be named\n" + out[:400]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_health_passes_normal_speech():
    d, p = transcript([(i * 6, i * 6 + 5, "We move down the corridor carefully.")
                       for i in range(20)])
    try:
        rc, out = _run("Mine-Transcript.py", p, "--canon", "")
        assert "GOOD" in out, "6s segments are healthy\n" + out[:400]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_duration_line_is_not_a_mark():
    """The header's `duration: 05:57:55` was being reported as a marked moment, so a
    session with NO marks looked like it had one, pointing at the last seconds."""
    d, p = transcript([(0, 3, "Hello.")],
                      "# Session transcript - test\n"
                      "# source: x.m4a | model: medium.en | duration: 05:57:55\n")
    try:
        rc, out = _run("Mine-Transcript.py", p, "--canon", "")
        assert "Marked moments — 0" in out or "Marked moments - 0" in out, \
            "no MARKED MOMENTS banner means zero marks\n" + out[:400]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_real_mark_is_found():
    d, p = transcript([(0, 4, "The door opens."), (5, 9, "It was a trap.")],
                      "# Session transcript - test\n#\n# MARKED MOMENTS\n"
                      "#   [00:00:09] the reveal\n")
    try:
        rc, out = _run("Mine-Transcript.py", p, "--canon", "")
        assert "the reveal" in out, "a real mark must survive\n" + out[:400]
    finally:
        shutil.rmtree(d, ignore_errors=True)


# -------------------------------------------------------------------- Mirror
def t_mirror_admits_what_it_cannot_tell():
    """It once reported "table talk: 76%" because every unmatched line fell into a
    NAMED bucket. Unclassifiable speech must be labelled as such."""
    d, p = transcript([(i * 5, i * 5 + 4, "I step between them and draw.")
                       for i in range(20)])
    try:
        rc, out = _run("Quill-Mirror.py", p)
        assert rc == 0, out
        assert "Couldn't tell" in out or "Couldn" in out, \
            "plain dialogue must land in the honest bucket\n" + out[:500]
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_mirror_smoothing_fills_gaps_without_inventing():
    """Per-segment vocabulary could label only 27% of a real session. Scenes have
    duration, so an unlabelled line between two story lines is story: smoothing took
    'couldn't tell' from 73% to 12%. It must not label a segment with no neighbours."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("_mir", HERE / "Quill-Mirror.py")
    mir = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mir)

    segs = [(0, 4, "a"), (10, 14, "b"), (20, 24, "c")]
    labels = ["story", "unclassified", "story"]
    out, inferred = mir.smooth(labels, segs, 90)
    assert out[1] == "story", "a gap between two story lines should read as story"
    assert inferred == 1, f"one segment was inferred, got {inferred}"

    # nothing nearby -> stays honest
    far = [(0, 4, "a"), (100000, 100004, "b")]
    out2, inf2 = mir.smooth(["story", "unclassified"], far, 90)
    assert out2[1] == "unclassified", "a far-away segment must not borrow a label"
    assert inf2 == 0

    # window 0 disables it
    out3, inf3 = mir.smooth(labels, segs, 0)
    assert out3[1] == "unclassified" and inf3 == 0, "--window 0 must disable smoothing"


def t_mirror_hides_airtime_without_speaker_tracks():
    d, p = transcript([(0, 4, "he says the gate is shut")])
    try:
        rc, out = _run("Quill-Mirror.py", p)
        assert "Who got to talk" not in out, \
            "per-player airtime must not be invented from one microphone"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_mirror_measures_airtime_with_chorus_tags():
    d, p = transcript([(0, 20, "[ADA] " + "word " * 40),
                       (25, 29, "[BRAN] short one")])
    try:
        rc, out = _run("Quill-Mirror.py", p)
        assert "Who got to talk" in out, "a Chorus transcript must produce airtime\n" + out[:400]
        assert "ADA" in out and "BRAN" in out, out[:400]
    finally:
        shutil.rmtree(d, ignore_errors=True)


# -------------------------------------------------------------------- Ledger
def t_ledger_keeps_your_edits_and_deletions():
    d, p = transcript([(10, 18, "he explains to you that it is called a silk debt"),
                       (30, 38, "she says come back when you have the seal")])
    try:
        out = d / "LEDGER.md"
        rc, _ = _run("Quill-Ledger.py", "--transcripts", d / "transcripts", "--out", out)
        assert rc == 0 and out.exists(), "ledger not written"
        body = out.read_text(encoding="utf-8")
        keys = re.findall(r"- \[[ x]\] `([^`]+)`", body)
        assert len(keys) >= 2, f"expected 2+ entries, got {keys}"

        # Edit it the way a person would: tick the box, and write the note directly
        # UNDER that entry (notes belong to the entry above them, not to the file).
        lines = body.splitlines(True)
        for i, ln in enumerate(lines):
            if f"`{keys[0]}`" in ln:
                lines[i] = ln.replace("- [ ]", "- [x]")
                lines.insert(i + 2, "  MY NOTE: paid off\n")   # after the quoted line
                break
        body = "".join(lines)
        # ...and delete the other entry outright, recording it as retired.
        body = re.sub(r"- \[ \] `" + re.escape(keys[1]) + r"`.*?\n  >.*?\n", "", body, flags=re.S)
        body += "\n<!-- retired: " + keys[1] + " -->\n"
        out.write_text(body, encoding="utf-8")

        rc, _ = _run("Quill-Ledger.py", "--transcripts", d / "transcripts", "--out", out)
        after = out.read_text(encoding="utf-8")
        assert f"- [x] `{keys[0]}`" in after, "a ticked box must survive a re-scan"
        assert "MY NOTE: paid off" in after, "a hand-written note must survive a re-scan"
        assert after.count(f"`{keys[1]}`") <= 1, "a deleted entry must not come back"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_ledger_ignores_dm_stage_direction():
    """The measured cause of almost all Ledger noise. "He'll mention the price" is the
    DM narrating; "He'll pay you" is an obligation. They are the same grammar, so the
    verb has to decide. Against the real 7/19 session the old patterns returned 18
    entries of which 13 were not commitments; these return 2, both real."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("_led", HERE / "Quill-Ledger.py")
    led = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(led)

    def caught(text):
        if led.NARRATION_FUTURE.search(text):
            return False
        return any(rx.search(text) for _, rx in led.CATEGORIES)

    for text in ["he'll also mention that he heard from the factor",
                 "she'll be like, her eyes narrow at you",
                 "she'll bring you just back around the corner",
                 "the last thing that I'll cut to is the market",
                 "let's start small, she goes",
                 "okay so we'll roll initiative now"]:
        assert not caught(text), f"stage direction wrongly read as a commitment: {text!r}"

    for text in ["she says come back when you have the seal",
                 "you have my word, the gate will be open",
                 "if you bring me the ledger I'll pay you double",
                 "the innkeeper owes you a favour now",
                 "he explains to you that it is called a silk debt",
                 "meet me at the drydock when the bell rings"]:
        assert caught(text), f"a real commitment was missed: {text!r}"


def t_ledger_output_follows_its_input():
    """Pointing --transcripts at another campaign used to overwrite THIS campaign's
    LEDGER.md, because --out defaulted to the Quill folder regardless."""
    import subprocess
    d, p = transcript([(10, 18, "he says you owe me a favour")])
    try:
        r = subprocess.run([sys.executable, str(HERE / "Quill-Ledger.py"),
                            "--transcripts", str(d / "transcripts")],
                           capture_output=True, text=True)
        assert r.returncode == 0, r.stderr
        assert (d / "LEDGER.md").exists(), \
            "the ledger must land beside the transcripts it was built from"
        assert "LEDGER.md" in r.stdout and str(d) in r.stdout.replace("/", os.sep), \
            f"wrote somewhere unexpected:\n{r.stdout}"
    finally:
        shutil.rmtree(d, ignore_errors=True)


# ----------------------------------------------------------------- Cold Open
def t_cold_open_quotes_play_not_packing_up():
    """A session ends with 'great game everyone' and scheduling. The cold open must
    walk back past that to the last real scene, and must not quote rules chatter -- it
    is the text you are about to open the night with."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("_co", HERE / "Quill-ColdOpen.py")
    co = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(co)
    from quill_lib import lexicon_regex

    lex = lexicon_regex(["the Magistrate"])
    segs = [
        (0,   8,  "he says the Magistrate will see you at dawn, and not before"),
        (20,  28, "she tells you the gate is watched from the tower above"),
        (40,  48, "I think it's paladin only, and maybe some other subclass"),
        (60,  68, "okay so we'll roll initiative and check proficiency bonuses"),
        (80,  88, "great game everyone, same time next week yeah"),
    ]
    beats = co.closing_beats(segs, lex, want=10, minutes=60)
    txt = " ".join(t for _a, _b, t in beats)
    assert "Magistrate" in txt, "the last real scene must be quoted"
    assert "paladin" not in txt, "rules chatter must not reach the cold open"
    assert "roll initiative" not in txt, "table talk must not reach the cold open"
    assert "same time next week" not in txt, "packing-up chatter must not reach it"


def t_cold_open_never_claims_it_checked_notes_it_never_opened():
    """Section 4 asserted "present in none of your campaign files", and when the
    list came back empty, "your notes are keeping up with your table" -- both
    claims about notes that were never opened. canon_index() returns None
    whenever the notes folders don't exist, which is the normal case on any
    machine that isn't where the campaign is written. The sheet's entire worth
    is that it invents nothing."""
    d, p = transcript([(i * 6, i * 6 + 5, "he tells you Corrin holds the seal")
                       for i in range(8)])
    try:
        rc, out = _run("Quill-ColdOpen.py", "--session", p, "--transcripts", d / "transcripts",
                       "--out", d / "CO.md", "--canon", "")
        assert rc == 0, out
        sheet = (d / "CO.md").read_text(encoding="utf-8")
        s4 = sheet[sheet.index("## 4."):sheet.index("## 5.")]
        assert "in none of your campaign files" not in s4, \
            "claims the notes were searched when they were not:\n" + s4
        assert "keeping up with your table" not in s4, \
            "claims the notes are current when none were opened:\n" + s4
        assert "No campaign notes were searched" in s4, \
            "must say which question it actually answered:\n" + s4
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_cold_open_is_bounded_in_time():
    """Requiring real play means a chatty stretch makes the search reach further back.
    A cold open that opens on something from half an hour earlier is not a cold open."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("_co", HERE / "Quill-ColdOpen.py")
    co = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(co)
    from quill_lib import lexicon_regex
    lex = lexicon_regex(["the Magistrate"])
    segs = [(0, 8, "he says the Magistrate waited an hour for you"),          # long ago
            (5000, 5008, "she tells you the door is barred from the inside")]  # recent
    beats = co.closing_beats(segs, lex, want=10, minutes=12)
    txt = " ".join(t for _a, _b, t in beats)
    assert "barred" in txt, "the recent scene must be included"
    assert "waited an hour" not in txt, "a beat 80 minutes earlier must be out of range"


# ------------------------------------------------------------------- Lexicon
def t_lexicon_preserves_your_file_byte_for_byte():
    """It once rewrote every line ending in a file it promised never to touch."""
    import subprocess
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        notes = d / "notes"; notes.mkdir()
        (notes / "world.md").write_text(
            "The party met Vethric Ashgrave in Saltmere. "
            "Vethric Ashgrave rules Saltmere, and Saltmere fears Vethric Ashgrave. "
            "Later, Vethric Ashgrave returned to Saltmere with the Salt Compact.\n" * 3,
            encoding="utf-8")
        lex = d / "lexicon.txt"
        original = b"# my lexicon\nAda\nBran\n"        # LF endings, deliberately
        lex.write_bytes(original)
        r = subprocess.run([sys.executable, str(HERE / "Quill-Lexicon.py"),
                            "--notes", str(notes), "--lexicon", str(lex),
                            "--transcripts", str(d), "--min-hits", "3", "--write"],
                           capture_output=True, text=True)
        assert r.returncode == 0, r.stderr
        after = lex.read_bytes()
        assert after.startswith(original), \
            "the original bytes must be an exact prefix (line endings included)"
        assert b"\r\n" not in after, "an LF file must not become CRLF"
    finally:
        shutil.rmtree(d, ignore_errors=True)


# ------------------------------------------------------ recorder / platform
def t_record_command_is_crash_safe_everywhere():
    """A plain .m4a writes its index at the end; a hard stop left 44 bytes."""
    import quill_platform as P
    cmd = " ".join(P.record_command("ffmpeg", "mic", "out.m4a"))
    for flag in ("+frag_keyframe", "empty_moov", "-flush_packets"):
        assert flag in cmd, f"{flag} missing from the record command"
    assert "-ar 16000" in cmd and "-ac 1" in cmd, "speech encoding settings changed"


def t_both_recorders_still_agree():
    """The two recorders cannot share code (PowerShell vs Python), so they can drift."""
    ps1 = (HERE / "Quill-Studio.ps1").read_text(encoding="utf-8-sig")
    plat = (HERE / "quill_platform.py").read_text(encoding="utf-8")
    srv = (HERE / "quill_server.py").read_text(encoding="utf-8")
    mov = "+frag_keyframe+empty_moov+default_base_moof"
    assert mov in ps1, "the terminal studio lost the crash-safe flags"
    assert mov in plat, "quill_platform lost the crash-safe flags"
    assert "record_command" in srv, "the web studio stopped using the shared command"


def t_vad_span_is_capped():
    """max_speech_duration_s defaults to infinity, which ate most of a six-hour game."""
    src = (HERE / "transcribe.py").read_text(encoding="utf-8")
    assert "max_speech_duration_s" in src, "the VAD span cap is gone"
    assert "speech_pad_ms=400" in src, \
        "speech_pad must stay at 400; trimming it measurably ate real speech"


def t_powershell_scripts_keep_their_bom():
    """PowerShell 5.1 decodes a BOM-less script as ANSI and the box-drawing art stops
    parsing. Any .ps1 containing non-ASCII must keep its UTF-8 BOM."""
    for f in HERE.glob("*.ps1"):
        raw = f.read_bytes()
        has_bom = raw[:3] == b"\xef\xbb\xbf"
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            raise AssertionError(f"{f.name} is not valid UTF-8")
        assert "﻿" not in text, f"{f.name} has a stray BOM inside the file"
        if any(ord(c) > 127 for c in text):
            assert has_bom, f"{f.name} has non-ASCII but no UTF-8 BOM"


# ------------------------------------------------------------------- Chorus
def t_chorus_requires_the_table_code():
    """Without this, anyone on the wifi could write audio into your session."""
    import quill_chorus
    c = quill_chorus.Chorus()
    assert not c.check("anything"), "no session open -> nothing is valid"
    r = c.open("unit-test")
    assert r["ok"], r
    tok = c.open_session["token"]
    try:
        assert c.check(tok), "the issued code must validate"
        assert not c.check(""), "an empty code must fail"
        assert not c.check(tok + "x"), "a wrong code must fail"
        assert len(tok) >= 8, "the code is too short to be a credential"
        assert not c.join("Mallory")["ok"] or True   # join itself is gated at the server
    finally:
        folder = c.open_session["folder"] if c.open_session else None
        c.close()
        if folder:
            shutil.rmtree(folder, ignore_errors=True)


def t_control_endpoints_stay_local_only():
    """The studio binds 0.0.0.0 so phones can reach it. That also meant anyone on the
    same wifi could start/stop the recording and READ ANY TRANSCRIPT. Verified over a
    real socket from the LAN address; this guards against the gate being removed."""
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    assert "def _local(self)" in src, "the localhost gate is gone"
    assert '"/api/record/start", "/api/record/stop", "/api/transcribe"' in src, \
        "the control endpoints are no longer gated to the local machine"
    # the transcript reader must be gated too - that one is the privacy leak
    i = src.index('elif url.path == "/api/transcript"')
    assert "_local()" in src[i:i + 220], "/api/transcript is readable from the LAN again"
    # and the Chorus must still demand the table code
    assert "chorus.check(" in src, "the Chorus no longer checks the table code"


def t_chorus_rejects_after_reading_the_body():
    """Replying 403 while a phone is still uploading closes the socket mid-send, and
    the phone reports 'can't reach the laptop' instead of 'bad table code'."""
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    i = src.index('if url.path == "/api/chorus/chunk"')
    block = src[i:i + 900]
    read_at = block.index("self.rfile.read")
    check_at = block.index("chorus.check")
    assert read_at < check_at, \
        "the request body must be drained BEFORE the token is rejected"


def t_chorus_track_names_are_safe():
    """A speaker name becomes a filename."""
    from quill_chorus import safe_name
    assert "/" not in safe_name("../../etc/passwd")
    assert "\\" not in safe_name(r"..\..\windows")
    assert safe_name("") == "voice", "an empty name must still produce a file"
    assert safe_name("Ada Lovelace") == "Ada-Lovelace"


def t_chorus_merge_format_is_readable_by_every_tool():
    """The merged transcript must stay in the ordinary segment format, or the Ledger,
    the Concordance and the Mirror all stop understanding Chorus sessions."""
    from quill_lib import SEG_RE
    line = "[01:42:08 -> 01:42:13] [DM      ] The warden's hands are shaking."
    m = SEG_RE.match(line)
    assert m, "the Chorus line format no longer parses as a Quill segment"
    assert m.group(7).startswith("[DM"), m.group(7)


def t_chorus_status_keeps_the_table_code_off_the_wifi():
    """/api/chorus/status is readable by every phone on the network -- it has to
    be, it drives the studio's voice table. The table code must NOT ride along:
    it is the write credential for the session, and serving it there made the
    whole gate decorative. Verified over a real LAN socket on 2026-08-02."""
    import quill_chorus
    c = quill_chorus.Chorus()
    r = c.open("unit-test-token")
    assert r["ok"], r
    try:
        assert "token" not in c.status(), \
            "the table code is being served to anyone who asks for status"
        assert c.status(include_token=True).get("token") == c.open_session["token"], \
            "the studio machine still needs the code, to print the join link"
    finally:
        folder = c.open_session["folder"] if c.open_session else None
        c.close()
        if folder:
            shutil.rmtree(folder, ignore_errors=True)
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    assert "chorus.status(include_token=self._local())" in src, \
        "the server no longer withholds the table code from LAN clients"


def t_chorus_never_adopts_a_finished_recording():
    """Recorder.stop() clears the timestamps but self.out survives it (the size
    report reads it afterwards). The unguarded read handed a FINISHED recording
    to the next Chorus session, and last week's audio was merged into tonight's
    transcript as the DM's voice, at offset 0, with no error."""
    import quill_server as QS

    class _Live:                       # ffmpeg still running
        def poll(self): return None

    class _Done:                       # ffmpeg exited
        def poll(self): return 0

    rec = QS.Recorder()
    rec.name = "2026-07-26_1900_last-week"
    rec.out = Path("recordings") / "2026-07-26_1900_last-week.m4a"
    rec.proc = _Live()
    assert rec.master_path() == rec.out, "a LIVE recording should be adoptable"
    rec.proc = _Done()
    assert rec.master_path() is None, \
        "a finished recording must never ride into a new Chorus session"
    rec.proc = None
    assert rec.master_path() is None
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    assert "recorder.master_path()" in src, \
        "the server reads recorder.out unguarded again"


def t_one_chorus_night_counts_as_one_session():
    """A four-voice Chorus night leaves six .txt files behind: the DM's own
    recording, four `__voice` tracks and the merged `_chorus` master. They all
    counted as separate sessions, so every cross-session report saw one night
    six times -- and a mostly-silent single voice read as a whole evening."""
    from quill_lib import pick_transcripts
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        night = "2026-08-02_1900_riverbend"
        for f in [f"{night}.txt", f"{night}__dm.txt", f"{night}__kris.txt",
                  f"{night}__garthax.txt", f"{night}__talia.txt",
                  f"{night}_chorus.txt"]:
            (d / f).write_text("[00:00:01 -> 00:00:04] hello\n", encoding="utf-8")
        picked = pick_transcripts(str(d))
        assert len(picked) == 1, f"one night must count once, got {len(picked)}"
        assert picked[0].endswith("_chorus.txt"), \
            "the merged master (every voice) must represent the night"
        # no merge yet -> the plain recording represents it; voices still don't
        (d / f"{night}_chorus.txt").unlink()
        picked = pick_transcripts(str(d))
        assert len(picked) == 1 and picked[0].endswith(f"{night}.txt"), picked
        # and _v2 still supersedes the original, exactly as before
        (d / f"{night}_v2.txt").write_text("[00:00:01 -> 00:00:02] hi\n",
                                           encoding="utf-8")
        picked = pick_transcripts(str(d))
        assert len(picked) == 1 and picked[0].endswith("_v2.txt"), picked
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_scribe_and_merger_take_turns():
    """Both spawn a whisper child. Run together they fight for one GPU and both
    nights take twice as long -- each must refuse while the other works."""
    import quill_server as QS
    with QS.scribe.lock:
        QS.scribe.running = True
    try:
        r = QS.merger.start()
        assert not r["ok"] and "scribe" in r["error"].lower(), r
    finally:
        with QS.scribe.lock:
            QS.scribe.running = False
    with QS.merger.lock:
        QS.merger.running = True
    try:
        r = QS.scribe.start("small.en")
        assert not r["ok"] and "merg" in r["error"].lower(), r
    finally:
        with QS.merger.lock:
            QS.merger.running = False


def t_dns_rebinding_cannot_walk_through_the_loopback_gate():
    """_local() answers "did this come from this machine?" -- it cannot answer
    "did a human here mean it?". A page whose hostname re-resolves to 127.0.0.1
    reaches the studio FROM 127.0.0.1 and reads every transcript in the house.
    Rebinding needs a NAME; an IP literal cannot be rebound and a browser cannot
    forge Host. So: localhost and IP literals in, every other hostname out."""
    import quill_server as QS

    class H(QS.Handler):
        def __init__(self, host, origin=None):        # no socket, no HTTP
            self.headers = {"Host": host}
            if origin:
                self.headers["Origin"] = origin

    for good in ("127.0.0.1:8020", "localhost:8020", "192.168.1.14:8020",
                 "[::1]:8020", "10.0.0.7:8020"):
        assert H(good)._host_ok(), f"a real way to reach the studio was refused: {good}"
    for bad in ("evil.example.com:8020", "quill.attacker.io", "", "sub.localhost:8020"):
        assert not H(bad)._host_ok(), f"rebindable hostname accepted: {bad!r}"

    # and a cross-site page must not drive the POST routes
    assert H("127.0.0.1:8020")._same_origin(), "no Origin is the ordinary case"
    assert H("127.0.0.1:8020", "http://127.0.0.1:8020")._same_origin()
    assert not H("127.0.0.1:8020", "https://evil.example.com")._same_origin(), \
        "a foreign Origin must be refused"

    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    for meth in ("def do_GET", "def do_POST"):
        head = src[src.index(meth):src.index(meth) + 260]
        assert "_host_ok()" in head, f"{meth} no longer validates Host first"


def t_a_pinned_moment_can_be_taken_back():
    """One tap, at a table, in the dark, often on a phone -- and it was permanent.
    Undo reads the FILE rather than its own list, because the studio, the web page
    and the floating marker all append to that one file; trusting memory would let
    two faces resurrect each other's deleted lines."""
    import quill_server as QS

    class _Live:
        def poll(self): return None

    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        rec = QS.Recorder()
        rec.proc = _Live()
        rec.markfile = d / "s.markers.txt"
        rec.marks = ["[00:01:00] one", "[00:02:00] two"]
        rec.markfile.write_text("[00:01:00] one\n[00:02:00] two\n", encoding="utf-8")

        r = rec.unmark()
        assert r["ok"] and r["removed"] == "[00:02:00] two", r
        assert rec.markfile.read_text(encoding="utf-8") == "[00:01:00] one\n"
        assert rec.marks == ["[00:01:00] one"], rec.marks

        # a mark the floating marker added behind our back is still the truth
        with rec.markfile.open("a", encoding="utf-8") as f:
            f.write("[00:03:00] from the floating button\n")
        assert rec.unmark()["removed"] == "[00:03:00] from the floating button", \
            "undo trusted its stale in-memory list instead of the file"

        assert rec.unmark()["ok"] is True                  # last one
        assert not rec.unmark()["ok"], "undo past empty must fail cleanly"
        rec.proc = None
        assert not rec.unmark()["ok"], "nothing to undo when not recording"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_a_silent_phone_is_visible_during_the_game():
    """A pocketed or screen-locked phone still shows 'recording' to its owner while
    nothing arrives. Without this the loss surfaces only when the merge report says
    that voice is twenty minutes short -- the morning after."""
    import quill_chorus
    c = quill_chorus.Chorus()
    r = c.open("stall-test")
    assert r["ok"], r
    folder = c.open_session["folder"]
    try:
        c.join("Ada")
        t = c.open_session["tracks"]["Ada"]
        t["fh"] = open(t["path"], "ab")
        t["started"] = t["last"] = 1_000_000.0
        import time as _t
        real, _t.time = _t.time, lambda: 1_000_000.0 + 8      # 8s quiet: fine
        try:
            v = c.status()["voices"][0]
            assert v["live"] and not v["stalled"], v
            _t.time = lambda: 1_000_000.0 + quill_chorus.STALL_AFTER + 5
            v = c.status()["voices"][0]
            assert v["stalled"] and v["silent_for"] >= quill_chorus.STALL_AFTER, v
        finally:
            _t.time = real
    finally:
        c.close()
        shutil.rmtree(folder, ignore_errors=True)


# --------------------------------------------------------------------------
# Packaging checks: MAINTAINER ONLY.
#
# These four prove that the release build cannot ship the author's own campaign
# material to a stranger. They live in `quill_release.py`, which is the build
# tool and is deliberately NOT part of this download -- it is the one file that
# has to write private names down in order to search for them, and a file that
# names them is a file that leaks them.
#
# So in the copy you downloaded these SKIP, on purpose. Nothing is wrong, and
# nothing is being hidden from you: they check the maintainer's packaging, not
# your installation. Everything else in this file runs.
# --------------------------------------------------------------------------

def _packaging(check):
    try:
        import quill_release
    except ImportError:
        raise Skip("maintainer-only: needs the build tool, which testers don't get")
    quill_release.SELFTESTS[check]()


def t_packaging_the_leak_scan_catches_a_planted_leak():
    _packaging("scan catches a planted leak")


def t_packaging_the_shipped_source_is_clean():
    _packaging("shipped source is clean")


def t_packaging_the_manifest_leaves_nothing_unclassified():
    _packaging("manifest is total")


def t_packaging_the_built_zip_has_no_private_material():
    """The exemption-free scan of the built artifact: every entry, raw bytes, no
    path skips. The scanner exempts its own source by name -- you cannot grep a
    blocklist against itself -- and that correct rule hid a real answer, because
    "is this file clean?" is not the same question as "should a stranger have
    this file at all?"."""
    _packaging("built zip has no private material")


def t_a_txt_without_timestamps_is_not_a_session():
    """`transcripts\\` is a folder people put things in -- a README ships in it,
    and DMs drop session notes there. Every report globbed *.txt and took what
    it found, so a notes file became a night: it skewed the Concordance, and if
    it was the newest file the Cold Open built from it and failed instead."""
    from quill_lib import pick_transcripts, has_segments
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        (d / "2026-08-02_1900_real.txt").write_text(
            "# Session transcript - real\n"
            "# source: x.m4a | model: medium.en | duration: 00:00:09\n"
            "#\n# MARKED MOMENTS\n#   [00:00:04] the reveal\n\n"
            "[00:00:01 -> 00:00:09] he tells you the gate is watched\n", encoding="utf-8")
        (d / "README.txt").write_text(
            "Your transcripts land here. Nothing in this folder ships.\n", encoding="utf-8")
        (d / "session-notes.txt").write_text(
            "Ideas for next week:\n- the factor betrays them\n- [00:00:12] is not a segment\n",
            encoding="utf-8")

        picked = [os.path.basename(p) for p in pick_transcripts(str(d))]
        assert picked == ["2026-08-02_1900_real.txt"], picked

        # the header alone must never qualify: a marked moment is written
        # `#   [00:00:04] ...` and SEG_RE anchors at the start of the line
        (d / "header-only.txt").write_text(
            "# Session transcript - x\n#   [00:00:04] a mark\n", encoding="utf-8")
        assert not has_segments(d / "header-only.txt"), \
            "a marks-only header is not a transcript"

        # bounded: a big non-transcript is not read to its end looking for one
        big = d / "huge-notes.txt"
        big.write_text("word " * 400 + "\n[00:00:01 -> 00:00:04] buried\n", encoding="utf-8")
        assert not has_segments(big, limit=200), "the scan is not bounded"
        assert has_segments(big), "a generous default must still find a real segment"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_cold_open_is_never_readable_from_the_wifi():
    """The cold open is the transcript's best parts, concentrated -- verbatim
    quotes, open plot debts, names. It is a bigger privacy leak than a raw
    transcript, not a smaller one, so it is gated exactly like /api/transcript."""
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    i = src.index('elif url.path == "/api/coldopen"')
    assert "_local()" in src[i:i + 320], "/api/coldopen is readable from the LAN"
    assert '"/api/coldopen/build"' in src[src.index("def do_POST"):], \
        "the cold-open build is no longer gated to the studio machine"
    j = src.index('if self.path in ("/api/record/start"')
    gate = src[j:j + 400]
    assert "/api/coldopen/build" in gate and "self._deny()" in gate, \
        "the build must sit inside the local-only gate, not beside it"


def t_cold_open_renderer_escapes_before_it_formats():
    """Every quoted line in the sheet is raw speech-to-text of whatever was said
    at the table. Format first and a stray < would become live markup in the
    DM's own browser; escape first and it stays text. Order is the whole fix."""
    page = (HERE / "web" / "index.html").read_text(encoding="utf-8")
    assert page.count("inlineMd(esc(") >= 4, \
        "the renderer formats un-escaped text somewhere"
    assert "esc(inlineMd(" not in page, "escaping runs AFTER formatting -- backwards"
    body = page[page.index("function renderMd("):page.index("return out.join(\"\");")]
    assert "innerHTML" not in body, "the renderer should build a string, not touch the DOM"


def t_cold_open_knows_when_it_has_gone_stale():
    """The drawer must answer 'is this sheet still about my newest night?' with
    the SAME picker the generator uses -- including that a Chorus night's own
    voice tracks are not nights. Otherwise finishing a merge leaves the drawer
    claiming stale forever, with a rebuild that changes nothing."""
    import quill_server as QS
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    tr = d / "transcripts"; tr.mkdir()
    keep = (QS.TRANSCRIPTS, QS.COLD_OPEN)
    QS.TRANSCRIPTS, QS.COLD_OPEN = tr, d / "COLD-OPEN.md"
    seg = "[00:00:01 -> 00:00:04] hello\n"
    def put(name, when):
        p = tr / name
        p.write_text(seg, encoding="utf-8")
        os.utime(p, (when, when))
    try:
        assert QS.cold_open_state() == {"exists": False, "newest": None, "stale": False}

        put("2026-08-02_1900_one.txt", 1_000_000)
        s = QS.cold_open_state()
        assert s["exists"] is False and s["stale"] is True, s

        QS.COLD_OPEN.write_text(
            "*Built from `2026-08-02_1900_one.txt` (00:00:04 recorded).*\n", encoding="utf-8")
        s = QS.cold_open_state()
        assert s["exists"] and not s["stale"], s
        assert s["built_from"] == "2026-08-02_1900_one.txt", s

        put("2026-08-03_1900_two.txt", 2_000_000)          # a newer night
        assert QS.cold_open_state()["stale"], "a newer session must read as stale"

        # built from the merged Chorus master -> its own voice tracks are the
        # SAME night and must not re-stale the sheet
        put("2026-08-04_1900_three_chorus.txt", 3_000_000)
        QS.COLD_OPEN.write_text(
            "*Built from `2026-08-04_1900_three_chorus.txt` (00:00:04 recorded).*\n",
            encoding="utf-8")
        assert not QS.cold_open_state()["stale"], "the merged master is the newest night"
        put("2026-08-04_1900_three__kris.txt", 4_000_000)
        put("2026-08-04_1900_three__dm.txt",   5_000_000)
        s = QS.cold_open_state()
        assert not s["stale"], \
            f"a voice track is not a night -- drawer would nag forever (newest={s['newest']})"
    finally:
        QS.TRANSCRIPTS, QS.COLD_OPEN = keep
        shutil.rmtree(d, ignore_errors=True)


def t_one_answer_to_where_the_notes_are():
    """Four tools each grew their own flag for the same question -- --canon on
    the cold open, the concordance and the miner, --notes on the lexicon -- all
    defaulting to ../Campaigns,../World, two folders that exist on nobody's
    machine. So on every real install all four silently ran degraded."""
    from quill_lib import notes_roots, notes_found, canon_roots_from_flag
    import quill_lib
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    keep = quill_lib.NOTES_FILE
    quill_lib.NOTES_FILE = str(d / "NOTES.txt")
    try:
        real = d / "campaign"; real.mkdir()
        (d / "NOTES.txt").write_text(
            f"# a comment must not be read as a path\n{real}\n", encoding="utf-8")
        roots = notes_roots()
        assert roots == [str(real)], roots
        assert notes_found(roots) == [str(real)]
        assert notes_found([str(d / "nope")]) == [], "a missing folder must not count"

        # an explicit flag wins; an explicitly empty one opts out entirely
        assert canon_roots_from_flag(None) == [str(real)], "unset should use NOTES.txt"
        assert canon_roots_from_flag("") == [], '"" must mean do not search'
        other = d / "other"; other.mkdir()
        assert canon_roots_from_flag(str(other)) == [str(other)], "a flag must win"
    finally:
        quill_lib.NOTES_FILE = keep
        shutil.rmtree(d, ignore_errors=True)


def t_no_report_claims_it_read_notes_that_were_never_there():
    """Three sheets make claims about your campaign notes. With no notes to
    read, the concordance labelled every name in the campaign "recorded nowhere
    else" and the mirror would have reported a night of pure improvisation --
    both statements about files nobody opened."""
    d, p = transcript([(i * 6, i * 6 + 5, "he tells you Corrin holds the seal tonight")
                       for i in range(8)])
    try:
        rc, _o = _run("Quill-Concordance.py", "--transcripts", d / "transcripts",
                      "--out", d / "C.md", "--canon", "")
        assert rc == 0
        con = (d / "C.md").read_text(encoding="utf-8")
        assert "No campaign notes were searched" in con, con[:400]
        assert "recorded nowhere else" not in con.split("## ")[0], \
            "still claims the names are absent from notes it never read"

        rc, _o = _run("Quill-Mirror.py", d / "transcripts", "--out", d / "M.md",
                      "--canon", "")
        assert rc == 0
        mir = (d / "M.md").read_text(encoding="utf-8")
        s = mir[mir.index("## Prep and improvisation"):]
        assert "no campaign notes were searched" in s.lower(), s[:400]
        assert "arrived at the table" not in s.lower(), \
            "called names improvised without checking the notes"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_the_mirror_reads_one_night_not_one_voice():
    """The Mirror picked its session with a raw *.txt scan instead of
    pick_transcripts, so the fix that stops a README counting as a session never
    protected it -- and after a Chorus merge the newest .txt is often a single
    player's track. The Mirror would then report their mostly-silent microphone
    as the whole evening."""
    src = (HERE / "Quill-Mirror.py").read_text(encoding="utf-8")
    assert "pick_transcripts(path)" in src, "the Mirror is back to a raw *.txt scan"
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        tr = d / "transcripts"; tr.mkdir()
        night = "2026-08-05_1900_riverbend"
        (tr / f"{night}_chorus.txt").write_text(
            "".join(f"[00:0{i}:00 -> 00:0{i}:05] [DM  ] he tells you the gate is watched\n"
                    for i in range(1, 6)), encoding="utf-8")
        # a lone voice track, written LAST so a naive newest-file scan grabs it
        (tr / f"{night}__kris.txt").write_text(
            "[00:04:00 -> 00:04:02] yeah\n", encoding="utf-8")
        os.utime(tr / f"{night}_chorus.txt", (1_000_000, 1_000_000))
        os.utime(tr / f"{night}__kris.txt", (2_000_000, 2_000_000))
        from quill_lib import pick_transcripts
        picked = pick_transcripts(str(tr))
        newest = max(picked, key=os.path.getmtime)
        assert newest.endswith("_chorus.txt"), \
            f"the Mirror would have read one voice as the night: {os.path.basename(newest)}"
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_the_web_face_reaches_everything_the_terminal_does():
    """The terminal studio could mine a transcript, run the pre-game check,
    rehearse the Chorus and rebuild the lexicon; the web face -- the one that
    works from a phone and the one that would ever ship -- could do none of it.
    Every one of these reads or writes the campaign, so every route is gated to
    the studio machine."""
    import quill_server as QS
    assert set(QS.HOUSE) == {"doctor", "rehearsal"}, QS.HOUSE
    for k, spec in QS.HOUSE.items():
        script = [c for c in spec["cmd"] if c and c.endswith((".ps1", ".py"))][0]
        assert (HERE / script).is_file(), f"{k}: {script} missing"

    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    gate = src[src.index('if self.path in ("/api/record/start"'):][:700]
    for route in ("/api/house/run", "/api/mine", "/api/lexicon", "/api/lexicon/add"):
        assert route in gate, f"{route} is not inside the local-only gate"
    i = src.index('elif url.path == "/api/house"')
    assert "_local()" in src[i:i + 200], "/api/house is readable from the LAN"

    page = (HERE / "web" / "index.html").read_text(encoding="utf-8")
    for needle, why in [("/api/mine", "the Shelf can no longer mine a session"),
                        ("/api/house/run", "the pre-game check and rehearsal are gone"),
                        ("/api/lexicon/add", "the lexicon cannot be written from the page")]:
        assert needle in page, why

    # the digest must not be mistakable for a transcript by the picker
    assert '"_digest.md"' in src or "_digest.md" in src, "digest naming changed"
    from quill_lib import _copy_rank
    assert not str(HERE / "x_digest.md").endswith(".txt")


def t_the_lexicon_keeps_what_you_took_and_forgets_what_you_threw_away():
    """The block is rebuilt every run, and that broke its own promise twice.

    Accepted names VANISHED: a name suggested last week is in the file, so it
    counts as covered, so it is not in this run's picks, so rebuilding from
    picks deleted it. Measured -- run one added Valdren and Salt Compact, run
    two left only the new name.

    Pruned names CAME BACK: delete a bad suggestion and it is no longer in the
    file, so it is no longer covered, so the next run offers it again. A bad
    hint actively biases the transcriber, so "prune freely" has to be true."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("_lex", HERE / "Quill-Lexicon.py")
    lex = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lex)

    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    try:
        p = d / "lexicon.txt"
        p.write_text("# my own names\nCorrin\n", encoding="utf-8")

        lex.merge_into_lexicon(str(p), ["Valdren", "Salt Compact"])
        body = p.read_text(encoding="utf-8")
        assert "Valdren" in body and "Salt Compact" in body

        # a later run finds a new name; the earlier two are no longer candidates
        lex.merge_into_lexicon(str(p), ["Thessaly"])
        body = p.read_text(encoding="utf-8")
        for n in ("Valdren", "Salt Compact", "Thessaly"):
            assert n in body, f"{n} was deleted by a later run"
        assert "Corrin" in body, "the DM's own lines must never be touched"

        # the DM prunes one by hand
        p.write_text("\n".join(l for l in body.splitlines() if l.strip() != "Valdren")
                     + "\n", encoding="utf-8")
        lex.merge_into_lexicon(str(p), ["Valdren", "Thessaly"])
        body = p.read_text(encoding="utf-8")
        entries = [l.strip() for l in body.split("prune freely) ---")[1].splitlines()
                   if l.strip() and not l.strip().startswith("#")]
        assert "Valdren" not in entries, "a pruned name came back"
        assert "Thessaly" in entries and "Salt Compact" in entries, entries
    finally:
        shutil.rmtree(d, ignore_errors=True)


def t_every_sheet_is_reachable_from_the_page_and_none_from_the_wifi():
    """The web face could build and read exactly one of the sheets; the others
    dead-ended in a folder the same way the cold open used to. Every one of them
    is quotes from the campaign -- the ledger is literally what the NPCs
    promised, the session log names every night by label -- so all of them are
    gated like /api/transcript."""
    import quill_server as QS
    assert set(QS.REPORTS) == {"coldopen", "mirror", "ledger", "concordance",
                               "log"}, QS.REPORTS
    for k, spec in QS.REPORTS.items():
        if spec["script"] is None:
            continue                    # a sheet that writes itself; see below
        assert (HERE / spec["script"]).is_file(), f"{k}: {spec['script']} missing"

    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    i = src.index('elif url.path in ("/api/report", "/api/reports")')
    assert "_local()" in src[i:i + 300], "the sheets are readable from the LAN"
    gate = src[src.index('if self.path in ("/api/record/start"'):][:500]
    for route in ("/api/report/build", "/api/report/tick"):
        assert route in gate, f"{route} is not inside the local-only gate"

    page = (HERE / "web" / "index.html").read_text(encoding="utf-8")
    assert "/api/reports" in page and "/api/report/build" in page, \
        "the Reading Room no longer reaches the sheets"
    # the Mirror's shape-of-the-night chart lives in a fenced block
    assert "co-pre" in page and 'startsWith("```")' in page, \
        "fenced blocks are no longer preserved -- the Mirror's chart would flatten"


def t_a_sheet_that_writes_itself_is_never_stale_and_offers_no_button():
    """SESSION-LOG.md is the fifth tab in the Reading Room and the only one with
    NO generator -- transcribe.py appends a row as each transcription finishes.
    Every other sheet in the registry answers "rebuild me"; this one cannot, so
    three things have to hold or the tab becomes a lie:

      - it is never STALE. Staleness means "a rebuild would say something
        different", and there is no rebuild. A dot beside a button that does not
        exist is an instruction the DM cannot follow.
      - a build POST is REFUSED with a sentence. The page hides the button, but
        the route is still there, and `HERE / None` is a TypeError -- a 500
        where an explanation belongs.
      - "rebuild all" skips it. Sweeping it in would count one guaranteed
        failure on every single press.
    """
    import quill_server as QS
    spec = QS.REPORTS["log"]
    assert spec["script"] is None and spec["file"] == "SESSION-LOG.md", spec

    r = QS.build_report("log")
    assert not r["ok"] and "nothing to rebuild" in r["error"], r
    assert QS.report_lock.acquire(blocking=False), "the refusal kept the build lock"
    QS.report_lock.release()

    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    keepH, keepT = QS.HERE, QS.TRANSCRIPTS
    QS.HERE, QS.TRANSCRIPTS = d, d / "transcripts"
    try:
        QS.TRANSCRIPTS.mkdir()
        (d / "SESSION-LOG.md").write_text("| a | b |\n|---|---|\n", encoding="utf-8")
        (d / "CONCORDANCE.md").write_text("# who this campaign knows\n", encoding="utf-8")
        # a transcript that landed AFTER both were written -- the mtime rule
        # every other sheet uses would call this stale
        time.sleep(0.05)
        (QS.TRANSCRIPTS / "night.txt").write_text(
            "[00:00:01 -> 00:00:04] the warden's hands are shaking\n", encoding="utf-8")
        st = QS.report_state("log")
        assert st["exists"] and st["newest"] == "night.txt", st
        assert st["stale"] is False, "a sheet with no generator was called stale"
        assert st["buildable"] is False, st

        # ...and before its first row exists either. The tab dot means PRESS
        # REBUILD, and the page lights it on `stale || !exists` -- so a missing
        # SESSION-LOG.md lit a dot pointing at a button that is not there. Found
        # in the browser, not here: the unit check only covered the file
        # existing, which is why the assertion below is on both states.
        (d / "SESSION-LOG.md").unlink()
        gone = QS.report_state("log")
        assert gone["exists"] is False and gone["stale"] is False, gone
        # and the sheets that DO have one still answer the old way
        assert QS.report_state("concordance")["buildable"] is True
        assert QS.report_state("concordance")["stale"] is True, \
            "the mtime staleness rule stopped working for the real sheets"
    finally:
        QS.HERE, QS.TRANSCRIPTS = keepH, keepT
        shutil.rmtree(d, ignore_errors=True)

    page = (HERE / "web" / "index.html").read_text(encoding="utf-8")
    assert '$("btn-cold").style.display = c.buildable' in page, \
        "the Rebuild button no longer hides for a sheet that cannot be rebuilt"
    assert 'r.buildable' in page and 'buildables.slice()' in page, \
        "'rebuild all' is no longer driven by which sheets actually build"
    assert "(r.buildable && (r.stale || !r.exists))" in page, \
        "the tab dot can light on a sheet with no Rebuild button to press"
    # the log is a markdown TABLE; without table support it renders as raw pipes
    assert "co-tbl" in page and "flushTable" in page, \
        "pipe tables are no longer rendered -- the Session Log would be pipe soup"


def t_ticking_a_promise_off_leaves_every_other_byte_alone():
    """LEDGER.md is the one sheet the DM is invited to EDIT -- ticked boxes,
    notes written under entries, entries deleted on purpose -- and re-running
    the generator preserves all of it. A tick from the web page has to be just
    as careful, so it rewrites one character on one line. Anything cleverer
    eventually eats somebody's notes."""
    import quill_server as QS
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    keep = QS.HERE
    QS.HERE = d
    try:
        original = (
            "# LEDGER — what was promised at this table\n\n"
            "**2 open** · last scan 2026-08-05\n\n"
            "- [ ] `night@00:00:10` **PROMISE** (world)\n"
            "  > he says come back when you have the seal\n"
            "  MY NOTE: he meant the brass one\n"
            "- [ ] `night@00:00:30` **DEBT** (party)\n"
            "  > the innkeeper owes you a favour\n"
            "<!-- retired: night@00:01:00 -->\n"
        )
        led = d / "LEDGER.md"
        led.write_text(original, encoding="utf-8")

        r = QS.tick_ledger("night@00:00:10", True)
        assert r["ok"] and r["changed"] == 1, r
        after = led.read_text(encoding="utf-8")
        assert "- [x] `night@00:00:10`" in after, after
        assert "- [ ] `night@00:00:30`" in after, "it touched a different entry"
        assert "MY NOTE: he meant the brass one" in after, "it ate a hand-written note"
        assert "<!-- retired: night@00:01:00 -->" in after, "it resurrected a deletion"
        assert sum(a != b for a, b in zip(original, after)) == 1 and \
            len(original) == len(after), "more than one character changed"

        assert QS.tick_ledger("night@00:00:10", False)["ok"], "a debt must reopen"
        assert led.read_text(encoding="utf-8") == original, \
            "unticking did not return the file to exactly what it was"

        bad = QS.tick_ledger("night@99:99:99", True)
        assert not bad["ok"], "ticked an entry that isn't there"
        assert led.read_text(encoding="utf-8") == original, "a miss still wrote"
    finally:
        QS.HERE = keep
        shutil.rmtree(d, ignore_errors=True)


def t_campaign_wide_sheets_go_stale_on_any_new_session():
    """The cold open and the mirror are about ONE night, so they name it and
    staleness means a newer night exists. The ledger and the concordance read
    every transcript there is, so the only sensible question is whether anything
    has changed since they were built."""
    import quill_server as QS
    d = Path(tempfile.mkdtemp(prefix="quilltest_"))
    tr = d / "transcripts"; tr.mkdir()
    keep = (QS.HERE, QS.TRANSCRIPTS)
    QS.HERE, QS.TRANSCRIPTS = d, tr
    try:
        (tr / "2026-08-01_1900_one.txt").write_text(
            "[00:00:01 -> 00:00:04] hello\n", encoding="utf-8")
        os.utime(tr / "2026-08-01_1900_one.txt", (1_000_000, 1_000_000))

        s = QS.report_state("ledger")
        assert s["exists"] is False and s["stale"] is True, s
        assert s["title"] == "Ledger" and s["blurb"], s

        led = d / "LEDGER.md"
        led.write_text("# LEDGER\n", encoding="utf-8")
        os.utime(led, (2_000_000, 2_000_000))
        assert not QS.report_state("ledger")["stale"], "built after the session: fresh"

        (tr / "2026-08-02_1900_two.txt").write_text(
            "[00:00:01 -> 00:00:04] hello\n", encoding="utf-8")
        os.utime(tr / "2026-08-02_1900_two.txt", (3_000_000, 3_000_000))
        assert QS.report_state("ledger")["stale"], "a newer session must make it stale"

        # and the tab strip must not ship the whole sheet on every poll
        assert "text" not in QS.report_state("ledger", with_text=False), \
            "the tab list is carrying full sheet bodies"
    finally:
        QS.HERE, QS.TRANSCRIPTS = keep
        shutil.rmtree(d, ignore_errors=True)


def t_the_rehearsal_checks_the_things_that_matter():
    """The rehearsal is the only proof the Chorus works end to end, so its two
    load-bearing checks must not quietly disappear: words coming back under the
    right speaker, and a latecomer landing where the clock says rather than at
    the top of the night. Verified by breaking the merge on purpose (offsets
    dropped) -- every other check stayed green and only the clock one noticed."""
    src = (HERE / "Quill-Rehearsal.py").read_text(encoding="utf-8")
    for needle, why in [
        ("came back under its own name", "the cross-attribution check is gone"),
        ("lands where the clock says",   "the clock-sync check is gone"),
        ("LATE_S",                        "nobody joins late any more, so offsets stay 0"),
        ("a wrong table code is turned away", "the token check is gone"),
        ("every byte sent is a byte stored",  "the upload integrity check is gone"),
    ]:
        assert needle in src, why
    # it must never be able to run against the real studio's port
    assert "PORT = 8021" in src, "the rehearsal could collide with a live game on 8020"
    # and the server has to honour the override that makes that possible
    srv = (HERE / "quill_server.py").read_text(encoding="utf-8")
    assert 'os.environ.get("QUILL_PORT")' in srv, \
        "the port override is gone, so the rehearsal would fight a live studio"
    import ast
    ast.parse(src)                      # syntax, without importing (it spawns a server)


def t_merge_button_is_the_studios_call():
    """The merge spawns transcription jobs on the DM's machine; like open and
    close, it must never be reachable by a phone (or anything else on the wifi).
    And the web page must actually offer it -- the old flow ended with 'go run
    python Quill-Chorus.py in a terminal', a cliff at the moment of payoff."""
    src = (HERE / "quill_server.py").read_text(encoding="utf-8")
    assert 'act in ("open", "close", "merge")' in src, \
        "the merge action is no longer gated to the studio machine"
    assert 'act == "merge"' in src, "the merge branch is gone from the server"
    page = (HERE / "web" / "index.html").read_text(encoding="utf-8")
    assert "/api/chorus/merge" in page, \
        "the web studio no longer offers the merge button"


# --------------------------------------------------------------------------
# The guards, over a real socket.
#
# Every other check in this file that claims to prove the local-only gate reads
# quill_server.py as TEXT and asserts a substring is present. Two of them even
# say "verified over a real socket from the LAN address" in their docstring --
# and no test in this file had ever opened a socket. Those checks catch the gate
# being DELETED. They cannot catch it being defeated, and they would all still
# pass if `_local` were changed to `return True`.
#
# So: stand the real server up, speak real HTTP at it, and -- because a test
# that has never failed is not yet a test -- break each guard on purpose and
# prove the check goes red.
# --------------------------------------------------------------------------

def _wire_server():
    """The actual ThreadingHTTPServer, on a port nothing else is using."""
    import socket as _s
    from http.server import ThreadingHTTPServer
    import quill_server as QS
    probe = _s.socket()
    probe.bind(("127.0.0.1", 0))
    port = probe.getsockname()[1]
    probe.close()
    srv = ThreadingHTTPServer(("0.0.0.0", port), QS.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, port, QS


def _speak(port, host, path, method="GET", origin=None, connect_to="127.0.0.1"):
    """One raw HTTP request. Raw, because Host and Origin are the whole point
    and no polite client will let us forge them."""
    import socket as _s
    body = "{}" if method == "POST" else None
    req = f"{method} {path} HTTP/1.1\r\nHost: {host}\r\n"
    if origin:
        req += f"Origin: {origin}\r\n"
    if body is not None:
        req += f"Content-Type: application/json\r\nContent-Length: {len(body)}\r\n"
    req += "Connection: close\r\n\r\n"
    c = _s.create_connection((connect_to, port), timeout=10)
    try:
        c.sendall(req.encode() + (body.encode() if body else b""))
        buf = b""
        while True:
            chunk = c.recv(8192)
            if not chunk:
                break
            buf += chunk
    finally:
        c.close()
    head = buf.split(b"\r\n", 1)[0].decode(errors="replace")
    return int(head.split()[1]), buf.decode(errors="replace")


def t_the_local_only_guard_holds_over_a_real_socket():
    """The privacy promise, tested as a stranger would attack it rather than as
    a substring. `/api/transcript` is the one that matters: it is the campaign.

    The LAN half is the real receipt -- connecting to this machine's own LAN
    address makes the kernel put that address in client_address, so the server
    genuinely sees a non-loopback caller. That is the café-wifi case, reproduced."""
    srv, port, QS = _wire_server()
    try:
        # the DM's own browser gets through the gate (404 = no such transcript,
        # which is the gate saying yes and the filesystem saying no)
        code, _ = _speak(port, f"127.0.0.1:{port}", "/api/transcript?name=nope")
        assert code != 403, "the studio's own browser was locked out of its transcripts"

        lan = QS.lan_ip()
        if lan == "127.0.0.1":
            return                      # no network: the LAN half cannot be staged
        for path in ("/api/transcript?name=nope", "/api/house", "/api/coldopen",
                     "/api/report?name=ledger", "/api/reports"):
            code, txt = _speak(port, f"{lan}:{port}", path, connect_to=lan)
            assert code == 403, (
                f"{path} answered {code} to a LAN client -- anyone on the same "
                f"wifi can read this: {txt[-160:]}")
        # status stays open on purpose (the phones need it) but must not carry
        # the Chorus table code, which is the write credential for the night
        code, txt = _speak(port, f"{lan}:{port}", "/api/chorus/status", connect_to=lan)
        assert code == 200 and '"token"' not in txt, \
            "the table code is being served to the whole wifi: " + txt[-160:]

        # ...nor the session shelf. Transcript BODIES were locked down while
        # their TITLES rode out on the open endpoint -- and a label is the
        # campaign's name and what happened in it. Fix the class, not the file.
        code, txt = _speak(port, f"{lan}:{port}", "/api/status", connect_to=lan)
        assert code == 200, f"the phones' own endpoint broke: {code}"
        assert '"sessions": []' in txt.replace('"sessions":[]', '"sessions": []'), \
            "the session shelf is being served to the whole wifi: " + txt[-200:]
        # and the DM's own browser must still get it, or the studio has no shelf
        code, txt = _speak(port, f"127.0.0.1:{port}", "/api/status")
        assert '"sessions"' in txt, "the studio lost its own session shelf"
    finally:
        srv.shutdown()


def t_dns_rebinding_and_cross_site_are_refused_over_a_real_socket():
    """A hostname that re-resolves to 127.0.0.1 turns the loopback check into a
    welcome mat: the request really does arrive from this machine. The Host
    header is what a browser will not let the attacker forge, so it is what the
    server checks -- here, against a real one."""
    srv, port, _ = _wire_server()
    try:
        for good in (f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"):
            code, _ = _speak(port, good, "/api/status")
            assert code != 421, f"a real way to reach the studio was refused: {good}"
        for bad in ("evil.example.com", f"quill.attacker.test:{port}",
                    f"localhost.evil.example.com:{port}", ""):
            code, _ = _speak(port, bad, "/api/transcript?name=nope")
            assert code == 421, f"rebindable Host accepted: {bad!r} -> {code}"
        # a cross-site page must not be able to drive the studio
        code, _ = _speak(port, f"127.0.0.1:{port}", "/api/record/start", "POST",
                         origin="https://evil.example.com")
        assert code == 421, f"a foreign Origin drove a POST: {code}"
        # ...while the studio's own page still can (404 = past both gates, and
        # deliberately a path with no side effect: asserting on /api/record/start
        # would start a real recording)
        code, _ = _speak(port, f"127.0.0.1:{port}", "/api/nothing-here", "POST",
                         origin=f"http://127.0.0.1:{port}")
        assert code == 404, f"the studio's own page was refused its own API: {code}"
    finally:
        srv.shutdown()


def t_breaking_a_guard_actually_turns_the_guard_tests_red():
    """Suspect the tests. The two checks above are only worth having if they
    fail when the thing they describe is broken -- so break it, on purpose, and
    confirm they notice. This is the check that the OLD substring tests could
    never have passed: `"def _local(self)" in src` is still true when the body
    of `_local` is `return True`."""
    import quill_server as QS

    real_local, real_host = QS.Handler._local, QS.Handler._host_ok
    try:
        QS.Handler._local = lambda self: True          # the gate, wedged open
        srv, port, _ = _wire_server()
        try:
            lan = QS.lan_ip()
            if lan != "127.0.0.1":
                code, _ = _speak(port, f"{lan}:{port}", "/api/transcript?name=nope",
                                 connect_to=lan)
                assert code != 403, \
                    "a wedged-open _local() still refused the LAN -- the wire " \
                    "test is not measuring the guard it claims to measure"
        finally:
            srv.shutdown()
        QS.Handler._local = real_local

        QS.Handler._host_ok = lambda self: True        # rebinding check removed
        srv, port, _ = _wire_server()
        try:
            code, _ = _speak(port, "evil.example.com", "/api/status")
            assert code != 421, \
                "a removed _host_ok() still refused a forged Host -- the " \
                "rebinding test would pass with the guard gone"
        finally:
            srv.shutdown()
    finally:
        QS.Handler._local, QS.Handler._host_ok = real_local, real_host


def t_the_readme_does_not_misstate_how_many_checks_there_are():
    """README said "27 checks" while the runner printed 51. A tester's very first
    act is to run this file, so the first thing the docs did was get caught
    lying about the thing standing right next to it -- and a doc that is wrong
    where you CAN check it earns no trust where you can't.

    Pinning it here means the number can only ever go stale in a way that fails
    the build, rather than in a way a stranger finds."""
    n = len([k for k in globals() if k.startswith("t_") and callable(globals()[k])])
    readme = (HERE / "README.md").read_text(encoding="utf-8", errors="replace")
    m = re.search(r"test_quill\.py.*?#\s*(\d+)\s*checks", readme, re.S)
    assert m, "README no longer states a check count next to test_quill.py"
    assert int(m.group(1)) == n, (
        f"README claims {m.group(1)} checks; there are {n}. Update README.md.")


def t_the_docs_do_not_send_testers_to_edit_paths_that_are_already_relative():
    """HOW-TO told a tester to "fix the paths in the two `.bat` files". Both were
    made %~dp0-relative long ago, so the instruction sends a stranger hunting for
    an edit that does not exist, on line numbers that do not exist. Stale
    instructions are the failure mode that outlives every other kind of bug."""
    for name in ("HOW-TO.md", "README.md"):
        t = (HERE / name).read_text(encoding="utf-8", errors="replace")
        assert "fix the paths in the two" not in t, \
            f"{name} still tells testers to edit paths that are already relative"
    for bat in ("The Quill.bat", "Gnashers Quill Web.bat"):
        b = (HERE / bat).read_text(encoding="utf-8", errors="replace")
        assert "%~dp0" in b, f"{bat} is no longer folder-relative"


def t_the_chorus_page_blames_http_not_the_browser():
    """Browsers expose a microphone only in a secure context. On the studio's
    plain-http LAN address `navigator.mediaDevices` is undefined, so the Chorus
    join page fired "This browser can't record audio. Try Chrome (Android) or
    Safari (iPhone)" -- at someone already holding Chrome on Android. The page
    must name the real cause, and the docs must not promise phone recording."""
    page = (HERE / "web" / "chorus.html").read_text(encoding="utf-8", errors="replace")
    assert "isSecureContext" in page, \
        "the Chorus page no longer detects the insecure-origin case at all"
    i = page.index("isSecureContext")
    assert "http" in page[i:i + 700], \
        "the insecure-origin branch does not tell the DM that http is the cause"


def main():
    print("\n  GNASHER'S QUILL - regression net")
    print("  " + "-" * 62)
    tests = [(n[2:].replace("_", " "), f) for n, f in sorted(globals().items())
             if n.startswith("t_") and callable(f)]
    for name, fn in tests:
        check(name, fn)
    print("  " + "-" * 62)
    tail = f", {len(SKIP)} skipped" if SKIP else ""
    print(f"  {len(PASS)} passed, {len(FAIL)} failed{tail}, {len(tests)} total")
    if FAIL:
        print("\n  Something that used to be true has stopped being true:")
        for n, _ in FAIL:
            print(f"    - {n}")
    print()
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
