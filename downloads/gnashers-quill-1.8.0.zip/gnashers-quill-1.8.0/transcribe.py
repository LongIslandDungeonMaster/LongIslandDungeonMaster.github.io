#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
transcribe.py - local, offline session-audio transcription. The engine inside The Quill.
Uses faster-whisper (CPU, free). Driven by Transcribe-Session.ps1, but runnable directly:

    python transcribe.py "recordings/2026-07-19_saltmere-shackles.m4a" --model small.en

Writes a timestamped .txt next to the audio's twin in ../transcripts/.
First run per model downloads it from HuggingFace (needs internet ONCE); after that,
fully offline.

Extras it picks up automatically if present:
  - lexicon.txt (next to this script): campaign proper nouns fed to the model as
    hotwords so it spells "Vethric Ashgrave" instead of guessing. Edit freely.
  - recordings/<name>.markers.txt: moments you marked during recording ([M] in the
    studio). Merged into the transcript header so the recap can find them fast.
  - ../SESSION-LOG.md: one ledger line appended per finished transcript.
"""
import argparse
import datetime
import glob
import logging
import os
import sys
import warnings
from pathlib import Path

# Quiet the HuggingFace noise (telemetry off, no symlink lecture, no token nag).
# After the first model download everything is cached and offline anyway.
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
warnings.filterwarnings("ignore")
logging.getLogger("huggingface_hub").setLevel(logging.ERROR)

def enable_nvidia_dlls() -> None:
    """Make pip-installed cuBLAS/cuDNN visible to ctranslate2 (Windows GPU path).

    Windows only, and the guard matters: os.add_dll_directory does not EXIST on
    macOS/Linux, so this raised AttributeError there. The caller swallows every
    exception, so the failure was invisible -- it just quietly fell back to CPU on
    a Linux box whose CUDA was working fine."""
    if not sys.platform.startswith("win"):
        return
    for sp in sys.path:
        for d in glob.glob(os.path.join(sp, "nvidia", "*", "bin")):
            try:
                os.add_dll_directory(d)
                os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")
            except OSError:
                pass

def pick_device(force_cpu: bool) -> tuple[str, str]:
    """CUDA if a GPU is visible (RTX = ~10x faster), else CPU. (device, compute_type)"""
    if not force_cpu:
        try:
            enable_nvidia_dlls()
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                return "cuda", "float16"
        except Exception:
            pass
    return "cpu", "int8"

def fmt_ts(seconds: float) -> str:
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"

def load_lexicon(script_dir: Path) -> str:
    """Read lexicon.txt -> one comma-joined hint string (empty if no file)."""
    lex_file = script_dir / "lexicon.txt"
    if not lex_file.exists():
        return ""
    names = []
    for line in lex_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            names.append(line)
    return ", ".join(names)

def load_markers(audio: Path) -> list[str]:
    """Read recordings/<name>.markers.txt if the studio wrote one."""
    mfile = audio.parent / (audio.stem + ".markers.txt")
    if not mfile.exists():
        return []
    # utf-8-sig: PowerShell's Add-Content writes a BOM; strip it.
    return [ln.strip() for ln in mfile.read_text(encoding="utf-8-sig").splitlines() if ln.strip()]

def append_session_log(script_dir: Path, audio: Path, out_path: Path,
                       duration: str, model: str, n_segments: int) -> None:
    log = script_dir / "SESSION-LOG.md"
    if not log.exists():
        log.write_text(
            "# Quill Session Log\n\n"
            "One line per transcribed session, newest last. Auto-written by transcribe.py.\n\n"
            "| transcribed | session | duration | model | segments |\n"
            "|---|---|---|---|---|\n",
            encoding="utf-8",
        )
    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    row = f"| {stamp} | [{audio.stem}](transcripts/{out_path.name}) | {duration} | {model} | {n_segments} |\n"
    with log.open("a", encoding="utf-8") as f:
        f.write(row)

def main() -> int:
    ap = argparse.ArgumentParser(description="Transcribe a session recording locally.")
    ap.add_argument("audio", help="Path to the audio file (.m4a/.wav/.mp3/...).")
    ap.add_argument("--model", default="small.en",
                    help="Whisper model: tiny.en, base.en, small.en (default), medium.en. "
                         "Bigger = more accurate + slower.")
    ap.add_argument("--out", default=None, help="Output .txt path (default: ../transcripts/<name>.txt).")
    ap.add_argument("--cpu", action="store_true", help="Force CPU even if a GPU is available.")
    ap.add_argument("--max-speech", type=float, default=20.0, metavar="SEC",
                    help="Hard cap on one VAD speech span (default 20). Lower it if a noisy "
                         "room still produces long segments with almost no words in them.")
    ap.add_argument("--no-log", action="store_true",
                    help="don't append a row to SESSION-LOG.md. Used by Quill-Chorus.py, "
                         "which transcribes one track per voice and would otherwise write "
                         "five ledger rows for a single night.")
    ap.add_argument("--no-hotwords", action="store_true",
                    help="Ignore lexicon.txt. Use if the model starts chanting campaign names "
                         "over quiet stretches instead of transcribing them.")
    args = ap.parse_args()

    audio = Path(args.audio)
    if not audio.exists():
        print(f"ERROR: audio file not found: {audio}", file=sys.stderr)
        return 1

    script_dir = Path(__file__).resolve().parent

    if args.out:
        out_path = Path(args.out)
    else:
        transcripts_dir = audio.parent.parent / "transcripts"
        transcripts_dir.mkdir(exist_ok=True)
        out_path = transcripts_dir / (audio.stem + ".txt")

    try:
        from faster_whisper import WhisperModel
    except ImportError:
        print("ERROR: faster-whisper not installed. Run: python -m pip install faster-whisper",
              file=sys.stderr)
        return 2

    lexicon = load_lexicon(script_dir)
    if lexicon:
        n = lexicon.count(",") + 1
        print(f"Lexicon: {n} campaign names loaded from lexicon.txt (spelling hints).")

    kwargs = dict(
        beam_size=5,
        vad_filter=True,                       # skips silence -> faster, cleaner
        # --- the table-audio fix (2026-07-30) -------------------------------
        # Silero's max_speech_duration_s defaults to *infinity*. At a real table
        # nobody is silent for a clean 800ms -- five people, dice, snacks -- so the
        # VAD never found a split point and merged minutes of room noise into one
        # "speech" span. Whisper then decoded the whole span and emitted ONE line
        # for it. Measured on the 2026-07-19 Saltmere session (5h58m): median
        # segment 31s, and spans like "[67s] Okay." -- 67 seconds of table
        # reduced to one word. Capping the span is what fixes it.
        vad_parameters=dict(
            min_silence_duration_ms=400,       # was 800 - split at real table pauses
            max_speech_duration_s=args.max_speech,  # was inf - THE bug
            # speech_pad_ms stays at the 400ms default ON PURPOSE. Trimming it to 200
            # measurably ate real speech: on the full 5h58m session it cost ~145 words
            # of vocabulary, clipped off the edges of ~1000 chunks. More splits means
            # more edges, so the padding matters MORE here, not less.
            speech_pad_ms=400,
            threshold=0.45,                    # a touch more sensitive for far-field mics
        ),
        # Long table recordings + background noise make Whisper prone to repetition
        # loops when each window is conditioned on the last. Independent windows
        # cost a little coherence, prevent multi-minute hallucination spirals.
        condition_on_previous_text=False,
        word_timestamps=True,                  # word-level splits: marks land on the beat
        repetition_penalty=1.15,               # belt-and-braces against loop spirals
    )
    # A/B on a 20-min slice of that session, medium.en:
    #   median segment 30.7s -> 6.2s | segments 33 -> 62 | speech density +56%
    #   "long span, <=3 words" segments 4 -> 0
    #   and 100s that had produced only hallucinated lexicon names came back as
    #   real content ("Master Strahj ... showed up with two guards ...").
    if lexicon and not args.no_hotwords:
        kwargs["hotwords"] = lexicon

    def run(device: str, compute: str):
        """Load the model and fully transcribe. Returns (lines, info).
        Fully drains the segment generator here so GPU faults surface inside
        this call and the CPU fallback below can still catch them."""
        label = "GPU (CUDA)" if device == "cuda" else "CPU"
        print(f"Loading model '{args.model}' on {label} "
              f"(first run downloads it; then it's cached/offline)...")
        model = WhisperModel(args.model, device=device, compute_type=compute)
        print(f"Transcribing {audio.name} ... (long sessions run unattended)")
        try:
            segments, info = model.transcribe(str(audio), **kwargs)
        except TypeError:
            # Older faster-whisper without hotwords support - fall back gracefully.
            kwargs.pop("hotwords", None)
            if lexicon:
                kwargs["initial_prompt"] = f"A tabletop RPG session. Names: {lexicon}."
            segments, info = model.transcribe(str(audio), **kwargs)
        print(f"Detected language: {info.language} (p={info.language_probability:.2f}), "
              f"duration: {fmt_ts(info.duration)}")
        out_lines = []
        for seg in segments:
            line = f"[{fmt_ts(seg.start)} -> {fmt_ts(seg.end)}] {seg.text.strip()}"
            out_lines.append(line)
            print(line)                        # live progress so you see it working
        return out_lines, info

    device, compute = pick_device(args.cpu)
    try:
        lines, info = run(device, compute)
    except Exception as e:
        if device == "cuda":
            print(f"GPU path failed ({type(e).__name__}) - falling back to CPU.", file=sys.stderr)
            lines, info = run("cpu", "int8")
        else:
            raise

    header = (
        f"# Session transcript - {audio.stem}\n"
        f"# source: {audio.name} | model: {args.model} | "
        f"duration: {fmt_ts(info.duration)}\n"
        f"# RAW auto-transcript. Saved in Quill\\transcripts\\ - ready for session prep.\n"
    )
    markers = load_markers(audio)
    if markers:
        header += ("#\n# MARKED MOMENTS - flagged live at the table. A mark is pressed just\n"
                   "# AFTER the moment lands, so the beat it points at sits shortly BEFORE\n"
                   "# each timestamp. Check these first when building the recap:\n")
        for m in markers:
            header += f"#   {m}\n"
    header += "\n"

    out_path.write_text(header + "\n".join(lines) + "\n", encoding="utf-8")
    if not args.no_log:
        append_session_log(script_dir, audio, out_path, fmt_ts(info.duration),
                           args.model, len(lines))
    print(f"\nDONE -> {out_path}")
    if markers:
        print(f"({len(markers)} marked moment(s) carried into the transcript header.)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
