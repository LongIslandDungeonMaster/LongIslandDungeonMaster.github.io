# Gnasher's Quill

**Record your tabletop session. Get back what your table actually said.**

No cloud. No subscription. No account. **No AI listening at your table.** Your audio never
leaves your machine — the transcription runs locally, offline, on hardware you own.

Every other session tool asks you to upload your table's audio to someone's server and pay
monthly. This one doesn't, and that isn't a limitation to apologise for. It's the product.

---

## What it actually gives you

Recording a session is the easy part. The hard part is that a six-hour recording becomes
120 KB of unpunctuated text that nobody will ever read. So the Quill reads it *for* you:

- **`LEDGER.md`** — the promises, debts and threats spoken aloud, in fiction, across every
  session. *A campaign doesn't die because you forgot last session. It dies because in
  session 4 an NPC said "come back when you have the seal", the players wrote it down, and
  you never did.*
- **`CONCORDANCE.md`** — a who's-who that builds itself, plus search across every night.
  *"When did we first meet Talia?"* is one command.
- **`COLD-OPEN.md`** — the page you read twenty minutes before the players arrive: how
  last session ended in your own words, what you pinned, what you still owe, who turned up
  that you never wrote down, and where the table leaned in.
- **`MIRROR.md`** — how you **ran** it. The shape of the night, where the clock went, your
  longest unbroken narration, dead air. No other session tool tells a DM anything about
  their own craft.
- **The Chorus** — every player's phone records *their own voice*, so the transcript knows
  who said what. Including **who didn't get to talk**.

All of it is deterministic: vocabulary lists, timestamps and arithmetic. Nothing here calls
a model to decide what your session meant.

---

## Install

**Windows** — if you downloaded this as a zip: **right-click the zip → Properties → tick
`Unblock` → OK**, and only *then* extract it. Windows marks downloaded files and will refuse to
run the scripts otherwise. Extract somewhere simple like `C:\Quill` — not inside OneDrive.

Then double-click **`SETUP (run me first).bat`**. That's the whole install.

(The equivalent from a terminal, if you prefer one:)

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup-Quill.ps1
```

Windows may warn that the publisher can't be verified — these are unsigned PowerShell scripts, and
everything they do is plain text you can read in this folder.

**macOS / Linux:**

```bash
chmod +x setup-quill.sh quill && ./setup-quill.sh
```

Both are idempotent, ask before installing anything, and support `--dry-run` / `-DryRun`.
They install Python, ffmpeg and `faster-whisper`, then verify the whole chain.

Then, before a session you care about:

On Windows, double-click **`Quill Doctor.bat`** (or press `[D]` in the studio).
On macOS / Linux:

```bash
./quill doctor
```

It checks Python, ffmpeg, **a working microphone**, GPU, whether the speech model is cached
for offline use, disk space, and that the crash-safety and VAD fixes are still in place —
and prints the exact command to fix anything missing. The worst failure this tool has is
discovering at 7pm that something isn't installed. This is the thirty seconds that prevents it.

---

## The 60-second version

1. **Record.** `The Quill.bat` → `[1]`, or `./quill` for the browser studio. One audio file
   covers the whole game.
2. **Mark moments as they land.** Press `[M]`, tap the floating button, or use your phone.
   Marks are **retroactive** — you press *after* the beat, because nobody can see a great
   moment coming.
3. **Transcribe** after everyone goes home. Local, offline, free. Minutes on a GPU.
4. **Mine it.** `[8]` or `./quill mine`. Health check, your marks with the audio *before*
   them, and names your table said that aren't in your notes.

---

## Everything in the box

| | what it does |
|---|---|
| `The Quill.bat` / `./quill` | the studio — record, transcribe, everything below |
| `Quill-Doctor.ps1` | pre-game check of the whole chain, with fixes |
| `Setup-Quill.ps1` / `setup-quill.sh` | install what's missing |
| `transcribe.py` | the local speech engine (faster-whisper) |
| `Mine-Transcript.py` | one session → a digest worth reading |
| `Quill-Ledger.py` | what you owe your players, across all sessions |
| `Quill-Concordance.py` | who's-who + `--find` search over every night |
| `Quill-Mirror.py` | how you ran it |
| `Quill-Lexicon.py` | build the name list from notes you already wrote |
| `Quill-ColdOpen.py` | the pre-session sheet — "right, previously…" |
| `Quill-Chorus.py` | merge one-track-per-voice into a speaker-labelled transcript |
| `Quill-Marker.ps1` | floating always-on-top MARK button |
| `quill_platform.py` | the only file that knows what OS this is — **run it first on a new machine** |

---

## The Chorus

Working out who's speaking from one room microphone is genuinely hard, and five people
talking over each other defeats it. So don't. **If every voice records itself, the speaker
isn't inferred — it's known.**

Each player opens a link on their own phone, types their name, taps record. Afterwards:

```
[01:42:08 -> 01:42:13] [DM]      The warden's hands are shaking.
[01:42:15 -> 01:42:17] [KRIS]    I step between them.
[01:42:19 -> 01:42:23] [GARTHAX] Bad idea. I ready an action.
```

**Remote tables get this free** — everyone records their local mic, nobody captures the call.

---

## Honest limits

- **Single-mic transcripts have no speaker labels.** That's what the Chorus is for. Where a
  number can't be known from one microphone, the tools say **"couldn't tell"** rather than
  inventing it.
- **Phones stop the mic when the screen locks.** The Chorus page requests a wake lock and
  warns you; if a phone sleeps, that player rejoins and everything already uploaded is safe.
- **macOS and Linux are written but not yet run in anger.** The Quill was built and measured
  on Windows. The audio paths for other platforms follow the documented ffmpeg interfaces,
  but nobody has recorded a real session on a Mac with it yet. `python3 quill_platform.py`
  prints exactly what it detected and the record command it would use — run that first.
- **The terminal studio is Windows-only** (it's PowerShell). The **web studio is the
  cross-platform face**, and it does everything.
- **Ask your table before you record them.** Every time. A recorder nobody agreed to is a
  betrayal, not a tool.
- **It's a LAN tool, not a hardened server.** Control and transcript-reading are locked to
  the machine running it; the Chorus needs the table code from the join link; status and
  the MARK button are open to the network. That is the right shape for a table in a house.
  Don't run it on a network you wouldn't hand a USB stick to.

## Tests

```bash
python test_quill.py          # 60 checks, offline, touches only a temp folder
```

Every test is a bug that shipped or nearly did — the 31-second segments that ate a
six-hour game, the 44-byte crash file, the report that claimed 76% table talk, the
"marked moment" that was really the duration line, the tool that rewrote your line
endings, the flag that let one campaign's ledger overwrite another's.

---

## Why it's built the way it is

A few decisions worth knowing, because each came from something that actually went wrong:

- **Recordings survive a crash.** A normal `.m4a` writes its index at the very end — a hard
  stop at hour five once produced a **44-byte unplayable file**. Audio is now written in
  self-contained fragments; a measured hard kill recovered 10.3 of 12 seconds.
- **Long sessions don't silently collapse.** The voice-activity detector had no cap on how
  long one "speech" stretch could be, so at a real table it merged minutes of room noise
  into a single span and the model returned one line for it. A 5h58m session had a **median
  segment of 31 seconds**; one covered 67 seconds and read `Okay.` Now capped.
- **Nothing overwrites what you wrote.** `LEDGER.md` is yours to edit — tick a box, add
  notes, delete entries. Re-running never clobbers an edit, and deletions stay deleted.
  `Quill-Lexicon.py` preserves your entries *and your line endings* byte-for-byte.

---

## License

**MIT.** See [`LICENSE`](LICENSE). Do what you like with it — fork it, sell it, build it
into something else — just keep the copyright notice.

The Quill **bundles nothing**: no libraries, no binaries, no models ship inside the
download. Your package manager and `pip` fetch what's needed, and the speech model
downloads itself on first use. See [`THIRD-PARTY.md`](THIRD-PARTY.md) — including the one
decision that would change your obligations, if you ever bundle an `ffmpeg` binary.

---

*The Quill records → the Grimoire holds → the Satchel carries.*
