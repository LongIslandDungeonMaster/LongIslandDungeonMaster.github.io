@echo off
title Gnasher's Quill - Web Studio
REM ============================================================
REM  Double-click to open Gnasher's Quill in your browser.
REM  Same engine as the terminal Quill - just a prettier face.
REM  A phone on the same Wi-Fi can open the page too and become
REM  a remote MARK button (the console prints the address).
REM
REM  Leave the console window open while you play - closing it
REM  stops the studio (stop your recording first!).
REM
REM  PORTABLE: finds quill_server.py next to itself, and asks quill_python.ps1
REM  which Python to run - the SAME answer setup, the doctor, the transcriber
REM  and the terminal studio get. A .bat cannot dot-source PowerShell, so it
REM  hands the whole job over instead of keeping its own (differently ordered,
REM  hardcoded-3.12) copy of the search. That copy is why a machine with two
REM  pythons installed faster-whisper into one and transcribed with the other.
REM
REM  the Quill records -> the Grimoire holds -> the Satchel carries
REM ============================================================
setlocal

set "SERVER=%~dp0quill_server.py"
set "FINDPY=%~dp0quill_python.ps1"

if not exist "%SERVER%" (
  echo.
  echo   Can't find quill_server.py. Keep this .bat inside the Quill folder.
  echo.
  pause
  exit /b 1
)

if not exist "%FINDPY%" (
  echo.
  echo   Can't find quill_python.ps1. Keep the whole Quill folder together -
  echo   re-extract the download rather than copying files out of it.
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%FINDPY%" -Run "%SERVER%" -RequireModule faster_whisper
if errorlevel 1 pause
endlocal
