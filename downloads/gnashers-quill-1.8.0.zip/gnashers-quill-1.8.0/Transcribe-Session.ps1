# SPDX-License-Identifier: MIT
<#
    Transcribe-Session.ps1  --  table-audio -> text, local & free. Part of The Quill.

    HOW YOU USE IT (after the game):
      1. Record the session (or use The Quill's menu). One file, saved into:
             Quill\recordings\
         Name it like  2026-07-19_saltmere-shackles.m4a  (any audio format works).
      2. Right-click this file -> "Run with PowerShell"   (or run it in a terminal).
      3. It transcribes every recording that doesn't have a transcript yet and drops
         the .txt into  Quill\transcripts\ , marked moments listed in the header.

    Options:
      .\Transcribe-Session.ps1                 # small.en (fast, good enough)
      .\Transcribe-Session.ps1 -Model medium.en   # slower, more accurate
      .\Transcribe-Session.ps1 -Force         # re-do even already-transcribed files
#>
param(
    [string]$Model = "small.en",
    [switch]$Force
)

# NOTE: deliberately NOT "Stop" - the transcriber prints harmless notices to stderr,
# and in Windows PowerShell that would otherwise abort the run. Step success is
# checked via $LASTEXITCODE below instead.
$ErrorActionPreference = "Continue"
$env:HF_HUB_DISABLE_TELEMETRY = "1"
$here          = Split-Path -Parent $MyInvocation.MyCommand.Path
$recordings    = Join-Path $here "recordings"
$transcripts   = Join-Path $here "transcripts"
$script        = Join-Path $here "transcribe.py"

# --- find python -------------------------------------------------------------
# One search, shared with setup, the doctor and the studio. This file used to
# prefer a HARDCODED Python312 while Setup-Quill.ps1 pip-installed with `py -3`:
# on a machine with both, setup succeeded and transcription then swore
# faster-whisper wasn't installed. Never resolve Python here again.
$pyHelper = Join-Path $here "quill_python.ps1"
if (-not (Test-Path $pyHelper)) {
    Write-Host "ERROR: quill_python.ps1 is missing - keep the whole Quill folder together." -ForegroundColor Red
    exit 1
}
. $pyHelper

$python = Find-Python -RequireModule faster_whisper
if (-not $python) {
    Write-QuillNoPython
    exit 1
}
if ($python.ModuleMissing) {
    Write-Host ""
    Write-Host "ERROR: Python is fine ($($python.Display))," -ForegroundColor Red
    Write-Host "       but faster-whisper is not installed in it - so there is nothing to" -ForegroundColor Red
    Write-Host "       transcribe with. Your recordings are safe and untouched." -ForegroundColor Red
    Write-Host ""
    Write-Host "  Fix: double-click 'SETUP (run me first).bat' and let it finish." -ForegroundColor Cyan
    Write-Host ""
    exit 1
}

if (-not (Test-Path $recordings)) { New-Item -ItemType Directory -Path $recordings | Out-Null }
if (-not (Test-Path $transcripts)) { New-Item -ItemType Directory -Path $transcripts | Out-Null }

# --- gather audio ------------------------------------------------------------
$exts  = @("*.m4a","*.mp3","*.wav","*.flac","*.ogg","*.wma","*.aac","*.mp4")
$audio = foreach ($e in $exts) { Get-ChildItem -Path $recordings -Filter $e -File -ErrorAction SilentlyContinue }

if (-not $audio) {
    Write-Host "No recordings found in:`n  $recordings" -ForegroundColor Yellow
    Write-Host "Drop your session audio there and run this again." -ForegroundColor Yellow
    exit 0
}

$did = 0
foreach ($file in $audio) {
    $outTxt = Join-Path $transcripts ($file.BaseName + ".txt")
    if ((Test-Path $outTxt) -and -not $Force) {
        Write-Host "SKIP (already transcribed): $($file.Name)" -ForegroundColor DarkGray
        continue
    }
    Write-Host "`n=== Transcribing: $($file.Name)  [model: $Model] ===" -ForegroundColor Cyan
    Invoke-Python $python @($script, $file.FullName, "--model", $Model, "--out", $outTxt)
    if ($LASTEXITCODE -eq 0) { $did++ }
    else { Write-Host "FAILED on $($file.Name) (exit $LASTEXITCODE)" -ForegroundColor Red }
}

Write-Host "`nFinished. $did transcript(s) written to:`n  $transcripts" -ForegroundColor Green
Write-Host "Marked moments ride along in each transcript's header - ready for session prep." -ForegroundColor Green
