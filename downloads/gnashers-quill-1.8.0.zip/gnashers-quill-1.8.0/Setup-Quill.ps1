﻿# SPDX-License-Identifier: MIT
# Setup-Quill.ps1 — install everything Gnasher's Quill needs, on a fresh Windows machine.
#
#   Right-click -> Run with PowerShell
#   or:   powershell -ExecutionPolicy Bypass -File Setup-Quill.ps1
#   see what it WOULD do, and change nothing:
#         powershell -ExecutionPolicy Bypass -File Setup-Quill.ps1 -DryRun
#
# `Quill-Doctor.ps1` already works out what is missing and prints the exact command to
# fix it. This is that, with the commands actually run. It is idempotent -- anything
# already present is detected and skipped, so re-running it is always safe.
#
# It installs only these, and tells you before each one:
#   Python 3.12 (winget)  ·  ffmpeg (winget)  ·  faster-whisper (pip)
#   optionally the NVIDIA CUDA runtime libs, and the speech model itself.

[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$Gpu,          # also install the CUDA runtime wheels
    [switch]$Model,        # also pre-download the speech model so night one is offline
    [switch]$Yes           # don't ask, just do it
)

$ErrorActionPreference = "Continue"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$didSomething = $false

function Head($t) { Write-Host ""; Write-Host "  $t" -ForegroundColor White
                    Write-Host ("  " + ("-" * 62)) -ForegroundColor DarkGray }
function Info($t) { Write-Host "  $t" -ForegroundColor Gray }
function Good($t) { Write-Host "  OK   $t" -ForegroundColor Green }
function Warn($t) { Write-Host "  ..   $t" -ForegroundColor Yellow }
function Bad ($t) { Write-Host "  !!   $t" -ForegroundColor Red }

function Confirm-Step($what) {
    if ($DryRun) { Warn "would run: $what"; return $false }
    if ($Yes)    { return $true }
    Write-Host "  ->   $what" -ForegroundColor Cyan
    $a = Read-Host "       run this? (Y/n)"
    return ($a -eq "" -or $a -match '^[Yy]')
}

# Python is found in exactly ONE place for the whole Quill: quill_python.ps1.
# This used to have its own copy of the search, in its own order -- so setup could
# pip-install faster-whisper into one interpreter while the transcriber ran a
# different one, and the DM got "faster-whisper not installed" right after a
# successful install. Whatever Find-Python returns here is what everything else
# will run, which is the entire point.
$pyHelper = Join-Path $here "quill_python.ps1"
if (-not (Test-Path $pyHelper)) {
    Write-Host ""
    Write-Host "  quill_python.ps1 is missing - keep the whole Quill folder together." -ForegroundColor Red
    Write-Host ""
    exit 1
}
. $pyHelper

Write-Host ""
Write-Host "  GNASHER'S QUILL - setup" -ForegroundColor White
Write-Host "  $here" -ForegroundColor DarkGray
if ($DryRun) { Write-Host "  DRY RUN - nothing will be installed" -ForegroundColor Yellow }

# --- 1. winget ---------------------------------------------------------------
Head "1. winget (Windows' package manager)"
$winget = Get-Command winget -ErrorAction SilentlyContinue
if ($winget) { Good "winget present" }
else {
    Bad "winget not found."
    Info "It ships with Windows 10/11 as 'App Installer'. Install it from the Microsoft"
    Info "Store, or install Python and ffmpeg by hand:"
    Info "   https://www.python.org/downloads/    https://www.gyan.dev/ffmpeg/builds/"
}

# --- 2. Python ---------------------------------------------------------------
Head "2. Python 3.12+"
$py = Find-Python
if ($py) {
    Good "$($py.VersionText)"
    Info "using: $($py.Display)"
} elseif ($winget) {
    if (Confirm-Step "winget install -e --id Python.Python.3.12") {
        winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
        $didSomething = $true
        Warn "Python was just installed - CLOSE THIS WINDOW and run setup again"
        Warn "so the new PATH is picked up."
        Read-Host "  press Enter to exit"; exit 0
    }
} else { Bad "Install Python 3.12 from python.org, ticking 'Add python.exe to PATH'." }

# --- 3. ffmpeg ---------------------------------------------------------------
Head "3. ffmpeg (does the recording)"
$ff = (Get-Command ffmpeg -ErrorAction SilentlyContinue).Source
if (-not $ff) {
    $cand = "$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe"
    if (Test-Path $cand) { $ff = $cand }
}
if ($ff) { Good "ffmpeg present" }
elseif ($winget) {
    if (Confirm-Step "winget install -e --id Gyan.FFmpeg") {
        winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
        $didSomething = $true
        Good "ffmpeg installed (a new console window will see it on PATH)"
    }
} else { Bad "Install ffmpeg and put it on PATH." }

# --- 4. faster-whisper -------------------------------------------------------
Head "4. faster-whisper (does the transcribing)"
# -RequireModule makes Find-Python settle on the interpreter that already HAS
# faster-whisper if one does -- the same interpreter Transcribe-Session.ps1 and
# the studio will pick. If none has it, we get the best interpreter back with
# .ModuleMissing set, and pip installs into exactly that one.
$py = Find-Python -RequireModule faster_whisper
if (-not $py) { Bad "Skipping - no Python yet. Re-run setup after installing it." }
elseif (-not $py.ModuleMissing) {
    $have = Get-QuillPythonVersionText $py "faster_whisper"
    if (-not $have) { $have = "present" }
    Good "faster-whisper $have"
    Info "in: $($py.Display)"
} elseif (Confirm-Step "$($py.Display) -m pip install --upgrade faster-whisper") {
    Invoke-Python $py @("-m", "pip", "install", "--upgrade", "faster-whisper")
    $didSomething = $true
    if ($LASTEXITCODE -eq 0) { Good "faster-whisper installed into $($py.Display)" } else { Bad "pip failed - see above" }
}

# --- 5. GPU (optional) -------------------------------------------------------
Head "5. GPU acceleration (optional)"
if (-not $py) { Warn "skipped - no Python" }
else {
    $cuda = (Invoke-Python $py @("-c", "import ctranslate2;print(ctranslate2.get_cuda_device_count())") 2>&1 | Out-String).Trim()
    if ($cuda -match "^\d+$" -and [int]$cuda -gt 0) {
        Good "CUDA already working - $cuda device(s). A 6h session takes minutes."
    } elseif ($Gpu) {
        if (Confirm-Step "$($py.Display) -m pip install nvidia-cublas-cu12 nvidia-cudnn-cu12") {
            Invoke-Python $py @("-m", "pip", "install", "nvidia-cublas-cu12", "nvidia-cudnn-cu12")
            $didSomething = $true
        }
    } else {
        Warn "no CUDA detected. CPU works fine, just slower."
        Info "If this machine has an NVIDIA card, re-run with  -Gpu  to add the runtime libs."
    }
}

# --- 6. the speech model (optional) ------------------------------------------
Head "6. The speech model"
$hf = Join-Path $env:USERPROFILE ".cache\huggingface\hub"
$have = (Test-Path $hf) -and (Get-ChildItem $hf -Directory -ErrorAction SilentlyContinue |
         Where-Object { $_.Name -match "whisper" })
if ($have) { Good "a Whisper model is cached - transcription is fully offline from here" }
elseif ($Model -and $py) {
    if (Confirm-Step "download small.en now (~500 MB, once)") {
        Invoke-Python $py @("-c", "from faster_whisper import WhisperModel; WhisperModel('small.en')")
        $didSomething = $true
        Good "model cached - the Quill now works with no internet at all"
    }
} else {
    Warn "not downloaded yet. The FIRST transcription will fetch it (~500 MB, once)."
    Info "To get it now, while you have wifi, re-run with  -Model"
}

# --- 7. verify ---------------------------------------------------------------
Head "7. Checking the whole chain"
$doc = Join-Path $here "Quill-Doctor.ps1"
if (Test-Path $doc) { & $doc } else { Bad "Quill-Doctor.ps1 is missing - can't verify." }

Write-Host ""
if ($DryRun) { Write-Host "  DRY RUN complete - nothing was changed." -ForegroundColor Yellow }
elseif ($didSomething) { Write-Host "  Setup done. If anything still reads FAIL, close this window and run setup again." -ForegroundColor Green }
else { Write-Host "  Nothing needed installing - this machine was already ready." -ForegroundColor Green }
Write-Host "  Start the Quill with 'The Quill.bat', or the web studio with 'Gnashers Quill Web.bat'."
Write-Host ""
# Only pause when a human is actually watching. Piped or captured (or called
# from Setup-Quill.ps1) this throws in NonInteractive mode.
# Pause only when a human is actually at the console. IsInputRedirected is the
# reliable signal: piped, captured, or launched from Setup-Quill.ps1 it is true,
# and Read-Host would either throw or hang forever waiting on a stdin nobody owns.
if (-not [Console]::IsInputRedirected) {
    try { Read-Host "  press Enter to close" | Out-Null } catch { }
}
