#!/usr/bin/env bash
# SPDX-License-Identifier: MIT
# Double-clickable launcher for macOS. Opens the web studio.
cd "$(dirname "$0")" && exec ./quill studio
