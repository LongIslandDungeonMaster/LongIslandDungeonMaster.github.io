# SPDX-License-Identifier: MIT
# quill_python.ps1 -- THE one place Gnasher's Quill decides which Python to run.
#
# WHY THIS FILE EXISTS
#   There used to be five copies of "find Python", in three different priority
#   orders. Setup installed faster-whisper with `py -3` (the newest interpreter)
#   while the transcriber and the studio preferred a hardcoded Python312 path.
#   On a machine with both, setup succeeded, the Doctor said "OK faster-whisper",
#   and transcription still died with "faster-whisper not installed" -- because
#   three different pythons were being used. One list, one order, one file.
#
# HOW YOU USE IT
#   . "$PSScriptRoot\quill_python.ps1"                 # dot-source it
#   $py = Find-Python                                  # best interpreter, or $null
#   $py = Find-Python -RequireModule faster_whisper    # prefer one that HAS the module
#   Invoke-Python $py @("transcribe.py", "--model", "small.en")
#
#   $py is an object, not a string, because the answer may be two tokens
#   (`py.exe -3`) or a path with spaces in it. Never build a command line by
#   gluing it together -- always go through Invoke-Python, which splats.
#
#   Fields on $py:  .Exe .Args .Display .Version .VersionMajor .VersionMinor
#                   .ModuleMissing .RequiredModule
#   .ModuleMissing is the difference between "no Python" and "Python is fine but
#   faster-whisper isn't installed in it" -- two problems with two different fixes.
#
# IT CAN ALSO LAUNCH SOMETHING (for .bat files, which cannot dot-source):
#   powershell -NoProfile -ExecutionPolicy Bypass -File quill_python.ps1 `
#              -Run "quill_server.py" -RequireModule faster_whisper
#
# THE RULES, in order:
#   1. .venv\Scripts\python.exe next to these scripts, if there is one
#   2. py -3          (the launcher; always resolves the newest real install)
#   3. python
#   4. python3
#   5. %LOCALAPPDATA%\Programs\Python\Python3*\python.exe, newest version first
#      (a GLOB -- never a hardcoded 3.12, which is how this broke before)
# and a candidate is REJECTED if any of these is true:
#   * `--version` exits nonzero or prints nothing (gate on the EXIT CODE, not on
#     whether some string came back)
#   * it is older than Python 3.9
#
# ABOUT \WindowsApps\ -- read this before "fixing" it:
#   On a clean Windows 11 the py.exe / python.exe / python3.exe under
#   %LOCALAPPDATA%\Microsoft\WindowsApps are 0-byte Microsoft Store "App
#   execution aliases". Get-Command FINDS them and they look real; running one
#   opens the Store and returns nonzero. That is the bug that made the Quill
#   pick a shop instead of an interpreter.
#   BUT a 0-byte alias there is ALSO how a genuinely installed Store / Python
#   Install Manager build is exposed -- measured on this very machine, the
#   WindowsApps py.exe is 0 bytes and resolves to a working Python 3.14. Size
#   and path cannot tell the two apart. RUNNING IT CAN.
#   So: a WindowsApps candidate is DEMOTED to last resort (a real install always
#   wins), and it only survives at all if it passes the exit-code + version
#   probe. The placeholder stub fails that probe and is dropped; a real Store
#   Python is still better than telling the DM "no Python found".
#
# Deliberately ASCII-only and dependency-free: it has to run on a machine where
# nothing is installed yet, under Windows PowerShell 5.1, with no BOM worries.

param(
    [string]   $Run,             # optional: run this script and exit with its code
    [string[]] $RunArgs = @(),   # arguments for -Run
    [string]   $RequireModule    # optional: prefer an interpreter that can import this
)

# Captured at dot-source time so the functions keep working no matter what the
# caller's current directory is.
if ($PSScriptRoot) { $script:QuillPyRoot = $PSScriptRoot }
elseif ($MyInvocation.MyCommand.Path) { $script:QuillPyRoot = Split-Path -Parent $MyInvocation.MyCommand.Path }
else { $script:QuillPyRoot = (Get-Location).Path }

$script:QuillPyCache = @{}
$script:QuillPythonModuleMissing = $false


function Test-QuillStoreStub {
    # Is this the Microsoft Store "App execution alias" path? Applies to py.exe,
    # python.exe AND python3.exe -- the old code only guarded `python`, which is
    # how `py` walked straight into the Store.
    # True here means "demote and prove it works", not "it is definitely fake" --
    # see the long note at the top of this file.
    param([string]$Path)
    if (-not $Path) { return $true }
    return ($Path -like '*\WindowsApps\*')
}


function Get-QuillPythonInfo {
    # Probe one candidate. Returns an interpreter object, or $null if it is not
    # a usable Python. This is where the exit-code and version gates live.
    param([string]$Exe, [string[]]$PyArgs = @())

    if (-not $Exe) { return $null }
    $probe = @($PyArgs) + @('--version')
    $raw   = $null
    $code  = $null
    $prev  = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    try {
        $raw  = (& $Exe @probe 2>&1 | Out-String)
        $code = $LASTEXITCODE
    } catch {
        return $null
    } finally {
        $ErrorActionPreference = $prev
    }

    if ($code -ne 0) { return $null }                       # the Store stub's tell
    if (-not $raw -or -not $raw.Trim()) { return $null }

    $m = [regex]::Match($raw, 'Python\s+(\d+)\.(\d+)')
    if (-not $m.Success) { return $null }
    $maj = [int]$m.Groups[1].Value
    $min = [int]$m.Groups[2].Value
    if ($maj -lt 3 -or ($maj -eq 3 -and $min -lt 9)) { return $null }

    $display = $Exe
    if ($PyArgs -and $PyArgs.Count -gt 0) { $display = "$Exe " + ($PyArgs -join ' ') }

    return [pscustomobject]@{
        Exe            = $Exe
        Args           = @($PyArgs)
        Display        = $display
        Version        = ("{0}.{1}" -f $maj, $min)
        VersionText    = $m.Value.Trim()
        VersionMajor   = $maj
        VersionMinor   = $min
        ModuleMissing  = $false
        RequiredModule = $null
    }
}


function Get-QuillPythonCandidates {
    # The one true order. Everything else in the Quill reads it from here.
    $root = $script:QuillPyRoot
    if (-not $root) { $root = (Get-Location).Path }
    # Each entry carries a Demoted flag; WindowsApps aliases are moved to the
    # back at the end, so a real install always wins.
    $list = @()

    # 1. a virtualenv sitting next to the scripts
    $venv = Join-Path $root ".venv\Scripts\python.exe"
    if (Test-Path $venv) { $list += ,@{ Exe = $venv; Args = @(); Demoted = (Test-QuillStoreStub $venv) } }

    # 2. the py launcher
    foreach ($c in @(Get-Command py -CommandType Application -ErrorAction SilentlyContinue)) {
        if ($c.Source) { $list += ,@{ Exe = $c.Source; Args = @('-3'); Demoted = (Test-QuillStoreStub $c.Source) } }
    }

    # 3 + 4. python, then python3 (-All: a real one may sit behind a Store alias)
    foreach ($name in @('python', 'python3')) {
        foreach ($c in @(Get-Command $name -CommandType Application -All -ErrorAction SilentlyContinue)) {
            if ($c.Source) { $list += ,@{ Exe = $c.Source; Args = @(); Demoted = (Test-QuillStoreStub $c.Source) } }
        }
    }

    # 5. every per-user install, newest first -- found by GLOB, never hardcoded.
    #    Two layouts: the classic python.org one, and the newer Python Install
    #    Manager one (pythoncore-3.14-64), which is what a Store install really is.
    $globs = @()
    if ($env:LOCALAPPDATA) {
        $globs += ,@{ Base = (Join-Path $env:LOCALAPPDATA "Programs\Python"); Filter = "Python3*";      Rx = '^Python(\d)(\d+)' }
        $globs += ,@{ Base = (Join-Path $env:LOCALAPPDATA "Python");          Filter = "pythoncore-3*"; Rx = '^pythoncore-(\d+)\.(\d+)' }
    }
    foreach ($g in $globs) {
        if (-not (Test-Path $g.Base)) { continue }
        $ranked = @()
        foreach ($d in @(Get-ChildItem $g.Base -Directory -Filter $g.Filter -ErrorAction SilentlyContinue)) {
            $exe = Join-Path $d.FullName "python.exe"
            if (-not (Test-Path $exe)) { continue }
            $rank = 0
            $mm = [regex]::Match($d.Name, $g.Rx)
            if ($mm.Success) { $rank = ([int]$mm.Groups[1].Value * 1000) + [int]$mm.Groups[2].Value }
            $ranked += ,([pscustomobject]@{ Exe = $exe; Rank = $rank })
        }
        foreach ($r in @($ranked | Sort-Object -Property Rank -Descending)) {
            $list += ,@{ Exe = $r.Exe; Args = @(); Demoted = (Test-QuillStoreStub $r.Exe) }
        }
    }

    # real installs first, Store aliases last -- order preserved within each half
    $ordered = @($list | Where-Object { -not $_.Demoted }) + @($list | Where-Object { $_.Demoted })

    # de-duplicate, keeping first-seen order
    $seen = @{}
    $out  = @()
    foreach ($c in $ordered) {
        $key = ($c.Exe + '|' + ($c.Args -join ' ')).ToLowerInvariant()
        if (-not $seen.ContainsKey($key)) { $seen[$key] = $true; $out += ,$c }
    }
    return $out
}


function Test-QuillPythonModule {
    # Can THIS interpreter import that module? Exit code, nothing else.
    param($Py, [string]$Module)
    if (-not $Py -or -not $Module) { return $false }
    if ($Module -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') { return $false }

    $a    = @($Py.Args) + @('-c', "import $Module")
    $code = $null
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    try {
        (& $Py.Exe @a 2>&1) | Out-Null
        $code = $LASTEXITCODE
    } catch {
        return $false
    } finally {
        $ErrorActionPreference = $prev
    }
    return ($code -eq 0)
}


function Get-QuillPythonVersionText {
    # Same probe, but asked of an interpreter object (handy for reporting).
    param($Py, [string]$Module)
    if (-not $Py -or -not $Module) { return $null }
    if ($Module -notmatch '^[A-Za-z_][A-Za-z0-9_]*$') { return $null }
    $a    = @($Py.Args) + @('-c', "import $Module,sys; sys.stdout.write(getattr($Module,'__version__','?'))")
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'SilentlyContinue'
    try {
        $out  = (& $Py.Exe @a 2>&1 | Out-String)
        $code = $LASTEXITCODE
    } catch {
        return $null
    } finally {
        $ErrorActionPreference = $prev
    }
    if ($code -ne 0) { return $null }
    if (-not $out) { return $null }
    return $out.Trim()
}


function Find-Python {
    <#
      Returns the interpreter to run, or $null if this machine has no usable
      Python at all.

      -RequireModule <name> prefers the first candidate that can actually import
      <name>. If NONE of them can, it still returns the best interpreter, with
      .ModuleMissing = $true -- so the caller can say "Python is fine, the module
      isn't installed in it" instead of the lie "Python not found".
    #>
    param([string]$RequireModule)

    if ($null -eq $script:QuillPyCache) { $script:QuillPyCache = @{} }
    $key = 'py|' + $RequireModule
    if ($script:QuillPyCache.ContainsKey($key)) { return $script:QuillPyCache[$key] }

    $best = $null
    foreach ($c in @(Get-QuillPythonCandidates)) {
        $info = Get-QuillPythonInfo -Exe $c.Exe -PyArgs $c.Args
        if (-not $info) { continue }
        if (-not $best) { $best = $info }
        if (-not $RequireModule) { break }
        if (Test-QuillPythonModule $info $RequireModule) {
            $info.RequiredModule = $RequireModule
            $info.ModuleMissing  = $false
            $script:QuillPythonModuleMissing = $false
            $script:QuillPyCache[$key] = $info
            return $info
        }
    }

    if ($best -and $RequireModule) {
        $best.RequiredModule = $RequireModule
        $best.ModuleMissing  = $true
    }
    $script:QuillPythonModuleMissing = [bool]($best -and $RequireModule)
    $script:QuillPyCache[$key] = $best
    return $best
}


function Invoke-Python {
    <#
      The ONLY safe way to run it. $Py.Exe may be a path with spaces and $Py.Args
      may add tokens of its own (`-3`), so both halves are splatted as an argument
      array -- never concatenated into a string and re-parsed.

          Invoke-Python $py @("transcribe.py", "--model", "small.en")
    #>
    param(
        [Parameter(Mandatory = $true, Position = 0)] $Py,
        [Parameter(Position = 1)] [string[]] $Arguments = @()
    )
    if (-not $Py) { throw "Invoke-Python: no Python interpreter (Find-Python returned nothing)." }
    $all = @($Py.Args) + @($Arguments)
    & $Py.Exe @all
}


function Write-QuillNoPython {
    # One wording for the one problem, everywhere.
    Write-Host ""
    Write-Host "  No usable Python was found on this machine." -ForegroundColor Red
    Write-Host "  Install Python 3.12 from https://www.python.org/downloads/ and TICK" -ForegroundColor Gray
    Write-Host "  'Add python.exe to PATH', then run 'SETUP (run me first).bat' again." -ForegroundColor Gray
    Write-Host "  (If Windows opens the Microsoft Store when you type python, that is" -ForegroundColor DarkGray
    Write-Host "   the placeholder stub, not Python. Install the real one.)" -ForegroundColor DarkGray
    Write-Host ""
}


# --- launcher mode, for .bat files that cannot dot-source PowerShell ----------
if ($Run) {
    $target = $Run
    if (-not [System.IO.Path]::IsPathRooted($target)) { $target = Join-Path $script:QuillPyRoot $target }
    if (-not (Test-Path $target)) {
        Write-Host ""
        Write-Host "  Can't find $Run" -ForegroundColor Red
        Write-Host "  Keep the whole Quill folder together." -ForegroundColor Gray
        Write-Host ""
        exit 1
    }
    $py = Find-Python -RequireModule $RequireModule
    if (-not $py) { Write-QuillNoPython; exit 1 }
    if ($py.ModuleMissing) {
        Write-Host ""
        Write-Host "  Python is fine ($($py.Display)) but '$($py.RequiredModule)' is not installed in it." -ForegroundColor Yellow
        Write-Host "  Recording still works. Transcribing will not until you run" -ForegroundColor Gray
        Write-Host "  'SETUP (run me first).bat'." -ForegroundColor Gray
        Write-Host ""
    }
    Invoke-Python $py (@($target) + @($RunArgs))
    if ($null -eq $LASTEXITCODE) { exit 0 }
    exit $LASTEXITCODE
}
