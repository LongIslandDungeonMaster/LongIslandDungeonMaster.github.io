# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT
"""
Quill-Concordance — a who's-who of your campaign that writes itself.

One session's digest tells you what came up that night. This reads EVERY session you
have and answers the questions that only make sense across a campaign:

    "Who is Talia, and when did we first meet her?"
    "Which nights does the the Salt Compact show up in?"
    "Did we ever actually follow up on Vethric?"

    python Quill-Concordance.py                  # build/refresh CONCORDANCE.md
    python Quill-Concordance.py --find Corrin  # every mention, every session
    python Quill-Concordance.py --find "silk debt" --context 2

This is the piece that makes the Quill worth more the longer you use it: session ten
is more useful than session one, because it knows about the first nine.

Nothing here needs a network or a model.
"""
import os
import re
import sys
import argparse
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from quill_lib import (HERE, hms, load_segments, load_lexicon, lexicon_regex,
                       canon_roots_from_flag, notes_found,
                       pick_transcripts, session_name, name_candidates,
                       canon_index, canon_hits, in_fiction)

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def gather(files, lexicon):
    """-> {name: {sessions:{sid:count}, first:(sid,t,line), total:int}}"""
    index = defaultdict(lambda: {"sessions": defaultdict(int), "first": None, "total": 0})
    order = []
    for f in files:
        sid = session_name(f)
        order.append(sid)
        _head, segs = load_segments(f)
        if not segs:
            continue
        singles, phrases, ctx = name_candidates(segs, known=[])
        merged = dict(singles)
        for p, n in phrases.items():
            merged[p] = max(merged.get(p, 0), n)
        # drop single words that are just a piece of a phrase we already have
        parts = {w for k in merged if " " in k for w in k.split()}
        merged = {k: v for k, v in merged.items() if " " in k or k not in parts}

        for name, n in merged.items():
            e = index[name]
            e["sessions"][sid] += n
            e["total"] += n
            if e["first"] is None:
                t, line = ctx.get(name, (0, ""))
                e["first"] = (sid, t, line)
    return index, order


def find(files, term, context):
    rx = re.compile(r"\b" + re.escape(term) + r"\b", re.I)
    hits = 0
    for f in files:
        _h, segs = load_segments(f)
        sid = session_name(f)
        shown = False
        for i, (a, _b, text) in enumerate(segs):
            if not rx.search(text):
                continue
            if not shown:
                print(f"\n=== {sid} ===")
                shown = True
            hits += 1
            lo = max(0, i - context)
            hi = min(len(segs), i + context + 1)
            for j in range(lo, hi):
                mark = ">>" if j == i else "  "
                print(f" {mark} [{hms(segs[j][0])}] {segs[j][2]}")
            if context:
                print()
    print(f"\n{hits} mention(s) of \"{term}\" across {len(files)} session(s).")
    return 0 if hits else 1


def main():
    ap = argparse.ArgumentParser(description="Cross-session who's-who and search.")
    ap.add_argument("--transcripts", default=os.path.join(HERE, "transcripts"))
    # No fixed default: see the note in Quill-Ledger.py. A ledger/concordance
    # must land beside the transcripts it was built from, or aiming the tool at
    # a second campaign quietly overwrites the first one's file.
    ap.add_argument("--out", default=None,
                    help="default: CONCORDANCE.md beside the --transcripts folder")
    ap.add_argument("--find", default=None, metavar="TERM", help="search every session instead")
    ap.add_argument("--context", type=int, default=1, help="lines either side of a --find hit")
    ap.add_argument("--min-said", type=int, default=2, help="ignore names said fewer times overall")
    ap.add_argument("--canon", default=None,
                    help='campaign-note folders, to mark names as written down. "" to skip.')
    a = ap.parse_args()
    if a.out is None:
        a.out = os.path.join(os.path.dirname(os.path.abspath(a.transcripts)),
                             "CONCORDANCE.md")

    files = pick_transcripts(a.transcripts)
    if not files:
        print("no transcripts found.")
        return 1

    if a.find:
        return find(files, a.find, a.context)

    lexicon = load_lexicon()
    index, order = gather(files, lexicon)

    roots = canon_roots_from_flag(a.canon)
    canon = canon_index(roots) if roots else None
    searched = notes_found(roots) if roots else []

    lex_lower = {n.lower() for n in lexicon}
    rows = []
    for name, e in index.items():
        if e["total"] < a.min_said:
            continue
        written = bool(canon) and canon_hits(name, canon) >= 3
        rows.append((name, e, written, name.lower() in lex_lower))
    rows.sort(key=lambda r: (-len(r[1]["sessions"]), -r[1]["total"], r[0].lower()))

    L = []
    L.append("# CONCORDANCE — who and what this campaign has said out loud")
    L.append("")
    L.append("> Built by `Quill-Concordance.py` from every transcript in `transcripts\\`.")
    L.append("> Names are ranked by how many separate nights they survived — a name that")
    L.append("> keeps coming back matters more than one said ten times in one scene.")
    L.append(">")
    # With no notes to search, `written` is False for everything -- so the old
    # header labelled every name in the campaign "recorded nowhere else", which
    # is a claim about files that were never opened. Say which question was
    # actually answered.
    if searched:
        L.append("> **written** = already in your campaign notes.  **UNWRITTEN** = said at the")
        L.append("> table and recorded nowhere else. Those are the ones you lose.")
        L.append(">")
        L.append("> *Notes searched: " + ", ".join(f"`{os.path.basename(r)}`" for r in searched) + "*")
    else:
        L.append("> **No campaign notes were searched**, so this cannot tell *already written")
        L.append("> down* from *new at the table* — every name below is simply a name your")
        L.append("> table said. Put your notes folder in `NOTES.txt` (or set it in the web")
        L.append("> studio) and the written/UNWRITTEN split starts working.")
    L.append("")
    L.append(f"*{len(rows)} names across {len(order)} session(s), last built from:*")
    for sid in order:
        L.append(f"- `{sid}`")
    L.append("")

    recurring = [r for r in rows if len(r[1]["sessions"]) > 1]
    if recurring:
        L.append("## Recurring — said on more than one night")
        L.append("")
        L.append("| name | nights | said | first heard | written down? |")
        L.append("|---|---|---|---|---|")
        for name, e, written, inlex in recurring:
            sid, t, _line = e["first"]
            mark = ("written" if written else "**UNWRITTEN**") if searched else "not checked"
            L.append(f"| **{name}** | {len(e['sessions'])} | {e['total']} | "
                     f"`{sid}` @ {hms(t)} | {mark} |")
        L.append("")

    L.append("## Everything, by name")
    L.append("")
    for name, e, written, inlex in sorted(rows, key=lambda r: r[0].lower()):
        sid, t, line = e["first"]
        tag = ("written" if written else "UNWRITTEN") if searched else "notes not searched"
        lex = " · in lexicon" if inlex else " · **not in lexicon**"
        L.append(f"### {name}")
        L.append(f"*{e['total']} mention(s) over {len(e['sessions'])} night(s) · {tag}{lex}*")
        L.append("")
        L.append(f"First heard `{sid}` @ **{hms(t)}**:")
        L.append(f"> {line[:300]}")
        L.append("")
        L.append("Nights: " + ", ".join(f"`{s}` ({n})" for s, n in
                                        sorted(e["sessions"].items())))
        L.append("")

    open(a.out, "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"{len(rows)} names across {len(order)} session(s)")
    print(f"  recurring across nights : {len(recurring)}")
    if searched:
        print(f"  unwritten (at risk)     : {sum(1 for r in rows if not r[2])}")
    else:
        print("  written vs new          : not checked (no notes folder — see NOTES.txt)")
    print(f"\n-> {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
