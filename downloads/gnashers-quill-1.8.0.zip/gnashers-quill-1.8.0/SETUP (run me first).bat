@echo off
title Gnasher's Quill - Setup
REM ============================================================
REM  DOUBLE-CLICK THIS FIRST, on any new machine.
REM
REM  It installs the three things the Quill needs (Python, ffmpeg,
REM  faster-whisper), skips anything already there, and finishes by
REM  running the pre-game check so you can see it worked.
REM
REM  -ExecutionPolicy Bypass is here because Windows blocks unsigned
REM  PowerShell scripts by default. It applies to THIS run only and
REM  changes nothing on your machine.
REM ============================================================

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Quill.ps1"

echo.
pause
