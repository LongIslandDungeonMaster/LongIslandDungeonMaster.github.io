Your transcripts land here. Nothing in this folder ships.
