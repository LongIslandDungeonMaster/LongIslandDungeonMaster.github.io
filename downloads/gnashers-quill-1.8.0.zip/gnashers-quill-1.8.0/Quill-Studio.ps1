﻿# SPDX-License-Identifier: MIT
<#
    Quill-Studio.ps1  --  one-window control panel for capturing & transcribing
    a live table session, for ANY campaign. Driven by "The Quill.bat" (double-click that).

    Gnasher's Quill. The Quill records. The Grimoire holds. The Satchel carries.

    Record -> lands in recordings\ ; press M mid-game to mark a moment ;
    Transcribe -> lands in transcripts\ (campaign names spelled right via lexicon.txt).
    Everything is local, offline, and free.

    NOTE: this file contains box-drawing + block glyphs and MUST stay UTF-8 with BOM,
    or Windows PowerShell 5.1 will mojibake the art. (Re-save with a BOM if you edit it.)
#>

$ErrorActionPreference = "Continue"
$here        = $PSScriptRoot
$recordings  = Join-Path $here "recordings"
$transcripts = Join-Path $here "transcripts"
$transcriber = Join-Path $here "Transcribe-Session.ps1"
$sessionLog  = Join-Path $here "SESSION-LOG.md"
foreach ($d in @($recordings,$transcripts)) { if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null } }

# --- ANSI truecolor ----------------------------------------------------------
$ESC = [char]27
function Enable-VT {
    # Turn on virtual-terminal processing so 24-bit color renders (Win10+; default
    # on in Win11, but we force it so the art never leaks raw escape codes).
    try {
        if (-not ("QuillVT" -as [type])) {
            Add-Type -Namespace Quill -Name VT -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern System.IntPtr GetStdHandle(int h);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool GetConsoleMode(System.IntPtr h, out uint m);
[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern bool SetConsoleMode(System.IntPtr h, uint m);
'@ -ErrorAction SilentlyContinue
        }
        $h = [Quill.VT]::GetStdHandle(-11); $m = 0
        if ([Quill.VT]::GetConsoleMode($h, [ref]$m)) { [void][Quill.VT]::SetConsoleMode($h, $m -bor 0x0004) }
    } catch { }
}
Enable-VT

function TC {
    param([string]$rgb, [string]$text, [switch]$NoNewline)
    $s = "$ESC[38;2;${rgb}m$text$ESC[0m"
    if ($NoNewline) { Write-Host $s -NoNewline } else { Write-Host $s }
}

# palette
$C_GOLD  = "255;205;90"
$C_AMBER = "255;160;50"
$C_EMBER = "205;90;25"
$C_PARCH = "214;188;140"
$C_DIM   = "150;132;96"
$C_INK   = "224;214;188"

function Box {
    param([string[]]$lines, [ConsoleColor]$color = [ConsoleColor]::Yellow, [int]$w = 60)
    Write-Host ("   " + [char]0x256D + ([string][char]0x2500 * $w) + [char]0x256E) -ForegroundColor $color
    foreach ($l in $lines) {
        if ($l -eq "") { Write-Host ("   " + [char]0x2502 + (" " * $w) + [char]0x2502) -ForegroundColor $color }
        else { Write-Host ("   " + [char]0x2502 + "  " + $l.PadRight($w - 2) + [char]0x2502) -ForegroundColor $color }
    }
    Write-Host ("   " + [char]0x2570 + ([string][char]0x2500 * $w) + [char]0x256F) -ForegroundColor $color
}

# --- locate ffmpeg -----------------------------------------------------------
function Get-Ffmpeg {
    $c = Get-Command ffmpeg -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $cands = @("$env:LOCALAPPDATA\Microsoft\WinGet\Links\ffmpeg.exe")
    $cands += (Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Filter ffmpeg.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -Expand FullName)
    return ($cands | Where-Object { Test-Path $_ } | Select-Object -First 1)
}
$ffmpeg = Get-Ffmpeg

# --- find the default microphone at run time (resilient to hardware changes) --
function Get-Mic {
    param($ff)
    if (-not $ff) { return $null }
    $lines = & $ff -hide_banner -list_devices true -f dshow -i dummy 2>&1
    foreach ($ln in $lines) {
        $m = [regex]::Match($ln, '"([^"]+)"\s*\(audio\)')
        if ($m.Success) { return $m.Groups[1].Value }
    }
    return $null
}
# Sniffed once at boot for the hearth line under the banner; Record still
# re-sniffs live, so a mic swapped mid-evening is still found.
$script:bootMic = Get-Mic $ffmpeg

# --- flavor ------------------------------------------------------------------
$TableWisdom = @(
    "Say names out loud at big moments -- the transcript gets sharper."
    "Press M while recording to pin a moment worth finding later."
    "Fast model for a quiet room; high accuracy for a rowdy table."
    "Label every session -- future-you is a forgetful archivist."
    "The lexicon spells your NPCs right. Feed it new names as they appear."
    "A marked moment is a found moment."
    "Raw transcripts are backups. The recap is the craft."
    "The dice remember nothing. The Quill remembers everything."
)
$Farewells = @(
    "The candles gutter. The tale keeps."
    "Ink dries. Legends don't."
    "The tavern empties. Roll well, Dungeon Master."
    "Somewhere, a d20 is already rolling."
    "The Quill sleeps. The Grimoire remembers."
)

# --- the hearth line: will tonight work? --------------------------------------
# One glance under the banner answers the 7pm question before it becomes the
# 7pm crisis. Mic + ffmpeg are sniffed once at boot; the scroll count stays live.
function Hearth {
    if (-not (Test-Path variable:script:bootPy)) { $script:bootPy = Find-Python }
    $n  = (Get-ChildItem $transcripts -Filter *.txt -ErrorAction SilentlyContinue | Measure-Object).Count
    $ok = "120;205;95"; $bad = "235;70;60"
    $mic = $script:bootMic
    if ($mic -and $mic.Length -gt 26) { $mic = $mic.Substring(0, 24) + ".." }
    Write-Host "          " -NoNewline
    if ($ffmpeg) { TC $ok "ffmpeg ✓" -NoNewline } else { TC $bad "ffmpeg ✗" -NoNewline }
    Write-Host "   " -NoNewline
    if ($mic)    { TC $ok ("mic ✓ " + $mic) -NoNewline } else { TC $bad "mic ✗ none heard" -NoNewline }
    Write-Host "   " -NoNewline
    if ($script:bootPy) { TC $ok "python ✓" -NoNewline } else { TC $bad "python ✗" -NoNewline }
    Write-Host "   " -NoNewline
    TC $C_PARCH ("scrolls " + $n)
}

# --- the title page ----------------------------------------------------------
function Banner {
    $rows = @(
        " ██████  ██    ██ ██ ██      ██     "
        "██    ██ ██    ██ ██ ██      ██     "
        "██    ██ ██    ██ ██ ██      ██     "
        "██ ▄▄ ██ ██    ██ ██ ██      ██     "
        " ██████   ██████  ██ ███████ ███████"
        "    ▀▀                              "
    )
    $grad = @("255;223;96","255;198;66","250;168;44","240;138;28","222;108;22","198;84;20")
    $feather = @("", "  ✦", " ╱", "╱", "", "")   # a little quill leaning over the word
    Write-Host ""
    TC $C_GOLD "     ✦ ══════════════════════════════════════════════ ✦"
    Write-Host ""
    TC "180;150;90" "                   G  N  A  S  H  E  R  ' S"
    Write-Host ""
    for ($i = 0; $i -lt 6; $i++) { TC $grad[$i] ("      " + $rows[$i] + $feather[$i]) }
    Write-Host ""
    TC $C_DIM  "                record  ·  transcribe  ·  remember"
    TC $C_DIM  "     the Quill records → the Grimoire holds → the Satchel carries"
    Write-Host ""
    Hearth
    Write-Host ""
    TC $C_GOLD "     ✦ ══════════════════════════════════════════════ ✦"
    Write-Host ""
}

function Header { Clear-Host; Banner }
function Pause2 { Write-Host ""; Read-Host "   -- press Enter to return to the studio --" | Out-Null }

# --- record (with live moment-marking + a faux VU meter) ---------------------
function Record {
    Header
    if (-not $ffmpeg) { Write-Host "   ffmpeg not found. Can't record here." -ForegroundColor Red; Pause2; return }
    $mic = Get-Mic $ffmpeg
    if (-not $mic) { Write-Host "   No microphone detected. Plug one in and retry." -ForegroundColor Red; Pause2; return }

    # a candle, lit
    TC "255;240;150" "                    ."
    TC "255;214;84"  "                   (o)"
    TC "255;150;45"  "                   )#("
    TC "232;120;34"  "                   |#|"
    TC $C_GOLD       "                  ====="
    TC $C_GOLD       "                  |   |"
    TC "184;142;72"  "                  ====="
    Write-Host ""
    Write-Host "   Microphone: " -NoNewline; Write-Host $mic -ForegroundColor Cyan
    $topic = Read-Host "   Label this session -- campaign + what happens (e.g. saltmere-shackles-riot), or Enter to skip"
    $stamp = Get-Date -Format "yyyy-MM-dd_HHmm"
    $name  = if ($topic.Trim()) { "${stamp}_" + ($topic.Trim() -replace '[^\w\-]','-') } else { $stamp }
    $out   = Join-Path $recordings "$name.m4a"
    $markFile = Join-Path $recordings "$name.markers.txt"

    Write-Host ""
    Write-Host "   Recording to: " -NoNewline; Write-Host "recordings\$name.m4a" -ForegroundColor Green
    Write-Host ""
    Box -color Yellow -lines @(
        "● RECORDING — leave this window open through the game."
        ""
        "   [M]   pin the moment that JUST happened (+ a note)"
        "   [U]   take back the last pin - a mistap is not permanent"
        "   [Q]   stop and save the recording"
        ""
        "[M] only works while THIS window has focus. If you run the"
        "game from another app, you will not press it — the 5h58m"
        "session on 2026-07-19 ended with zero marks. Running the"
        "web studio instead puts a MARK button on your phone."
        ""
        "Q is still the clean stop, but a crash no longer costs the"
        "night — the file is written in recoverable fragments."
    )
    Write-Host ""

    # mono 16 kHz AAC: ideal for speech + whisper, tiny files (~40 MB/hour).
    # ffmpeg runs as a child process with stdin piped so we own the keyboard:
    # M drops a timestamped marker, Q sends ffmpeg its graceful-quit key.
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $ffmpeg
    # CRASH SAFETY (2026-07-30). A normal .m4a writes its index (the moov atom) at the
    # very END. Lose power at hour five of a six-hour game and you get a 44-byte file and
    # no session - measured, not theorised. These flags write the file in self-contained
    # 2-second fragments and flush as they go, so a hard kill costs you the last fragment
    # instead of the whole night. Still a .m4a, still plays, still reports its duration.
    $frag = "-movflags +frag_keyframe+empty_moov+default_base_moof -frag_duration 2000000 -flush_packets 1"
    $psi.Arguments = "-hide_banner -loglevel error -nostats -f dshow -i `"audio=$mic`" -ac 1 -ar 16000 -c:a aac -b:a 96k $frag `"$out`""
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $proc = [System.Diagnostics.Process]::Start($psi)
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $marks = @()
    $meter = [char[]]"▁▂▃▄▅▆▇█"
    $tick = 0

    while (-not $proc.HasExited) {
        if ([Console]::KeyAvailable) {
            $k = [Console]::ReadKey($true)
            if ($k.Key -eq "Q") {
                $proc.StandardInput.Write("q")
                $proc.StandardInput.Flush()
                break
            }
            elseif ($k.Key -eq "M") {
                $ts = "{0:hh\:mm\:ss}" -f $watch.Elapsed
                Write-Host ""
                TC "220;150;255" "   ✦ moment marked at $ts"
                $note = Read-Host "     note (Enter for none)"
                $entry = if ($note.Trim()) { "[$ts] $($note.Trim())" } else { "[$ts]" }
                $marks += $entry
                Add-Content -Path $markFile -Value $entry -Encoding UTF8
            }
            elseif ($k.Key -eq "U") {
                # File-authoritative, exactly like the web studio and the floating
                # marker: all three write this one file, so undo reads it back
                # rather than trusting its own count.
                $lines = @()
                if (Test-Path $markFile) {
                    $lines = @(Get-Content $markFile -Encoding UTF8 | Where-Object { $_.Trim() })
                }
                Write-Host ""
                if ($lines.Count -eq 0) {
                    TC $C_DIM "   nothing to take back"
                } else {
                    $gone = $lines[-1]
                    $keep = if ($lines.Count -gt 1) { $lines[0..($lines.Count - 2)] } else { @() }
                    Set-Content -Path $markFile -Value $keep -Encoding UTF8
                    $marks = $keep
                    TC "220;150;255" "   ⤺ took back $gone"
                }
            }
        } else {
            Start-Sleep -Milliseconds 220
        }
        $tick++
        $el  = "{0:hh\:mm\:ss}" -f $watch.Elapsed
        $dot = if ($tick % 2 -eq 0) { "●" } else { " " }
        $vu  = -join (1..20 | ForEach-Object { $meter[(Get-Random -Minimum 0 -Maximum 8)] })
        $rec  = "$ESC[38;2;235;70;60m$dot REC$ESC[0m"
        $time = "$ESC[38;2;255;205;90m$el$ESC[0m"
        $bars = "$ESC[38;2;120;205;95m$vu$ESC[0m"
        $mk   = "$ESC[38;2;220;150;255m✦ $($marks.Count)$ESC[0m"
        $keys = "$ESC[90m[M]ark  [U]ndo  [Q]stop$ESC[0m"
        Write-Host -NoNewline ("`r   $rec   $time   $bars   $mk    $keys    ")
    }

    # give ffmpeg time to finalize the .m4a (it writes the index at the end)
    if (-not $proc.WaitForExit(15000)) {
        $proc.StandardInput.Close()
        if (-not $proc.WaitForExit(5000)) {
            $proc.Kill()
            Write-Host "`n   ffmpeg had to be force-stopped - the file may be unplayable." -ForegroundColor Red
        }
    }
    $watch.Stop()

    Write-Host ""; Write-Host ""
    if ((Test-Path $out) -and ((Get-Item $out).Length -gt 10KB)) {
        $mb = [math]::Round((Get-Item $out).Length/1MB,1)
        Write-Host "   Saved: recordings\$name.m4a  ($mb MB)" -ForegroundColor Green
        if ($marks.Count -gt 0) {
            TC "220;150;255" "   $($marks.Count) marked moment(s) -> recordings\$name.markers.txt"
            Write-Host "   (They ride into the transcript header automatically.)" -ForegroundColor DarkGray
        }
        Write-Host "   Next: menu option [2] to transcribe it." -ForegroundColor Green
    } else {
        Write-Host "   Hmm - the file looks empty. Mic may be muted or blocked." -ForegroundColor Red
    }
    Pause2
}

function Transcribe {
    param([string]$Model)
    Header
    TC $C_PARCH      "         .-=========================-."
    TC $C_PARCH      "        (                           )"
    TC "232;202;150" "        (    the scribe bends        )"
    TC "232;202;150" "        (       to the work …        )"
    TC $C_PARCH      "        (                           )"
    TC $C_PARCH      "         '-=========================-'"
    Write-Host ""
    Write-Host "   Transcribing new recordings with model: " -NoNewline; Write-Host $Model -ForegroundColor Cyan
    Write-Host "   (Long sessions take a while - it runs unattended.)" -ForegroundColor DarkGray
    Write-Host ""
    & $transcriber -Model $Model
    Pause2
}

function ShowLog {
    Header
    TC "210;170;90" "           ______________"
    TC "210;170;90" "          /             /|"
    TC "210;170;90" "         /_____________/ |"
    TC "210;170;90" "        │             │  |"
    TC $C_GOLD      "        │ L E D G E R │  |"
    TC "210;170;90" "        │             │ /"
    TC "210;170;90" "        │_____________│/"
    Write-Host ""
    if (Test-Path $sessionLog) {
        Get-Content $sessionLog | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
    } else {
        Write-Host "   No sessions in the ledger yet." -ForegroundColor DarkGray
        Write-Host "   It writes itself the first time you transcribe a recording." -ForegroundColor DarkGray
    }
    Pause2
}

function HowItWorks {
    Header
    TC $C_GOLD "   THE LOOP"
    Write-Host ""
    TC $C_GOLD "   ①  RECORD" -NoNewline;     Write-Host "      leave it running; press M to pin a moment, Q to stop" -ForegroundColor Gray
    TC $C_DIM  "       │"
    TC $C_DIM  "       ▼"
    TC $C_GOLD "   ②  TRANSCRIBE" -NoNewline; Write-Host "  whisper turns the audio into text (names via lexicon.txt)" -ForegroundColor Gray
    TC $C_DIM  "       │"
    TC $C_DIM  "       ▼"
    TC $C_GOLD "   ③  THE RECAP" -NoNewline;  Write-Host "   marked moments up top, saved in transcripts\ — ready for prep" -ForegroundColor Gray
    Write-Host ""
    Write-Host "   Works for any campaign - the session label keeps them straight." -ForegroundColor Green
    Write-Host "   All local. No internet needed. No monthly fees." -ForegroundColor Green
    Write-Host "   Use [3] instead of [2] if the room was noisy - slower but sharper." -ForegroundColor DarkGray
    Pause2
}

# --- which Python? -----------------------------------------------------------
# NOT decided here. quill_python.ps1 is the single source of truth for the whole
# Quill; this file used to prefer a hardcoded Python312 while setup installed
# into `py -3`, and the two never met. Find-Python and Invoke-Python come from
# there. Find-Python returns an OBJECT (the answer can be two tokens, `py -3`),
# so every call below goes through Invoke-Python, which splats it safely.
$pyHelper = Join-Path $here "quill_python.ps1"
if (Test-Path $pyHelper) {
    . $pyHelper
} else {
    # Recording only needs ffmpeg, so the studio still opens and can capture the
    # night; only the python-backed reports go dark.
    function Find-Python { param([string]$RequireModule) return $null }
    function Invoke-Python { param($Py, [string[]]$Arguments = @()) throw "quill_python.ps1 is missing." }
}

# --- mine a transcript -------------------------------------------------------

function Digest {
    Header
    $py     = Find-Python
    $script = Join-Path $here "Mine-Transcript.py"
    if (-not $py)                  { Write-Host "   No Python found." -ForegroundColor Red; Pause2; return }
    if (-not (Test-Path $script))  { Write-Host "   Mine-Transcript.py is missing." -ForegroundColor Red; Pause2; return }

    $files = Get-ChildItem $transcripts -Filter *.txt -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    if (-not $files) { Write-Host "   No transcripts yet. Record and transcribe a session first." -ForegroundColor Yellow; Pause2; return }

    Write-Host "   Which session?" -ForegroundColor Yellow
    Write-Host ""
    $show = $files | Select-Object -First 9
    for ($i = 0; $i -lt $show.Count; $i++) {
        Write-Host ("     [{0}] {1,-52} {2}" -f ($i + 1), $show[$i].BaseName, $show[$i].LastWriteTime.ToString("yyyy-MM-dd")) -ForegroundColor Gray
    }
    Write-Host ""
    $pick = Read-Host "   Number (Enter = newest)"
    $file = if ($pick -match '^\d+$' -and [int]$pick -ge 1 -and [int]$pick -le $show.Count) { $show[[int]$pick - 1] } else { $show[0] }

    $out = Join-Path $transcripts ($file.BaseName + "_digest.md")
    Write-Host ""
    Write-Host "   Mining $($file.Name) ..." -ForegroundColor Cyan
    Write-Host ""
    Invoke-Python $py @($script, $file.FullName, "--out", $out)
    if (Test-Path $out) {
        Write-Host "   Digest written: transcripts\$(Split-Path $out -Leaf)" -ForegroundColor Green
        Write-Host ""
        Get-Content $out | Select-Object -First 20 | ForEach-Object { Write-Host "   $_" -ForegroundColor DarkGray }
        Write-Host ""
        if ((Read-Host "   Open it? (y/N)") -match '^[Yy]') { Start-Process $out }
    }
    Pause2
}

# --- campaign-wide reports ---------------------------------------------------
# One keypress rebuilds everything that reads ACROSS sessions, so the campaign view
# is never stale just because rebuilding it was four separate chores.
function Reports {
    Header
    $py = Find-Python
    if (-not $py) { Write-Host "   No Python found." -ForegroundColor Red; Pause2; return }

    TC $C_GOLD "   Reading every transcript you have..."
    Write-Host ""

    $jobs = @(
        @{ s = "Quill-Ledger.py";      t = "LEDGER      promises, debts and threats, still open"; a = @() }
        @{ s = "Quill-Concordance.py"; t = "CONCORDANCE who's-who across every night";            a = @() }
        @{ s = "Quill-Mirror.py";      t = "MIRROR      how you ran the newest session";          a = @("transcripts", "--out", "MIRROR.md") }
        @{ s = "Quill-ColdOpen.py";    t = "COLD OPEN   what to say before the players arrive";   a = @() }
    )
    foreach ($j in $jobs) {
        $script = Join-Path $here $j.s
        if (-not (Test-Path $script)) {
            Write-Host ("   -- {0}  (missing {1})" -f $j.t, $j.s) -ForegroundColor DarkGray
            continue
        }
        Write-Host ("   {0}" -f $j.t) -ForegroundColor Yellow
        Invoke-Python $py (@($script) + @($j.a)) | ForEach-Object { Write-Host "      $_" -ForegroundColor DarkGray }
        Write-Host ""
    }

    Write-Host "   Written into the Quill folder:" -ForegroundColor Green
    foreach ($f in @("LEDGER.md", "CONCORDANCE.md", "MIRROR.md", "COLD-OPEN.md")) {
        $p = Join-Path $here $f
        if (Test-Path $p) { Write-Host ("     {0,-18} {1:N0} bytes" -f $f, (Get-Item $p).Length) -ForegroundColor Gray }
    }
    Write-Host ""
    Write-Host "   LEDGER.md is yours to edit - tick a box when you've paid a debt off." -ForegroundColor DarkGray
    Write-Host "   Search any session:  python Quill-Concordance.py --find <name>" -ForegroundColor DarkGray
    Pause2
}

# --- the Chorus: merge one track per voice into one transcript ----------------
# Running a Chorus session lives in the WEB studio, because that is the server the
# phones talk to. Merging afterwards is a batch job like transcription, so it lives here.
function ChorusMerge {
    Header
    $py = Find-Python
    $script = Join-Path $here "Quill-Chorus.py"
    if (-not $py -or -not (Test-Path $script)) {
        Write-Host "   Need Python and Quill-Chorus.py." -ForegroundColor Red; Pause2; return
    }

    TC $C_GOLD "   THE CHORUS - every voice on its own track"
    Write-Host ""
    $listing = Invoke-Python $py @($script, "--list") 2>&1
    $listing | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
    if ($listing -match "no Chorus sessions") {
        Write-Host ""
        Write-Host "   To record one: start the WEB studio [W], press 'Open the Chorus'," -ForegroundColor DarkGray
        Write-Host "   then have each player open the join link on their phone." -ForegroundColor DarkGray
        Pause2; return
    }

    Write-Host ""
    $sess = Read-Host "   Session to merge (Enter = newest)"
    $model = Read-Host "   Model - [1] fast small.en  [2] accurate medium.en (Enter = 2)"
    $m = if ($model.Trim() -eq "1") { "small.en" } else { "medium.en" }

    Write-Host ""
    Write-Host "   Transcribing each voice separately, then braiding them..." -ForegroundColor Yellow
    Write-Host ""
    $args = @("--model", $m)
    if ($sess.Trim()) { $args += @("--session", $sess.Trim()) }
    Invoke-Python $py (@($script) + @($args)) | ForEach-Object { Write-Host "   $_" }
    Pause2
}

# --- rebuild the lexicon from campaign notes ---------------------------------
function Lexicon {
    Header
    $py = Find-Python
    $script = Join-Path $here "Quill-Lexicon.py"
    if (-not $py -or -not (Test-Path $script)) {
        Write-Host "   Need Python and Quill-Lexicon.py." -ForegroundColor Red; Pause2; return
    }
    Write-Host "   Reading your campaign notes for names the transcriber should know..." -ForegroundColor Yellow
    Write-Host ""
    Invoke-Python $py @($script) | ForEach-Object { Write-Host "   $_" }
    Write-Host ""
    if ((Read-Host "   Add these to lexicon.txt? (y/N)") -match '^[Yy]') {
        Invoke-Python $py @($script, "--write") | ForEach-Object { Write-Host "   $_" -ForegroundColor Green }
        Write-Host "   Your own entries were not touched." -ForegroundColor DarkGray
    } else {
        Write-Host "   Left alone." -ForegroundColor DarkGray
    }
    Pause2
}

function Opt {
    param([string]$key, [string]$icon, [string]$label, [string]$hint = "")
    Write-Host "   │   " -ForegroundColor DarkYellow -NoNewline
    Write-Host $key -ForegroundColor Yellow -NoNewline
    Write-Host "  " -NoNewline
    Write-Host ("{0} {1,-28}{2}" -f $icon, $label, $hint) -ForegroundColor Gray
}

function Sect {
    # A menu of sixteen flat entries is a toolbox; grouped by WHEN you reach for
    # them, it becomes the night's running order.
    param([string]$title)
    $pad = [Math]::Max(1, 44 - $title.Length)
    Write-Host "   │" -ForegroundColor DarkYellow
    Write-Host "   ├─ " -ForegroundColor DarkYellow -NoNewline
    TC "222;108;22" ($title + " " + ([string][char]0x2500 * $pad))
}

# --- main loop ---------------------------------------------------------------
while ($true) {
    Header
    Write-Host "   ┌──────────────────────────────────────────────────────────" -ForegroundColor DarkYellow
    Sect "AT THE TABLE"
    Opt "[1]" "●" "Record a session"      "mic → recordings\"
    Opt "[F]" "◈" "Floating MARK button"  "stays on top while you play"
    Opt "[W]" "◆" "Web studio"            "browser + phone remote + the Chorus"
    Sect "AFTER THE GAME"
    Opt "[2]" "✎" "Transcribe — fast"     "small.en"
    Opt "[3]" "✎" "Transcribe — hi-acc"   "medium.en"
    Opt "[T]" "♫" "Merge the Chorus"      "one track per voice -> who said what"
    Opt "[8]" "❖" "Mine a transcript"     "one night: marks, names, health"
    Sect "THE CAMPAIGN"
    Opt "[9]" "≡" "Campaign reports"      "ledger · concordance · mirror"
    Opt "[O]" "☾" "Cold open"             "read this before the players arrive"
    Opt "[X]" "✒" "Rebuild lexicon"       "from your campaign notes"
    Opt "[6]" "▤" "Session log"
    Sect "THE HOUSE"
    Opt "[D]" "✚" "Pre-game check"        "run this before they arrive"
    Opt "[R]" "♫" "Rehearse the Chorus"   "a fake table, end to end, before a real one"
    Opt "[4]" "▸" "Recordings folder"
    Opt "[5]" "▸" "Transcripts folder"
    Opt "[7]" "✦" "How it works"
    Opt "[Q]" "×" "Quit"
    Write-Host "   │" -ForegroundColor DarkYellow
    Write-Host "   └──────────────────────────────────────────────────────────" -ForegroundColor DarkYellow
    Write-Host ""
    TC $C_DIM ("   ~ " + (Get-Random -InputObject $TableWisdom))
    Write-Host ""
    $choice = Read-Host "   Choose"
    switch ($choice.ToUpper()) {
        "1" { Record }
        "2" { Transcribe -Model "small.en" }
        "3" { Transcribe -Model "medium.en" }
        "4" { Start-Process explorer.exe $recordings }
        "5" { Start-Process explorer.exe $transcripts }
        "6" { ShowLog }
        "7" { HowItWorks }
        "8" { Digest }
        "9" { Reports }
        "O" {
            Header
            $py = Find-Python
            $sc = Join-Path $here "Quill-ColdOpen.py"
            if (-not $py -or -not (Test-Path $sc)) {
                Write-Host "   Need Python and Quill-ColdOpen.py." -ForegroundColor Red; Pause2; return
            }
            TC $C_GOLD "   Building the cold open from your newest session..."
            Write-Host ""
            Invoke-Python $py @($sc) | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
            $f = Join-Path $here "COLD-OPEN.md"
            if (Test-Path $f) {
                Write-Host ""
                if ((Read-Host "   Open it? (y/N)") -match '^[Yy]') { Start-Process $f }
            }
            Pause2
        }
        "X" { Lexicon }
        "T" { ChorusMerge }
        "F" {
            # Launched as its own process on purpose: a separate window that can be
            # left open over the Grimoire, and that cannot affect the recording.
            $mk = Join-Path $here "Quill-Marker.ps1"
            if (Test-Path $mk) {
                Start-Process powershell -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-WindowStyle","Hidden","-File","`"$mk`"")
                Header
                Write-Host "   Floating MARK button opened - drag it somewhere you can reach." -ForegroundColor Green
                Write-Host "   Start the recording first if you haven't; it marks the live session." -ForegroundColor DarkGray
                Start-Sleep -Seconds 2
            } else { Write-Host "   Quill-Marker.ps1 is missing." -ForegroundColor Red; Pause2 }
        }
        "D" {
            Header
            $doc = Join-Path $here "Quill-Doctor.ps1"
            if (Test-Path $doc) { & $doc } else { Write-Host "   Quill-Doctor.ps1 is missing." -ForegroundColor Red; Pause2 }
        }
        "R" {
            Header
            $py = Find-Python
            $sc = Join-Path $here "Quill-Rehearsal.py"
            if (-not $py -or -not (Test-Path $sc)) {
                Write-Host "   Need Python and Quill-Rehearsal.py." -ForegroundColor Red; Pause2; return
            }
            TC $C_GOLD "   THE CHORUS REHEARSAL"
            Write-Host ""
            Write-Host "   Invents a table, gives every seat a voice, and pushes their audio" -ForegroundColor Gray
            Write-Host "   through the same path a phone uses - then merges it and reads the" -ForegroundColor Gray
            Write-Host "   braid back to check every voice came home under its own name." -ForegroundColor Gray
            Write-Host ""
            Write-Host "   Takes a couple of minutes. Touches no real recording." -ForegroundColor DarkGray
            Write-Host ""
            $n = Read-Host "   How many voices? (Enter = 3)"
            $args = @()
            if ($n.Trim() -match '^\d+$') { $args += @("--voices", $n.Trim()) }
            Write-Host ""
            Invoke-Python $py (@($sc) + @($args)) | ForEach-Object { Write-Host $_ }
            Pause2
        }
        "W" {
            Header
            Write-Host "   Opening the web studio (prettier face, same engine)..." -ForegroundColor Yellow
            Write-Host "   Leave its console window open while you play." -ForegroundColor DarkGray
            Start-Process (Join-Path $here "Gnashers Quill Web.bat")
            Start-Sleep -Seconds 2
        }
        "Q" {
            Header
            TC "150;150;160" "                   ˚ ·"
            TC "120;112;96"  "                    )"
            TC "120;112;96"  "                   |#|"
            TC $C_GOLD       "                  ====="
            TC $C_GOLD       "                  |   |"
            TC "184;142;72"  "                  ====="
            Write-Host ""
            TC $C_GOLD ("   " + (Get-Random -InputObject $Farewells) + "`n")
            return
        }
        default { }
    }
}
